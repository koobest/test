#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "soc/spi_struct.h"
#include "esp_rom_gpio.h"
#include "driver/gpio.h"
#include "hal/gdma_ll.h"
#include "soc/dport_access.h"
#include "soc/periph_defs.h"
#include "soc/system_reg.h"

#include "soc/lldesc.h"

#define LINK_CNT    (10)
#define pDMA        (&GDMA)
#define DMA_CHANNEL (1)
#define pSPI        (&GPSPI2)

#define SPI_CLK_IDX (101)
#define SPI_CS0_IDX (110)
#define SPI_Q_IDX   (102)
#define SPI_D_IDX   (103)
#define SPI_HD_IDX  (104)
#define SPI_WP_IDX  (105)

#define SPI_CLK     (36)
#define SPI_CS      (35)
#define SPI_Q       (15)
#define SPI_D       (16)
#define SPI_HD      (34)
#define SPI_WP      (33)

static lldesc_t desc[LINK_CNT];

int link_idx = 0;

enum {
	NOTIFY_LINK_TEST = 0x8,
    NOTIFY_SEG_MODE = 0x9,
    NOTIFY_SEG_TRANS_DONE = 0x5,
};

static void spi_matrix_out(int io, int sig, bool inv)
{
    if((io != -1) && (sig != -1)) {
        PIN_FUNC_SELECT(GPIO_PIN_MUX_REG[io], PIN_FUNC_GPIO);
        gpio_set_direction(io, GPIO_MODE_OUTPUT);
        esp_rom_gpio_connect_out_signal(io, sig, 0, inv);
    }
}

static void spi_matrix_in(int io, int sig, bool inv)
{
    if((io != -1) && (sig != -1)) {
        PIN_FUNC_SELECT(GPIO_PIN_MUX_REG[io], PIN_FUNC_GPIO);
        gpio_set_direction(io, GPIO_MODE_INPUT);
        esp_rom_gpio_connect_in_signal(io, sig, inv);
    }
}

static void spi_set_pin(void)
{
    spi_matrix_out(SPI_CLK, SPI_CLK_IDX, 0);
    spi_matrix_out(SPI_CS, SPI_CS0_IDX, 0);
    spi_matrix_out(SPI_Q, SPI_Q_IDX, 0);
    spi_matrix_out(SPI_D, SPI_D_IDX, 0);
    spi_matrix_out(SPI_WP, SPI_WP_IDX, 0);
    spi_matrix_out(SPI_HD, SPI_HD_IDX, 0);

    DPORT_SET_PERI_REG_MASK(SYSTEM_PERIP_CLK_EN0_REG, SYSTEM_SPI2_CLK_EN);
    DPORT_CLEAR_PERI_REG_MASK(SYSTEM_PERIP_RST_EN0_REG, SYSTEM_SPI2_RST);
    printf("SPI data: %x\n", pSPI->date.date);
}

static void set_dma_desc(lldesc_t *desc, uint8_t *buf, size_t size, bool eof_en, uint32_t next_entry)
{
    desc->size = size;
    desc->length = size;
    desc->buf = buf;
    desc->empty = next_entry;
    desc->owner = 1;
    desc->offset = 0;
    desc->sosf = 0;
    desc->eof = eof_en;
}

static void wait_trans_done(void)
{
    static int first_time = 0;
    if (first_time == 0) {
        first_time = 1;
        return;
    }
    uint32_t intr_flag = 0;
    do {
        intr_flag = pSPI->dma_int_raw.trans_done;
    } while(intr_flag == 0);
    pSPI->dma_int_clr.val = ~0;
}

static void spi_notify(int cmd)
{
    wait_trans_done();
    pSPI->user2.usr_command_value = cmd;
    pSPI->user.usr_mosi = 0;
    pSPI->user.usr_dummy = 0;
    pSPI->user.usr_addr = 1;
    pSPI->user.usr_command = 1;
    pSPI->cmd.update = 1;
    pSPI->cmd.usr = 1;
}

void spi_trans_slice(uint8_t *buf, int size, int seq)
{
    wait_trans_done();
    pSPI->dma_conf.rx_afifo_rst = 1;
    pSPI->dma_conf.buf_afifo_rst = 1;
    pSPI->dma_conf.dma_afifo_rst = 1;

    set_dma_desc(&desc[link_idx], buf, size, 1, NULL);

    gdma_ll_tx_set_desc_addr(pDMA, DMA_CHANNEL, (uint32_t)&desc[link_idx]);
    gdma_ll_tx_start(pDMA, DMA_CHANNEL);
    pSPI->ms_dlen.ms_data_bitlen = size*8-1;
    pSPI->user2.usr_command_value = 0x23;
    pSPI->user.usr_mosi = 1;
    pSPI->user.usr_dummy = 1;
    pSPI->user.usr_addr = 1;
    pSPI->user.usr_command = 1;
    pSPI->cmd.update = 1;
    pSPI->cmd.usr = 1;
    link_idx = (link_idx + 1) % LINK_CNT;
}

void spi_link_test(void)
{
    spi_notify(NOTIFY_SEG_TRANS_DONE);
}

void spi_finish_slice(void)
{
    spi_notify(NOTIFY_SEG_TRANS_DONE);
}

void spi_notify_seg_trans_mode(void)
{
    spi_notify(NOTIFY_SEG_MODE);
}

void spi_master_stub_init(void)
{
	int pre_div = 2;
	int div = 2;
	spi_set_pin();
	gdma_ll_enable_clock(pDMA, true);
    gdma_ll_tx_reset_channel(pDMA, DMA_CHANNEL);
    gdma_ll_enable_m2m_mode(pDMA, DMA_CHANNEL, false);
    gdma_ll_tx_connect_to_periph(pDMA, DMA_CHANNEL, 0);
    gdma_ll_tx_enable_owner_check(pDMA, DMA_CHANNEL, false);
    gdma_ll_tx_set_desc_addr(pDMA, DMA_CHANNEL, (uint32_t)&desc[0]);
    pDMA->conf1[DMA_CHANNEL].infifo_full_thrs = 128;
    pDMA->conf1[DMA_CHANNEL].in_ext_mem_bk_size = 1;
    pDMA->sram_size[DMA_CHANNEL].in_size = 1;

    pSPI->clk_gate.mst_clk_sel = 1;
    pSPI->clk_gate.clk_en = 1;
    pSPI->clk_gate.mst_clk_active = 1;
    pSPI->clock.clk_equ_sysclk = 0 ;
    pSPI->clock.clkcnt_l = div-1;
    pSPI->clock.clkcnt_h = (div>>1)-1;
    pSPI->clock.clkcnt_n = div-1;
    pSPI->clock.clkdiv_pre = pre_div-1;

    pSPI->ctrl.val = 0;
    pSPI->user.val = 0;
    pSPI->misc.val = 0;

    pSPI->ctrl.dummy_out = 1;
    pSPI->ctrl.faddr_quad = 0;

    pSPI->user.cs_hold = 1;
    pSPI->user.cs_setup = 1;
    pSPI->user.fwrite_quad = 1;

    pSPI->dma_conf.val = 0;
    pSPI->dma_int_clr.val = ~0;

    pSPI->slave.soft_reset = 1;
    pSPI->slave.soft_reset = 0;
    pSPI->slave.clk_mode = 0;
    pSPI->slave.slave_mode = 0;

    pSPI->user1.cs_setup_time = 2;
    pSPI->user1.cs_hold_time = 2;
	pSPI->user1.usr_dummy_cyclelen = 7;
	pSPI->user1.usr_addr_bitlen = 7;

    pSPI->dma_conf.dma_tx_ena = 1;

    pSPI->dma_conf.rx_afifo_rst = 1;
    pSPI->dma_conf.buf_afifo_rst = 1;
    pSPI->dma_conf.dma_afifo_rst = 1;

    // pSPI->cmd.update = 1;

    spi_notify(0x85);

    uint8_t pr[34] = {0x3};
    spi_trans_slice(pr, 34, 0);
    spi_trans_slice(pr, 34, 0);
    spi_trans_slice(pr, 34, 0);
    spi_trans_slice(pr, 34, 0);
}