#ifndef __SPI_STUB__
#define __SPI_STUB__

#ifdef __cplusplus
extern "C" {
#endif

void spi_slave_stub_init(void);

void spi_master_stub_init(void);

#ifdef __cplusplus
}
#endif

#endif