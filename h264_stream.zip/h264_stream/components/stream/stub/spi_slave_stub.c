#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "soc/spi_struct.h"
#include "esp_rom_gpio.h"
#include "driver/gpio.h"
#include "hal/gdma_ll.h"
#include "soc/dport_access.h"
#include "soc/periph_defs.h"
#include "soc/system_reg.h"
#include "esp_intr_alloc.h"
#include "soc/lldesc.h"
#include "h264_stream.h"

#define LINK_CNT    (5)
#define pDMA        (&GDMA)
#define DMA_CHANNEL (1)
#define pSPI        (&GPSPI2)

#define SPI_CLK_IDX (101)
#define SPI_CS0_IDX (110)
#define SPI_Q_IDX   (102)
#define SPI_D_IDX   (103)
#define SPI_HD_IDX  (104)
#define SPI_WP_IDX  (105)

#define SPI_CLK     (36)
#define SPI_CS      (35)
#define SPI_Q       (15)
#define SPI_D       (16)
#define SPI_HD      (34)
#define SPI_WP      (33)

static lldesc_t desc[LINK_CNT];
static lldesc_t *pcur = NULL;

static void spi_matrix_out(int io, int sig, bool inv)
{
    if((io != -1) && (sig != -1)) {
        PIN_FUNC_SELECT(GPIO_PIN_MUX_REG[io], PIN_FUNC_GPIO);
        gpio_set_direction(io, GPIO_MODE_OUTPUT);
        esp_rom_gpio_connect_out_signal(io, sig, 0, inv);
    }
}

static void spi_matrix_in(int io, int sig, bool inv)
{
    if((io != -1) && (sig != -1)) {
        PIN_FUNC_SELECT(GPIO_PIN_MUX_REG[io], PIN_FUNC_GPIO);
        gpio_set_direction(io, GPIO_MODE_INPUT);
        esp_rom_gpio_connect_in_signal(io, sig, inv);
    }
}

static void spi_set_pin(void)
{
    spi_matrix_in(SPI_CLK, SPI_CLK_IDX, 0);
    spi_matrix_in(SPI_CS, SPI_CS0_IDX, 0);
    spi_matrix_in(SPI_Q, SPI_Q_IDX, 0);
    spi_matrix_in(SPI_D, SPI_D_IDX, 0);
    spi_matrix_in(SPI_WP, SPI_WP_IDX, 0);
    spi_matrix_in(SPI_HD, SPI_HD_IDX, 0);
    if (DPORT_GET_PERI_REG_MASK(SYSTEM_PERIP_CLK_EN1_REG, SYSTEM_DMA_CLK_EN) == 0) {
        DPORT_SET_PERI_REG_MASK(SYSTEM_PERIP_CLK_EN1_REG, SYSTEM_DMA_CLK_EN);
        DPORT_CLEAR_PERI_REG_MASK(SYSTEM_PERIP_RST_EN1_REG, SYSTEM_DMA_RST);
    }
    DPORT_SET_PERI_REG_MASK(SYSTEM_PERIP_CLK_EN0_REG, SYSTEM_SPI2_CLK_EN);
    DPORT_CLEAR_PERI_REG_MASK(SYSTEM_PERIP_RST_EN0_REG, SYSTEM_SPI2_RST);
    printf("lcd_cam: 0x%x  0x%x\n",  pSPI->date.date, pDMA->date);
}

static void set_dma_desc(lldesc_t *desc, uint8_t *buf, size_t size, bool eof_en, uint32_t next_entry)
{
    desc->size = size;
    desc->length = size;
    desc->buf = buf;
    desc->empty = next_entry;
    desc->owner = 1;
    desc->offset = 0;
    desc->sosf = 0;
    desc->eof = eof_en;
}

static void spi_init_dma_link(void)
{
    uint8_t *dma_buf = (uint8_t *)malloc(1023*4*LINK_CNT);
    if (dma_buf == NULL) {
        printf(" SPI dma buffer alloc fail\n");
        assert(0);
    }
    for (int i = 0; i < LINK_CNT; i++) {
        set_dma_desc(&desc[i], dma_buf, 1023*4, 0, &desc[(i+1) % LINK_CNT]);
        dma_buf += 1023*4;
    }
    pcur = &desc[0];
}

static void dma_isr(void *param)
{
    uint32_t stat;
    while(1) {
        stat = gdma_ll_get_interrupt_status(pDMA, DMA_CHANNEL);
        if(stat == 0) break;
        gdma_ll_clear_interrupt_status(pDMA, DMA_CHANNEL, stat);
        h264_stream_push(pcur->buf, pcur->length);
        if (stat & GDMA_LL_EVENT_RX_SUC_EOF) {
            pcur = (lldesc_t *)gdma_ll_rx_get_success_eof_desc_addr(pDMA, DMA_CHANNEL);
            portYIELD_FROM_ISR();
        }
        pcur = (lldesc_t *)pcur->empty;
    }
}

static void spi_slave_isr(void *param)
{
    typeof(pSPI->dma_int_st) int_st;
    while(1) {
        int_st = pSPI->dma_int_st;
        if(int_st.val == 0) break;
        pSPI->dma_int_clr.val = int_st.val;
        if (int_st.cmd7) {
            ;
        }
        if (int_st.cmd8) {
            ;
        }
        if (int_st.cmd9) {
            ;
        }
        if (int_st.cmda) {
            ;
        }
    }
}

static void spi_slave_start(void)
{
    spi_init_dma_link();
    esp_intr_alloc(ETS_DMA_CH1_INTR_SOURCE, 0, dma_isr, NULL, NULL);
    // esp_intr_alloc(ETS_SPI2_INTR_SOURCE, 0, spi_slave_isr, NULL, NULL);
    gdma_ll_enable_interrupt(pDMA, DMA_CHANNEL, GDMA_LL_EVENT_RX_SUC_EOF | GDMA_LL_EVENT_RX_DONE, true);
    // pSPI->dma_int_ena.cmd7 = 1;
    // pSPI->dma_int_ena.cmd8 = 1;
    // pSPI->dma_int_ena.cmd9 = 1;
    // pSPI->dma_int_ena.cmda = 1;
    // pSPI->dma_int_ena.trans_done = 1;
    // pSPI->dma_int_ena.dma_seg_trans_done = 1;
    gdma_ll_rx_set_desc_addr(pDMA, DMA_CHANNEL, (uint32_t)&desc[0]);
    gdma_ll_rx_start(pDMA, DMA_CHANNEL);
}

void spi_slave_stub_init(void)
{
	int pre_div = 1;
	int div = 2;
	spi_set_pin();
	gdma_ll_enable_clock(pDMA, true);
    gdma_ll_rx_reset_channel(pDMA, DMA_CHANNEL);
    gdma_ll_enable_m2m_mode(pDMA, DMA_CHANNEL, false);
    gdma_ll_rx_connect_to_periph(pDMA, DMA_CHANNEL, 0);
    gdma_ll_rx_enable_owner_check(pDMA, DMA_CHANNEL, false);
    gdma_ll_rx_set_desc_addr(pDMA, DMA_CHANNEL, (uint32_t)&desc[0]);
    pDMA->conf1[DMA_CHANNEL].infifo_full_thrs = 128;
    pDMA->conf1[DMA_CHANNEL].in_ext_mem_bk_size = 1;
    pDMA->sram_size[DMA_CHANNEL].in_size = 1;

    pSPI->clk_gate.mst_clk_sel = 1;
    pSPI->clk_gate.clk_en = 1;
    pSPI->clk_gate.mst_clk_active = 1;
    pSPI->clock.clk_equ_sysclk = 0 ;
    pSPI->clock.clkcnt_l = div-1;
    pSPI->clock.clkcnt_h = (div>>1)-1;
    pSPI->clock.clkcnt_n = div-1;
    pSPI->clock.clkdiv_pre = pre_div-1;

    pSPI->ctrl.val = 0;
    pSPI->user.val = 0;
    pSPI->misc.val = 0;

    pSPI->dma_int_clr.val = ~0;
    pSPI->dma_conf.val = 0;
    pSPI->dma_conf.dma_seg_trans_en = 1;
    pSPI->dma_conf.dma_rx_ena = 1;

    pSPI->slave.val = 0;
    pSPI->slave.slave_mode = 1;
    pSPI->slave.soft_reset = 1;
    pSPI->slave.soft_reset = 0;

    pSPI->dma_conf.rx_afifo_rst = 1;
    pSPI->dma_conf.buf_afifo_rst = 1;
    pSPI->dma_conf.dma_afifo_rst = 1;
    pSPI->cmd.update = 1;
    spi_slave_start();
}