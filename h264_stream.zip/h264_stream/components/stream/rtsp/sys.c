#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "rtsp_server.h"
#include "rtp.h"

#define MGMT_SYS_MSG_QUEUE  "/mgmt_sys_msg_queue"

typedef enum
{
   MGMT_SYS_EVENT_PLAY, 
   MGMT_SYS_EVENT_TEARDOWN, 

} eMGMT_SYS_EVENT;

typedef struct
{
    unsigned int    id; 

} sMGMT_SYS_EVENT_DATA_TEARDOWN;


typedef struct
{
    unsigned int    id; 
    unsigned int    ip;
    unsigned short  port;

} sMGMT_SYS_EVENT_DATA_PLAY;


typedef union
{
    sMGMT_SYS_EVENT_DATA_PLAY       play;
    sMGMT_SYS_EVENT_DATA_TEARDOWN   teardown; 

} uMGMT_SYS_EVENT_DATA;


typedef struct
{
    eMGMT_SYS_EVENT         event;
    uMGMT_SYS_EVENT_DATA    event_data;

} sMGMT_SYS_MSG;


typedef struct
{
    QueueHandle_t       msg_queue;
    unsigned int    active_session; 
} sMGMT_SYS_CBLK;

static sMGMT_SYS_CBLK   f_cblk;

static void rerouces_init(void)
{
    f_cblk.msg_queue = xQueueCreate(10, sizeof(sMGMT_SYS_MSG));
}


static void mgmt_rtsp_cback(void *arg,eSX_MGMT_RTSP_EVENT event, uSX_MGMT_RTSP_EVENT_DATA *event_data)
{
    sMGMT_SYS_MSG   msg;
    if(event == MGMT_RTSP_EVENT_PLAY)
    {
        msg.event = MGMT_SYS_EVENT_PLAY;
        msg.event_data.play.id = event_data->play.id;
        msg.event_data.play.ip = event_data->play.ip;
        msg.event_data.play.port = event_data->play.port;
        printf("event: %d\n", event_data->play.port);
        xQueueSend(f_cblk.msg_queue, &msg, (portTickType)0);
    }

    if(event == MGMT_RTSP_EVENT_TEARDOWN)
    {
        msg.event = MGMT_SYS_EVENT_TEARDOWN;
        msg.event_data.teardown.id = event_data->teardown.id; 
        xQueueSend(f_cblk.msg_queue, &msg, (portTickType)0);
    }
}


static void mgmt_sys_thread(void * arg)
{
    sMGMT_SYS_MSG   msg;
    // Open RTSP manager.
    sx_mgmt_rtsp_open();

    // Open RTP manager.
    sx_mgmt_rtp_open();

    // Open video manager. 
    // sx_mgmt_video_open();

    while(1)
    {
        xQueueReceive(f_cblk.msg_queue, &msg, (portTickType)portMAX_DELAY);
        switch(msg.event)
        {
            case MGMT_SYS_EVENT_PLAY:
            {
                // Activate RTP manager.
                sx_mgmt_rtp_activate(msg.event_data.play.id,
                                     msg.event_data.play.ip,
                                     msg.event_data.play.port);
                if(f_cblk.active_session == 0)
                {
                    printf("mgmt_video_activate() Invoked\n");

                    // sx_mgmt_video_activate(); 
                }

                f_cblk.active_session++; 

                break;
            }
            case MGMT_SYS_EVENT_TEARDOWN:
            {
                // Reset associate RTP session. 
                sx_mgmt_rtp_reset(msg.event_data.teardown.id); 

                f_cblk.active_session--; 

                if(f_cblk.active_session == 0)
                {
                    printf("mgmt_video_reset() Invoked\n");

                    // sx_mgmt_video_reset(); 
                }
                break; 
            }
            default:
            {
                assert(0);
            }
        }
    }
}


static void mgmt_sys_thread_create(void)
{
    xTaskCreate(mgmt_sys_thread, "mgmt_sys_thread", 1024*3, NULL, 7, NULL);
}


void mgmt_sys_init(void)
{
    printf("mgmt_sys_init(): Invoked.\n"); 

    // Initialize resources.
    rerouces_init();

    // Initialize RTSP manager.
    sx_mgmt_rtsp_init(mgmt_rtsp_cback, &f_cblk);

    // Initialize RTP manager.
    sx_mgmt_rtp_init();

    // Initialize video manager. 
    // sx_mgmt_video_init(); 
}


void mgmt_sys_open(void)
{
    printf("mgmt_sys_open(): Invoked.\n"); 

    mgmt_sys_thread_create();
}
