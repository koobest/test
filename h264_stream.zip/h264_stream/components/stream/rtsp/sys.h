#ifndef __RTSP_SYS_H__
#define __RTSP_SYS_H__

#ifdef __cplusplus
extern "C" {
#endif

void mgmt_sys_init(void);
void mgmt_sys_open(void);

#ifdef __cplusplus
}
#endif

#endif