#ifndef __INCLUDE_ALL_H__
#define __INCLUDE_ALL_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "h264_stream.h"
#include "rtsp_server.h"
#include "rtp.h"
#include "sys.h"
#include "spi_stub.h"
#include "wifi_start.h"

#ifdef __cplusplus
}
#endif

#endif