#ifndef __H264_STREAM__
#define __H264_STREAM__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct stream_buf {
    uint8_t *stream_buf;
    int nal_remain;
    int nal_offset;
    size_t max_size;
    size_t size;
} stream_buf_t;

void h264_stream_push(uint8_t *stream_buf, size_t size);

void h264_stream_push_done(bool blocking_ena);

void h264_stream_pull(uint8_t **stream_buf, size_t* size);

void h264_stream_pull_done(void);

void h264_stream_reset(void);

void h264_stream_init(void);

#ifdef __cplusplus
}
#endif

#endif