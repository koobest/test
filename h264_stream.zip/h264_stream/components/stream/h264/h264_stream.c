#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "string.h"

#define FRAME_STASH_CNT  10
//stream_buffer: NAL header(32B max) + VCL data;

typedef struct stream_buf {
    uint8_t *stream_buf;
    int nal_remain;
    int nal_offset;
    size_t max_size;
    size_t size;
} stream_buf_t;

typedef struct h264_stream{
    stream_buf_t sream_buf[FRAME_STASH_CNT];
    stream_buf_t *in_cur;
    stream_buf_t *out_cur;
    QueueHandle_t inQueue;
	QueueHandle_t outQueue;
} h264_stream_t;

h264_stream_t  stream = {0};

static void handle_in_stream_buffer_full(void)
{
    uint32_t get_item;
    xQueueReceive(stream.inQueue, &get_item, (portTickType)0);
    xQueueSend(stream.outQueue, &get_item, (portTickType)0);
}

void h264_stream_push(uint8_t *stream_buf, size_t size)
{
    memcpy(stream.in_cur->stream_buf+stream.in_cur->size, stream_buf, size);
    stream.in_cur->size += size;
}

//Todo: DIR 帧不能
void h264_stream_push_done(bool blocking_ena)
{
    // printf("push size: %d\n", stream.in_cur->size);
    uint32_t val = (uint32_t)(stream.in_cur);
    if (blocking_ena) {
        xQueueSend(stream.inQueue, &(val), (portTickType)portMAX_DELAY);
    } else {
        if (xQueueSend(stream.inQueue, &(val), (portTickType)200) != pdTRUE) {
            handle_in_stream_buffer_full();
            xQueueSend(stream.inQueue, &(val), (portTickType)0);
        }
    }
    xQueueReceive(stream.outQueue, &(val), (portTickType)0);
    stream.in_cur  = (stream_buf_t *)val;
    stream.in_cur->size = 0;
    // printf("push done : %p\n", stream.in_cur->stream_buf);
}

void h264_stream_pull(uint8_t **stream_buf, size_t* size)
{
    uint32_t val;
    xQueueReceive(stream.inQueue, &(val), (portTickType)portMAX_DELAY);
    stream.out_cur = (stream_buf_t*)val;
    *stream_buf = stream.out_cur->stream_buf;
    *size = stream.out_cur->size;
}

void h264_stream_pull_done(void)
{

    stream.out_cur->size = 0;
    uint32_t val = (uint32_t)stream.out_cur;
    xQueueSend(stream.outQueue, &(val), (portTickType)0);
}

void h264_stream_reset(void)
{
    xQueueReset(stream.outQueue);
    xQueueReset(stream.inQueue);
}

void h264_stream_init(void)
{
    stream.inQueue = xQueueCreate(FRAME_STASH_CNT, sizeof(stream_buf_t*));
    stream.outQueue = xQueueCreate(FRAME_STASH_CNT, sizeof(stream_buf_t*));

    for (int i = 0; i < FRAME_STASH_CNT; i ++) {
        stream.sream_buf[i].stream_buf = (uint8_t *)heap_caps_calloc(1, 128*1024, MALLOC_CAP_SPIRAM);
        if (stream.sream_buf[i].stream_buf == 0) printf("malloc fail\n");
        stream.sream_buf[i].nal_remain = 32;
        stream.sream_buf[i].nal_offset = 0;
        stream.sream_buf[i].max_size = 128*1024;
        stream.sream_buf[i].size = 0;
        // printf("buffer : %p\n", stream.sream_buf[i].stream_buf);
    }
    for (int i = 1; i < FRAME_STASH_CNT; i++ ) {
        uint32_t val = (uint32_t)(&(stream.sream_buf[i]));
        xQueueSend(stream.outQueue, &(val), (portTickType)0);
    }
    stream.in_cur = &(stream.sream_buf[0]);
    stream.out_cur = NULL;
}