#ifndef __WIFI_START__
#define __WIFI_START__

#ifdef __cplusplus
extern "C" {
#endif

void wifi_ap_start_up(void);

void wifi_sta_start_up(void);

void udp_ser_start_up(void);

#ifdef __cplusplus
}
#endif

#endif