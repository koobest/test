#include "esp_netif.h"
#include <string.h>
#include <sys/param.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"

#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include <lwip/netdb.h>
#include "h264_stream.h"


int socket_fd = -1;

int server_up_flag = 0;

void udp_server_task(void *param)
{
    printf("server start up\n");
    struct sockaddr_storage source_addr; // Large enough for both IPv4 or IPv6
    socklen_t socklen = sizeof(source_addr);
    char buf0[] = "hello world";
    char buf1[20];
    while(1) {
        printf("recv\n");
        recvfrom(socket_fd, buf1, 20, 0, (struct sockaddr *)&source_addr, &socklen);
        if ( memcmp(buf1, buf0, sizeof(buf0)) == 0) {
            printf("connect\n");
            break;
        }
   }
   uint8_t *buf = malloc(1024);
   if (buf == NULL) {
        printf("udp server buffer alloc fail\n");
        assert(0);
   }
   size_t size_rem;
   uint8_t *ptr;
   int tx_len;
   vTaskDelay(3000/portTICK_PERIOD_MS);
   server_up_flag = 1;
   while(1) {
        h264_stream_pull(&ptr, &size_rem);
        while(size_rem) {
            tx_len = size_rem > 1023 ? 1023 : size_rem;
            memcpy(buf, ptr, tx_len);
            sendto(socket_fd, buf, tx_len, 0, (struct sockaddr *)&source_addr, sizeof(source_addr));
            ptr += tx_len;
            size_rem -= tx_len;
            vTaskDelay(10/portTICK_PERIOD_MS);
        }
        h264_stream_pull_done();
   }
   vTaskDelete(NULL);
}

void udp_server_init(void)
{
    const int port = 5553;
    struct sockaddr_in local_addr = {0};
    local_addr.sin_family  = AF_INET;
    local_addr.sin_port	= htons(port);
    local_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    socket_fd = socket(PF_INET, SOCK_DGRAM, 0);
    if (socket_fd < 0) {
        printf("socket fail\n");
        return;
    }
    int ret = bind(socket_fd,(struct sockaddr*)&local_addr,sizeof(local_addr));
    if(ret < 0) {
        printf("bind fail\n");
        return;
    }
    xTaskCreate(udp_server_task, "udp_server", 4096, 0, 7, NULL);
}

void udp_ser_start_up(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    udp_server_init();
}