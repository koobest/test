#include <stdio.h>
#include "string.h"
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "include_all.h"

extern const uint8_t bin_start[] asm("_binary_test_264_start");
extern const uint8_t bin_end[]   asm("_binary_test_264_end");
extern int server_up_flag;

void stream_push_test_task(void *param)
{
    uint8_t *pr = bin_start;
    size_t size = bin_end-bin_start;
    while(server_up_flag != 1) {
        vTaskDelay(2000/portTICK_PERIOD_MS);
    }
    printf("tot size %d\n", size);
    while(1) {
        int size_rem = size;
        size_t tx_len = 0;
        pr = bin_start;
        while (size_rem) {
            tx_len = size_rem > 1000 ? 1000 : size_rem;
            // printf("%d\n", tx_len);
            h264_stream_push(pr, tx_len);
            // printf("push done\n");
            vTaskDelay(20/portTICK_PERIOD_MS);
            h264_stream_push_done(false);
            pr += tx_len;
            size_rem -= tx_len;
        }
        vTaskDelay(30/portTICK_PERIOD_MS);
    }
}

uint8_t *get_nal(size_t *out_size)
{
    static int in_size = -1;
    static uint8_t *nal = NULL;
    if (in_size == -1) {
        nal = bin_start;
        in_size = bin_end - bin_start;// - bin_end;
    }
    if (in_size < 4) {
        *out_size = 0;
        return NULL;
    };
    uint8_t *start = nal;
    uint8_t *end = nal+in_size;
    uint8_t *cur = start;
    uint8_t *ret = NULL;
    while (cur < end) {
        if (cur[0] == 0x0 && cur[1] == 0x0 && cur[2] == 0x0 && cur[3] == 0x1) {
            ret = cur + 4;
            cur += 5;
            break;
        }
        cur++;
    }
    while (cur < end) {
        if (cur[0] == 0x0 && cur[1] == 0x0 && cur[2] == 0x0 && cur[3] == 0x1) {
            nal = cur;
            break;
        }
        cur++;
    }
    *out_size = (size_t)(cur - ret);
    in_size -= *out_size;
    if( cur == end) {
        in_size = -1;
    }
    return ret;
}

void app_main(void)
{
    // uint8_t *pr = NULL;
    // size_t size = 0;
    // for (int i = 0; i < 10; i++) {
    //     pr = get_nal(&size);
    //     printf("%p  %d\n", pr, size);
    // }
   wifi_sta_start_up();//WiFi connection
   mgmt_sys_init();
   mgmt_sys_open();
#if 0
	h264_stream_init();
    spi_slave_stub_init();//SPI slave Init
    udp_ser_start_up();
    xTaskCreatePinnedToCore(stream_push_test_task, "stream_push_test_task", 4096, NULL, 8, NULL, 1);
#endif
}

// https://winddoing.github.io/post/35564.html
//https://blog.csdn.net/zhoubotong2012/article/details/86510032
// https://github.com/ireader/media-server/blob/master/librtsp/source/rtsp-header-range.c
//cat filename| head -n 1024 | tail -n +1000 > newfile.txt