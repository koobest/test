#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_heap_caps.h"
#include <netinet/in.h>
#include <eXosip2/eXosip.h>
#include "lwip/err.h"
#include "lwip/sys.h"
#include <osip2/osip_mt.h>
#include <eXosip2/eXosip2.h>
#include <rtp.h>
#include "audio.h"
#include "config.h"

typedef struct {
    struct eXosip_t *eXosip;
#define SESSIPN_PORT  1623
    char ip[32];
    int port;

#define RTP_PORT      5060
    struct {
        char rtp_ip[32];
        int rtp_port;
    } rtp;

    rtp_sink_t *rtp_sink;
    //session
    struct {
        int session_id;
        int call_id;
#define ADUIO_SAMPLE_RATE 8000
#define AUDIO_LEN 160
#define TIME_STAMP 1000*AUDIO_LEN/ADUIO_SAMPLE_RATE
    } session;
    // register
    struct {
        char uname[16];
        char passwd[8];
        char proxy_ip[32];
        int proxy_port;
        int rid;
        osip_message_t *reg;
    } user;
    void *net_work;
    void *control;
    void *task_handle;
    void *audio_task_handle;
    void *idle_task_handle;
    int status;
    int session_active;
} session_t;

enum {
    SESSION_UNITED,
    SESSION_INITED,
    SESSION_UNREGISTER,
    SESSION_REGISTERED,
    SESSION_INVITE,
    SESSION_HANDLE,
    SESSION_RING,
    SESSION_REJECT,
    SESSION_ANSER,
    SESSION_TALK,
    SESSION_NULL_CALL,
    SESSION_DONE,
};

static session_t *session;
static void session_main_task(void *param);

static void session_set_user_name(session_t *session, char *name, char *passwd, char *ip, int port)
{
    memset(session->user.uname, 0, sizeof(session->user.uname));
    memset(session->user.passwd, 0, sizeof(session->user.passwd));
    memset(session->user.proxy_ip, 0, sizeof(session->user.proxy_ip));
    strcpy(session->user.uname, name);
    strcpy(session->user.passwd, passwd);
    strcpy(session->user.proxy_ip, ip);
    session->user.proxy_port = port;
}

int session_init_exosip(session_t *session, const char *ip, int port)
{
    int ret = -1;
    session->eXosip = eXosip_malloc();
    if (session->eXosip == NULL) {
        return -1;
    }
    ret = eXosip_init(session->eXosip);
    if(ret!=0) {
        printf("Couldn't initialize eXosip contex!\n");
        return -1;
    }
    ret = eXosip_listen_addr(session->eXosip, IPPROTO_UDP, ip, port, AF_INET, 0);
    if(ret != 0) {
        printf("Couldn't initialize transport layer!\n");
        eXosip_quit(session->eXosip);
        return -1;
    }
    strcpy(session->ip, ip);
    strcpy(session->rtp.rtp_ip, ip);
    session->port = port;
    session->rtp.rtp_port = RTP_PORT;
    session->session_active = false;
    session->status = SESSION_INITED;
    session->rtp_sink = rtp_sink_alloc();
    //set default user name
    session_set_user_name(session, UNAME, PASSWD, PROXY_IP, PROXY_PORT);
    printf("session_init success, ip: %s, port: %d\n", ip, port);
    printf("RTP ip: %s, port: %d\n", session->rtp.rtp_ip, session->rtp.rtp_port);
    xTaskCreate(session_main_task, "session_main_task", 1024*10, NULL, 6, NULL);
    return 0;
}


int session_call(session_t *session, const char* dst_name)
{
#define INVITE_SDP_STR \
        "v=0\r\n"\
        "o=yate 1618414934 1618414934 IN IP4 %s\r\n"\
        "s=SIP Call\r\n"\
        "c=IN IP4 %s\r\n"\
        "t=0 0\r\n"\
        "m=audio %d RTP/AVP 0 8 11 98 97 105 106 101\r\n"\
        "a=rtpmap:0 PCMU/8000\r\n"\
        "a=rtpmap:8 PCMA/8000\r\n"\
        "a=rtpmap:11 L16/8000\r\n"\
        "a=rtpmap:98 iLBC/8000\r\n"\
        "a=fmtp:98 mode=20\r\n"\
        "a=rtpmap:97 iLBC/8000\r\n"\
        "a=fmtp:97 mode=30\r\n"\
        "a=rtpmap:105 iSAC/16000\r\n"\
        "a=rtpmap:106 iSAC/32000\r\n"\
        "a=rtpmap:101 telephone-event/8000\r\n"\
        "a=ptime:30\r\n"\
        "\r\n"

    if (session->status != SESSION_REGISTERED) {
        printf("error status\n");
        return -1;
    }
    int ret = -1;
    osip_message_t *invite=NULL;
    char source[64];
    char dest[64];
    uint8_t *invite_msg = malloc(512);
    memset(invite_msg, 0, 512);
    memset(source, 0, 64);
    memset(dest, 0, 64);
    sprintf(source, "sip:%s@%s", session->user.uname, session->ip);
    sprintf(dest, "sip:%s:%d", dst_name, RTP_PORT);
    ret = eXosip_call_build_initial_invite(session->eXosip, &invite, dest, source, NULL,"Exosip call");
    if (ret != 0) {
        printf("Build INVITE failed!\n");
        goto out;
    }
    snprintf((char *)invite_msg, 512, INVITE_SDP_STR, session->rtp.rtp_ip, session->rtp.rtp_ip, session->rtp.rtp_port);
    osip_message_set_body(invite, (char *)invite_msg, strlen((char *)invite_msg));
    osip_message_set_content_type(invite,"application/sdp");
    session->status = SESSION_INVITE;
    eXosip_lock(session->eXosip);
    ret = eXosip_call_send_initial_invite(session->eXosip, invite);
    eXosip_unlock(session->eXosip);
    ret = 0;
out:
    if (invite_msg) {
        free(invite_msg);
    }
    return ret;
}

int session_register(session_t *session)
{
    int rid = -1;
    char fromuser[64];
    char proxy[64];
    char *contact=NULL;
    memset(fromuser, 0, 64);
    memset(proxy, 0, 64);
    sprintf(fromuser, "sip:%s@%s", session->user.uname, session->user.proxy_ip);
    sprintf(proxy, "sip:%s:%d", session->user.proxy_ip, session->user.proxy_port);

    rid = eXosip_register_build_initial_register(session->eXosip, fromuser, proxy, contact, 1800, &(session->user.reg));
    if (rid < 0) {
        printf("Build REGISTER failed!\n");
    }

    session->user.rid = rid;
    session->status = SESSION_UNREGISTER;
    int ret; 
    eXosip_lock(session->eXosip);
    ret = eXosip_register_send_register(session->eXosip, rid, session->user.reg);
    eXosip_unlock(session->eXosip);
    if (ret != 0) {
        printf("reg fail\n");
    }
    return 0;
}

static void rtp_session_active(session_t *session)
{
    session->rtp_sink->rtp_socket_active(session->rtp_sink);
    session->session_active = 1;
}

static void rtp_session_deactive(session_t *session)
{
    session->rtp_sink->rtp_socket_close(session->rtp_sink);
    session->session_active = false;
}

static void session_play_audio(char *audio_name, int times, int time_scal_ms)
{
    uint8_t *_data;
    size_t _size;
    get_audio_by_name(audio_name, &_data, &_size);
    uint16_t *tx_buf = malloc(1024);
    size_t tx_size = 0;
    uint8_t *data;
    size_t size;
    for (int i = 0; i < times; i++) {
        data =_data;
        size =_size;
        while (size) {
            tx_size = size > 1024 ? 1024 : size;
            memcpy(tx_buf, data, tx_size);
            audio_ch_swap_16(tx_buf, tx_size);
            audio_write((uint8_t*)tx_buf, tx_size, 100);
            data += tx_size;
            size -= tx_size;
        }
        if (i == 1) break;
        vTaskDelay(time_scal_ms/portTICK_PERIOD_MS);
    }
    free(tx_buf);
}

void call_someone(char* dst_name)
{
    session_call(session, dst_name);
    // xTaskCreate(handle_session_event_task, "handle_session_event_task", 1024*6, NULL, 8, NULL);
}

static int session_sdp_parse(session_t *session, sdp_message_t *remote_sdp)
{
    int i_ip[2];
    int i_port[2];
    sdp_media_t *audio_sdp = NULL;
    audio_sdp = eXosip_get_audio_media(remote_sdp);
    sdp_connection_t *cnt = eXosip_get_audio_connection(remote_sdp);
    if (!cnt || !audio_sdp) {
        return -1;
    }
    if (audio_sdp->m_media) {
        ;
    }
    if (audio_sdp->m_number_of_port) {
        ;
    }
    if (audio_sdp->i_info) {
        ;
    }
    if (!audio_sdp->m_proto) return -1;
    
    rtp_sink_set_protol(session->rtp_sink, audio_sdp->m_proto);

    if (audio_sdp->m_port) {
        i_port[0] = RTP_PORT;
        i_port[1] = atoi(audio_sdp->m_port);
    }
    if (cnt->c_addr) {
       i_ip[1] = inet_addr(cnt->c_addr);
       i_ip[0] = inet_addr(session->ip);
    }
    for (int i = 0; i < audio_sdp->a_attributes.nb_elt; i++) {
       sdp_attribute_t *attr = (sdp_attribute_t*)osip_list_get(&audio_sdp->a_attributes, i);
       rtp_prase_sdp(session->rtp_sink, attr->a_att_field, attr->a_att_value);
    }
    session->rtp_sink->rtp_init_port_socket(session->rtp_sink, i_port, i_ip);
    return 0;
}

void call_terminate(void)
{
    if (session->status == SESSION_ANSER) {
        printf("send by\n");
        eXosip_call_terminate(session->eXosip, session->session.session_id , session->session.call_id);
    }
}

char* get_ip_str(void);

int session_global_init(void)
{
    session = (session_t *)malloc(sizeof(session_t));
    if (!session) return -1;
    memset(session, 0, sizeof(session_t));
    while (get_ip_str() == NULL) {
        vTaskDelay(100/portTICK_PERIOD_MS);
    }
    session->status = SESSION_UNITED;
    return session_init_exosip(session, get_ip_str(), 1132);
}

void net_config(void);
void console_init(void);
void bind_key(int key, int id, void (*on_cb)(void), void (*off_cb)(void));

void call0(void)
{
    char dst[64];
    memset(dst, 0, 64);
    sprintf(dst, "%s@%s\n", CALL_NAME, PROXY_IP);
    call_someone(dst);
}

void hold_on_0(void)
{
    printf("hold on\n");
    call_terminate();
    audio_stop();
}

void call1(void)
{
    char dst[64];
    memset(dst, 0, 64);
    sprintf(dst, "%s@%s\n", CALL_NAME, PROXY_IP);
    call_someone(dst);
}

void hold_on_1(void)
{
    ;
}

void call2(void)
{
    char dst[64];
    memset(dst, 0, 64);
    sprintf(dst, "%s@%s\n", CALL_NAME, PROXY_IP);
    call_someone(dst);
}

void hold_on_2(void)
{
    ;
}

static void handle_call_answer_event(session_t *session, eXosip_event_t *event)
{
    if (session->status != SESSION_RING) {
        return;
    }
    printf("session connected!\n");
    sdp_message_t *remote_sdp = eXosip_get_remote_sdp(session->eXosip, event->did);
    if (remote_sdp == NULL) goto r400;
    if (session_sdp_parse(session, remote_sdp) != 0) {
        goto r400;
    }

    osip_message_t *ack=NULL;
    eXosip_call_build_ack(session->eXosip, session->session.call_id, &ack);
    eXosip_call_send_ack(session->eXosip, session->session.call_id, ack);
    rtp_session_active(session);
    session->status = SESSION_ANSER;
    return;
r400:
    return;
}

static void handle_close_event(session_t *session, eXosip_event_t *event)
{
    osip_message_t *answer;
    printf("the remote hold the session!\n");
    if (eXosip_call_build_answer(session->eXosip, event->tid, 200, &answer) != 0) {
        eXosip_call_send_answer(session->eXosip, event->tid, 400, NULL);
    } else {
        eXosip_call_send_answer(session->eXosip, event->tid, 200, answer);
    }

    rtp_session_deactive(session);
    session_play_audio("dudu", 4, 50);
    session->status = SESSION_DONE;
}

static void handle_register_event(session_t *session, eXosip_event_t *event)
{
    if (event->type == EXOSIP_REGISTRATION_SUCCESS) {
        if (session->status == SESSION_UNREGISTER) {
            eXosip_register_remove(session->eXosip, session->user.rid);
            session->status = SESSION_REGISTERED;
            printf("registrered successfully\n");
        }
    } else if ( event->type == EXOSIP_REGISTRATION_FAILURE) {
        if ( session->status == SESSION_UNREGISTER) {
            vTaskDelay(10/portTICK_PERIOD_MS);
            eXosip_add_authentication_info(session->eXosip, session->user.uname, session->user.uname, session->user.passwd, NULL, NULL);
            eXosip_register_build_register(session->eXosip, session->user.rid, 1800, &(session->user.reg));
            eXosip_lock(session->eXosip);
            eXosip_register_send_register(session->eXosip, session->user.rid, session->user.reg);
            eXosip_unlock(session->eXosip);
        }
    }
}

static void handle_invite_event(session_t *session, eXosip_event_t *event)
{
#define ANSWER_SDP_STR \
        "v=0\r\n"\
        "o=yate 1618414934 1618414934 IN IP4 %s\r\n"\
        "s=SIP Call\r\n"\
        "c=IN IP4 %s\r\n"\
        "t=0 0\r\n"\
        "m=audio %d RTP/AVP 0 8 11 98 97 105 106 101\r\n"\
        "a=rtpmap:0 PCMU/8000\r\n"\
        "a=rtpmap:8 PCMA/8000\r\n"\
        "a=rtpmap:11 L16/8000\r\n"\
        "a=rtpmap:98 iLBC/8000\r\n"\
        "a=fmtp:98 mode=20\r\n"\
        "a=rtpmap:97 iLBC/8000\r\n"\
        "a=fmtp:97 mode=30\r\n"\
        "a=rtpmap:105 iSAC/16000\r\n"\
        "a=rtpmap:106 iSAC/32000\r\n"\
        "a=rtpmap:101 telephone-event/8000\r\n"\
        "a=ptime:20\r\n"\
        "\r\n"

    osip_message_t *answer = NULL;
    char *answer_msg = (char *)malloc(1024);
    sdp_message_t *remote_sdp = eXosip_get_remote_sdp(session->eXosip, event->did);
    if (!answer_msg || !remote_sdp) {
        goto r400;
    }
    memset(answer_msg, 0, 1024);
    eXosip_call_send_answer(session->eXosip, event->tid, 180, NULL);//progressing
    if (session_sdp_parse(session, remote_sdp) != 0) {
        goto r400;
    }
    if (eXosip_call_build_answer(session->eXosip, event->tid, 200, &answer) == 0)
    {
       snprintf(answer_msg, 1024, ANSWER_SDP_STR, session->rtp.rtp_ip, session->rtp.rtp_ip, session->rtp.rtp_port);
       osip_message_set_body(answer, answer_msg, strlen(answer_msg));
       osip_message_set_content_type(answer, "application/sdp");
       eXosip_call_send_answer(session->eXosip, event->tid, 200, answer);
       free(answer_msg);
    } else {
       goto r400;
    }
    session->session.session_id = event->cid;
    session->session.call_id = event->did;
    rtp_session_active(session);
    session->status = SESSION_INVITE;
    return;
r400:
    eXosip_call_send_answer(session->eXosip, event->tid, 400, NULL);
    if (answer_msg) {
        free(answer_msg);
    }
}

static void session_handle_ring_event(session_t *session, eXosip_event_t *event)
{
    session_play_audio("connect", 1, 0);
}

static void session_handle_null_event(session_t *session, eXosip_event_t *event)
{
    session_play_audio("null", 1, 0);
}

static void session_main_task(void *param)
{
    eXosip_event_t *event = NULL;
    while (1)
    {
        event = eXosip_event_wait(session->eXosip, 1, 0);
        if (event == NULL) {
            continue;
        }
        printf("%x\n", event->type);
        switch (event->type) {
            default:
            break;
            case EXOSIP_CALL_MESSAGE_ANSWERED:
                printf("session hungup\n");
                if (session->status == SESSION_TALK) {
                    session->status = SESSION_DONE;
                }
            break;
            case EXOSIP_CALL_RELEASED:
                    printf("NULL call\n");
                if (session->status == SESSION_INITED) {
                    session->status = SESSION_NULL_CALL;
                }
                break;
            case EXOSIP_CALL_MESSAGE_NEW:
                printf("NEW\n");
                break;
            case EXOSIP_CALL_REQUESTFAILURE:
                    printf("REQ\n");
                if (session->status == SESSION_RING) {
                    session->status = SESSION_REJECT;
                }
                break;
            case EXOSIP_CALL_INVITE:
                handle_invite_event(session, event);
                break;
            case EXOSIP_CALL_ACK:
                printf("ACK\n");
                break;
            case EXOSIP_CALL_PROCEEDING:
                printf("proceeding!\n");
                if (session->status == SESSION_INVITE) {
                    session->status = SESSION_HANDLE;
                }
                break;
            case EXOSIP_CALL_RINGING:
                printf("ringing!\n");
                if (session->status == SESSION_HANDLE) {
                    session->status = SESSION_RING;
                }
                break;
            case EXOSIP_CALL_ANSWERED: //收到200 OK，表示请求已经被成功接受，用户应答
                handle_call_answer_event(session, event);
                break;
            case EXOSIP_CALL_CLOSED:
                handle_close_event(session, event);
                break;
            case EXOSIP_REGISTRATION_NEW:
                // printf("received new registration\n");
                break;
            case EXOSIP_REGISTRATION_SUCCESS:
            case EXOSIP_REGISTRATION_FAILURE:
                handle_register_event(session, event);
                break;
            case EXOSIP_REGISTRATION_TERMINATED:
                break;
        }
        eXosip_event_free(event);
    }
    vTaskDelete(NULL);
}

#include "driver/timer.h"
uint64_t timer_tick(void)
{
    uint64_t timer_v;
    timer_get_counter_value(TIMER_GROUP_0, TIMER_0, &timer_v);
    return (timer_v>>5);//10us
}

static void sys_timer_init(void)
{
    timer_config_t config = {
        .divider = 25,
        .counter_dir = TIMER_COUNT_UP,
        .counter_en = TIMER_PAUSE,
        .alarm_en = TIMER_ALARM_DIS,
        .auto_reload = 1,
    };
    timer_init(TIMER_GROUP_0, TIMER_0, &config);
    timer_set_counter_value(TIMER_GROUP_0, TIMER_0, 0);
    timer_start(TIMER_GROUP_0, TIMER_0);
}

int udp_console_init(void);

void app_main(void)
{
    sys_timer_init();
    time_t time_now;
    // while(1) {
    //     time_now = osip_getsystemtime(NULL);
    //     printf("%d\n", (int)time_now);
    //     vTaskDelay(1000/portTICK_PERIOD_MS);
    // }
    net_config();
    audio_init();
    console_init();
#if 1
    session_global_init();
    session_register(session);
    // bind_key(34, 0, call0, hold_on_0);
    bind_key(36, 1, call1, hold_on_0);
    bind_key(39, 2, call2, hold_on_0);
#endif
    // vTaskDelay(5000/portTICK_PERIOD_MS);
    // udp_console_init();
    // session_main();
}

void session_main__(void *param)
{
    eXosip_event_t *event = NULL;
    osip_message_t *answer;
    osip_body_t *body;
    while (1)
    {
        event = eXosip_event_wait(session->eXosip, 1, 0);
        if (event == NULL) {
            continue;
        }
        // printf("%d  %x\n", event->type, event->type);
        switch (event->type) {
            default:
            printf("unknow\n");
            break;
            case EXOSIP_REGISTRATION_NEW:
                // printf("received new registration\n");
                break;
            case EXOSIP_REGISTRATION_SUCCESS:
                    printf("registrered successfully\n");
                    eXosip_register_remove(session->eXosip, session->user.rid);
                if (session->status == SESSION_UNREGISTER) {
                    session->status = SESSION_REGISTERED;
                }
                break;
            case EXOSIP_REGISTRATION_FAILURE:
                if ( session->status == SESSION_UNREGISTER) {
                    vTaskDelay(20/portTICK_PERIOD_MS);
                    eXosip_add_authentication_info(session->eXosip, session->user.uname, session->user.uname, session->user.passwd, NULL, NULL);
                    eXosip_register_build_register(session->eXosip, session->user.rid, 1800, &(session->user.reg));
                    eXosip_lock(session->eXosip);
                    eXosip_register_send_register(session->eXosip, session->user.rid, session->user.reg);
                    eXosip_unlock(session->eXosip);
                }
                break;
            case EXOSIP_REGISTRATION_TERMINATED:
                break;
            case EXOSIP_CALL_INVITE:
                printf("INVITE\n");
                break;
        }
        eXosip_event_free(event);
    }
    vTaskDelete(NULL);
}

/*
#include "driver/ledc.h"
#include "soc/ledc_struct.h"

uint32_t timer_tick(void)
{
    uint32_t val = LEDC.timer_group[0].timer[0].value.timer_cnt/1000;
    return val;
}

static void sys_timer_init(void)
{
    ledc_timer_config_t ledc_timer = {
        .duty_resolution = LEDC_TIMER_13_BIT,
        .freq_hz = 5000,
        .speed_mode = 0,
        .timer_num = 0,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ledc_timer_config(&ledc_timer);
    LEDC.timer_group[0].timer[0].conf.pause = 1;
    LEDC.timer_group[0].timer[0].conf.duty_resolution = 18;
    LEDC.timer_group[0].timer[0].conf.clock_divider = (1000<<8);
    LEDC.timer_group[0].timer[0].conf.tick_sel = 0;
    LEDC.timer_group[0].timer[0].conf.rst = 1;
    LEDC.timer_group[0].timer[0].conf.rst = 0;
    LEDC.timer_group[0].timer[0].conf.pause = 0;
}

#include "driver/timer.h"
uint32_t timer_tick(void)
{
    uint64_t timer_v;
    timer_get_counter_value(TIMER_GROUP_0, TIMER_0, &timer_v);
    return (uint32_t)timer_v;
}

static void sys_timer_init(void)
{
    timer_config_t config = {
        .divider = 40000,
        .counter_dir = TIMER_COUNT_UP,
        .counter_en = TIMER_PAUSE,
        .alarm_en = TIMER_ALARM_DIS,
        .auto_reload = 1,
    };
    timer_init(TIMER_GROUP_0, TIMER_0, &config);
    timer_set_counter_value(TIMER_GROUP_0, TIMER_0, 0);
    timer_start(TIMER_GROUP_0, TIMER_0);
}
*/

