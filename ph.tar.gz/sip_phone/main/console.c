#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

char *console = NULL;

int get_input(char *buf)
{
    int ch = 0xff;
    static int len = 0;
    int ret_len = 0;
    while (1) {
        ch = getchar() & 0xff;
        if (ch == 0xff) {
            break;
        }
        if (ch == '\r' || ch == '\n') {
            ret_len = len;
            len = 0;
            break;
        }
        buf[len++] = ch;
    }
    return ret_len;
}

int get_net_type(void);
void wifi_scan(void);
void wifi_connect(char *ssid, char* passwd);
void call_someone(const char* dst_name);
void call_terminate(void);
void prase_cmd(char *str)
{
    char *p = NULL;
    p = strtok(str, " ");
    printf("%s\n", p);
    if (0 == strcmp(p, "call")) {
        p = strtok(NULL, " ");
        if (!p) {
            printf("please specify the call name\n");
        } else {      
            call_someone(p);
        }
    } else if (0 == strcmp(p, "scan") && get_net_type() == 2) {
        printf("wifi scan\n");
        wifi_scan();
    } else if (0 == strcmp(p, "connect") && get_net_type() == 2) {
        printf("connct wifi\n");
        char *ssid = strtok(NULL, " ");
        char *passwd = strtok(NULL, " ");
        wifi_connect(ssid,passwd);
    } else if (0 == strcmp(p, "hangup")) {
        printf("hanup");
        call_terminate();
    } else if (0 == strcmp(p, "setip")) {
        printf("setip\n");
    }
}

void console_task(void *param)
{
    int len = 0;
    while (1) {
        memset(console, 0, 512);
        len = get_input(console);
        if (len > 0) {
            prase_cmd(console);
        }
        vTaskDelay(50/portTICK_PERIOD_MS);
    }
}

void console_init(void)
{
    console = (char *)heap_caps_calloc(1, 512, MALLOC_CAP_SPIRAM);
    if (!console) {
        printf("console malloc fail\n");
        return;
    }
    xTaskCreatePinnedToCore(console_task, "console_task", 1024*5, NULL, 5, NULL, 1);
}

int console_udp_init(void)
{
    return 1;
}

#if 0
#define M_HEADER 0xAA55

enum {
    CMD_BORDASE_CTL    = 0x1,
    CMD_AUDIO_TRANS    = 0x2,
    CMD_FILE_TRANS     = 0x3,
    CMD_PARAM_SET      = 0x4,
    CMD_PARAM_SET_ACK  = 0x5,
    CMD_STATUS_REPORT  = 0x6,
};

typedef struct {
    uint16_t M_Head;
    uint8_t M_CRC;
} Mpacket_t;

typedef struct {
    uint16_t M_Head;
    uint16_t M_Len;
    uint8_t M_Type;
    uint8_t M_Body[255];
    uint8_t M_CRC;
} Mpayload_t;

int uart_console(void *contex, void *packet)
{
    return 0;
}

int exec_cmd(console_contex_t *contex, int id)
{
    if (!contex) return -1;
    console_contex_t *contex = (console_contex_t*)contex;
    if (!contex->cb) return -1;
    // contex->cb[id]();
    return 0;
}

int console_register_cb(console_contex_t *contex, int idx, console_cb_t cb)
{
    if (!contex || idx > CONSOLE_CB_MAX) return -1;
    console_contex_t *contex = (console_contex_t*)contex;
    contex->cb[idx] = cb;
    return 0;
}

// int console_unregister_cb(console_contex_t *contex, int idx, console_cb_t cb)
// {
//     if (!contex || idx > CONSOLE_CB_MAX) return -1;
//     console_contex_t *contex = (console_contex_t*)contex;
//     contex->cb[idx] = NULL;
//     return 0;
// }

#define MSG_UNPARSWE     1
#define MSG_HEAD_PARSED  2
#define MSG_LEN_PARSED   3
#define MSG_TYPE_PARSED  4
#define MSG_BODEY_PARSED 5
#define MSG_CRC_PARSED   6

static int parse_message(uint8_t *buff, int len)
{
    uint8_t* pbuf = buff;
    int plen = len;
    static int prased_sta = 0;
    //parse M_header
    if (prased_sta == MSG_UNPARSWE) {
        if (plen < 4) {
            return 0;
        }
        while (1) {
            if (pbuf[0] && pbuf[1] && pbuf[2] && pbuf[3]) {
                pbuf += 4;
                plen-=4;
                prased_sta = MSG_HEAD_PARSED;
                break;
            } else {
                pbuf++;
                plen--;
            }
        }
        if (prased_sta != MSG_HEAD_PARSED) {
            return 0;
        }
    }
    //parse M_len
    if (prased_sta == MSG_HEAD_PARSED) {
        if (plen < 2) {
            return 0;
        }
        int len = (pbuf[0] << 8) | pbuf[1];
        if (len > 1024) {
            return 0;
        }
        pbuf += 2;
        plen -= 2;
        prased_sta = MSG_LEN_PARSED;
    }
    //parse M_type
    if (prased_sta == MSG_LEN_PARSED) {
        if (plen < 1) {
            return 0;
        }
        int type = pbuf[0];
        if (type > 256) {
            return 0;
        }
        pbuf++;
        plen--;
        prased_sta = MSG_TYPE_PARSED;
    }
   //parse M_body
    if (prased_sta == MSG_TYPE_PARSED) {
        int prased_le;
        for (int i = 0; i < plen; i++) {
            mpbu[i] = pbuf[i];
        }
        if (prased_le == len) {
            prased_sta = MSG_BODEY_PARSED;
        } else if (prased_le < len) {
            return 0;
        }
    }
    //parse M_CRC 
    if (prased_sta == MSG_BODEY_PARSED) {
        if (plen < 1) {
            return 0;
        }
        int crc = pbuf[0];
        prased_sta = MSG_CRC_PARSED;
    }
    if (prased_sta == MSG_CRC_PARSED) {
        prased_sta = MSG_UNPARSWE;
    }
    return 1;
}

Mpayload_t *console_wait_packet(void)
{
    Mpayload_t *m = NULL;
    int stash_len
    int rd_len;
    while(1) {
        rd_len = uart_read_bytes(0, data, can_read_len, (portTICK_PERIOD_MS)100);
        parse_message();
    }
    return m;
}

void console_task(void *param)
{
#define MAX_RD_LEN  (300)
    int rd_len = 0;
    int can_read_len = MAX_RD_LEN;
    uint8_t *data = (uint8_t *)malloc(MAX_RD_LEN);
    Mpayload_t *m = (Mpayload_t *)malloc(sizeof(Mpayload_t));
    int ret;
    while(1) {
        if (rd_len <= 0) {
            rd_len = uart_read_bytes(0, data, can_read_len, (portTICK_PERIOD_MS)50);
            if (rd_len <= 0) continue;
        }
        ret = parse_message(data, data, rd_len);
        if (ret == 1) {
            exec_cmd();
        }
    }
}

void console_init(void)
{
    ;
}

#endif