#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include "lwip/err.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"
#include "audio.h"

int udp_console_init_(void)
{
    int sock;
    int opt = 1;
    socklen_t addr_len;
    struct sockaddr_in peer_addr;
    peer_addr.sin_family = AF_INET;
    peer_addr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    peer_addr.sin_port = htons(8000);
    addr_len = sizeof(struct sockaddr_in);
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        printf("socket init fail\n");
    }
    int err = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt));
    if (err < 0) {
        printf("set ops fail\n");
    }
    char msg[100] = "hello world";
    while(1) {
        sendto(sock, msg, 11, 0, (struct sockaddr *)&peer_addr, addr_len);
        vTaskDelay(1000/portTICK_PERIOD_MS);
    }
    return 0;
}

int udp_console_init2(void)
{
    int sock;
    int opt = 1;
    socklen_t addr_len, dst_addr_len;
    struct sockaddr_in peer_addr, dest_addr;

    memset(&peer_addr, 0, sizeof(peer_addr));
    memset(&dest_addr, 0, sizeof(dest_addr));

    peer_addr.sin_family = AF_INET;
    peer_addr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    peer_addr.sin_port = htons(8000);
    addr_len = sizeof(struct sockaddr_in);
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        printf("socket init fail\n");
    }
    int err = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt));
    if (err < 0) {
        printf("set ops fail\n");
    }
    char msg[100] = "hello world";
    sendto(sock, msg, 11, 0, (struct sockaddr *)&peer_addr, addr_len);
    int len;
    while(1) {
    	printf("recv\n");
        memset(msg, 0, 100);
        len = recvfrom(sock, msg, sizeof(msg), 0, (struct sockaddr *)&dest_addr, &dst_addr_len);
        printf("%s\n", msg);
    }
    return 0;
}

// int udp_console_init(void)
// {
//      int socketfd;
//     struct sockaddr_in own_addr, dest_addr;
//     int err = -1;
//     int opt = 1;
//     char buf[]= "BROADCAST TEST DATA";
//     char group[4][16]= {
//         "224.0.0.88",
//         "224.0.0.87",
//         "224.0.0.86",
//         "224.0.0.85",
//     };
//     memset(&own_addr, 0, sizeof(own_addr));
//     memset(&dest_addr, 0, sizeof(dest_addr));
//     own_addr.sin_family = AF_INET;
//     own_addr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
//     own_addr.sin_port = htons(8000);
//     socklen_t addr_len;
//     socketfd = socket(AF_INET, SOCK_DGRAM, 0);
//     if (socketfd < 0) {
//         printf("sock\net");
//         exit(1);
//     }
//     err = setsockopt(socketfd, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt));
//     int ret = bind(socketfd, (struct sockaddr*)&own_addr, sizeof(struct sockaddr_in));
//     if (ret < 0) {
//         printf("bind\n");
//     }
//     char recv_msg[320];
//     // char recv_msg2[320];
//     while(1) 
//     {
//     	// printf("recv\n");
//         memset(recv_msg, 0, 320);
//         int len = recvfrom(socketfd, recv_msg, sizeof(recv_msg), 0, (struct sockaddr *)&dest_addr, &addr_len);
//         audio_ch_swap_16(recv_msg, len>0 ? len : 0);
//         audio_write((uint8_t*)recv_msg, len>0 ? len : 0, 100);
//         // printf("%s\n", recv_msg);
//     }
// }


int udp_console_init(void)
{
    int socketfd;
    struct sockaddr_in own_addr;
    int err = -1;
    int opt = 1;
    memset(&own_addr, 0, sizeof(own_addr));
    own_addr.sin_family = AF_INET;
    own_addr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    own_addr.sin_port = htons(8000);
    socketfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (socketfd < 0) {
        printf("sock\net");
        return -1;
    }
    err = setsockopt(socketfd, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt));
    err = bind(socketfd, (struct sockaddr*)&own_addr, sizeof(struct sockaddr_in));
    if (err < 0) {
        // printf("bind\n");
        close(socketfd);
        return -1;
    }
    return 0;
}