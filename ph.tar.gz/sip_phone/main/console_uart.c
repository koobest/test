#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "string.h"
#include "driver/uart.h"

typedef struct {
#define MAX_PAYLOAD_SIZE   (512)
#define MAX_PACKET_SIZE    (MAX_PAYLOAD_SIZE+6)
#define M_HD0  (0xaa)
#define M_HD1  (0xbb)
#define M_HD2  (0xcc)
#define M_HD3  (0xdd)
#define M_HEAD(b0,b1,b2,b3) ((b0)<<24) | ((b1) << 16) | ((b2) <<8) | (b3)
    uint32_t M_Head;
#define M_LEM(b0,b1) ((b0) << 8 | (b1))
    uint16_t M_Len;
    uint8_t M_Type;
    uint8_t M_Body[MAX_PAYLOAD_SIZE];
    uint8_t M_CRC;
} Mpayload_t;

typedef struct {
    Mpayload_t Mpayload;
#define MSG_UNPARSWE     0
#define MSG_HEAD_PARSED  1
#define MSG_LEN_PARSED   2
#define MSG_TYPE_PARSED  3
#define MSG_BODEY_PARSED 4
#define MSG_CRC_PARSED   5
    uint16_t prased_sta;
    uint16_t idx;
} Mpacket_t;

Mpayload_t *new_mpacket(void)
{
    Mpacket_t *p = (Mpacket_t *)malloc(sizeof(Mpacket_t));
    if (p) memset(p, 0, sizeof(Mpacket_t));
    return (Mpayload_t *)p;
}

void del_mpacket(void *p)
{
    if (p) free(p);
}

static int parse_message(Mpacket_t *parse, uint8_t *buff, int len)
{
    uint8_t* pbuf = buff;
    int plen = len;
    //parse M_header
    if (parse->prased_sta == MSG_UNPARSWE) {
        if (plen < 4) {
            return plen;
        }
        do {            
            if (pbuf[0] == M_HD0 && pbuf[1] == M_HD1 && pbuf[2] == M_HD2 && pbuf[3] == M_HD3) {
                parse->Mpayload.M_Head = M_HEAD(pbuf[0],pbuf[1],pbuf[2],pbuf[3]);
                parse->prased_sta = MSG_HEAD_PARSED;
                parse->idx = 0;
                pbuf += 4;
                plen -= 4;
                break;
            } else {
                pbuf++;
                plen--;
            }
        } while (plen-3 > 0);
        if (parse->prased_sta != MSG_HEAD_PARSED) {
            return plen;
        }
    }
    //parse M_len
    if (parse->prased_sta == MSG_HEAD_PARSED) {
        if (plen < 2) {
            return plen;
        }
        parse->Mpayload.M_Len = (pbuf[0] - '0') * 10 + pbuf[1]-'0';//M_LEM(pbuf[0],pbuf[1]);
        if (parse->Mpayload.M_Len > MAX_PAYLOAD_SIZE) {
            parse->prased_sta = MSG_UNPARSWE;
            printf("M_Len error: %d\n", parse->Mpayload.M_Len);
            //Invalid frame
            return 0;
        }
        pbuf += 2;
        plen -= 2;
        parse->prased_sta = MSG_LEN_PARSED;
    }
    //parse M_type
    if (parse->prased_sta == MSG_LEN_PARSED) {
        if (plen < 1) {
            return plen;
        }
        parse->Mpayload.M_Type = *pbuf++;
        pbuf++;
        plen--;
        parse->prased_sta = MSG_TYPE_PARSED;
    }
   //parse M_body 10
    if (parse->prased_sta == MSG_TYPE_PARSED) {
        while (plen && parse->idx < parse->Mpayload.M_Len) {
            parse->Mpayload.M_Body[parse->idx] = *pbuf++;
            plen--;
            parse->idx++;
        }
        if (parse->idx == parse->Mpayload.M_Len) {
            parse->prased_sta = MSG_BODEY_PARSED;
        } else if (parse->idx < parse->Mpayload.M_Len) {
            return plen;
        }
    }
    //parse M_CRC 
    if (parse->prased_sta == MSG_BODEY_PARSED) {
        if (plen < 1) {
            return plen;
        }
        parse->Mpayload.M_CRC = pbuf[0];
        parse->prased_sta = MSG_CRC_PARSED;
        plen--;
    }
    return plen;
}

static int read_msg_poll(uint8_t *buf, size_t max_size)
{
    int rd_len = 0;
    do {        
        rd_len = uart_read_bytes(1, buf, max_size, 40/portTICK_PERIOD_MS);
    } while (rd_len <= 0);
    return rd_len;
}

typedef struct console_contex console_contex_t;

typedef struct console_contex {
    uint8_t tmp[MAX_PACKET_SIZE];
    uint8_t *read_addr;
    uint8_t *parse_addr;
    int fd;
    int (*open)(console_contex_t *);
    int (*read)(console_contex_t *);
    int (*write)(console_contex_t *);
    void (*close)(console_contex_t *);
    Mpayload_t *(*parse)(console_contex_t *);
} console_contex_t;

Mpayload_t *console_wait_packet(console_contex_t *ctx)
{
    int left = 0;
    int rd_len = 0;
    int parse_len = 0;
    Mpacket_t *m = (Mpacket_t *)new_mpacket();
    if (!m) {
        return NULL;
    }
    uint8_t *r_end = ctx->tmp + MAX_PACKET_SIZE;
    while (m->prased_sta != MSG_CRC_PARSED) {
        rd_len = read_msg_poll(ctx->read_addr, r_end - ctx->read_addr);
        parse_len = rd_len + ctx->read_addr - ctx->parse_addr;
        left = parse_message(m, ctx->parse_addr, parse_len);
        if (left <= 0) {
            ctx->read_addr = ctx->tmp;
            ctx->parse_addr = ctx->tmp;
        } else {
            ctx->read_addr = ctx->read_addr + rd_len;
            ctx->parse_addr = ctx->parse_addr + parse_len - left;
        }
    }
    return (Mpayload_t *)m;
}

// void exec_cmd(Mpayload_t *m)
// {
//     printf("parse packet:\n");
//     printf("HEAD: %x\n", m->M_Head);
//     printf("Len: %d\n", m->M_Len);
//     printf("Type: %c\n", m->M_Type);
//     for (int i = 0; i < m->M_Len; i++) {
//         printf("%c",m->M_Body[i]);
//     }
//     printf("\n");
//     printf("CRC: %c\n", m->M_CRC);
//     char buf[] = "ACK\r\n";
//     if (m->M_Type) uart_write_bytes(1, buf, sizeof(buf));
// }
enum {
    CMD_BORDASE_CTL    = 0x1,
    CMD_AUDIO_TRANS    = 0x2,
    CMD_FILE_TRANS     = 0x3,
    CMD_PARAM_SET      = 0x4,
    CMD_PARAM_SET_ACK  = 0x5,
    CMD_STATUS_REPORT  = 0x6,
};

void exec_cmd(Mpayload_t *m)
{
    switch(m->M_Type) {
        case CMD_BORDASE_CTL: {
            switch (m->M_Body[0]) {
                case 0x1:
                    printf("play cmd: %d\n", m->M_Body[1]);
                break;
                case 0x2:
                    printf("set volum: %d\n", m->M_Body[1]);
                break;
                case 0x3:
                    printf("sound type: %d\n", m->M_Body[1]);
                break;
                case 0x4:
                    printf("split: %d\n", m->M_Body[1]);
                break;
                default:
                break;
            }
        }
        break;
        case CMD_AUDIO_TRANS:
            printf("frame: %d\n", m->M_Body[0]);
        break;
        case CMD_FILE_TRANS:
            printf("trans file: %d\n", m->M_Body[0]);
        break;
        case CMD_PARAM_SET:
            switch (m->M_Body[0]) {
                case 0x1:
                    printf("set ip: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
                break;
                case 0x2:
                    printf("set port: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
                break;
                case 0x3:
                    printf("ip mask: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
                break;
                case 0x4:
                    printf("phone no: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
                break;
                default:
                break;
            }
        break;
        case CMD_PARAM_SET_ACK:
            switch (m->M_Body[0]) {
                case 0x1:
                    printf("param set: %d\n", m->M_Body[1]);
                break;
                default:
                break;
            }
        break;
        case CMD_STATUS_REPORT:
            switch (m->M_Body[0]) {
                case 0x1:
                    printf("set ip: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
                break;
                case 0x2:
                    printf("set port: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
                break;
                case 0x3:
                    printf("ip mask: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
                break;
                case 0x4:
                    printf("phone no: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
                break;
                default:
                break;
            }
        break;
        default:
        break;
    }
}

static void console_port_uart_init(void)
{
    uart_config_t uart_config = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity    = 0,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    int intr_alloc_flags = 0;
    uart_driver_install(1, 1024 * 2, 0, 0, NULL, intr_alloc_flags);
    uart_param_config(1, &uart_config);
    uart_set_pin(1, 26, 27, -1, -1);
}


void _app_main(void *param)
{
    Mpayload_t *m;
    console_contex_t* ctx = malloc(sizeof(console_contex_t));
    ctx->read_addr = ctx->tmp;
    ctx->parse_addr = ctx->tmp;
    console_port_uart_init();
    while (1) {
        m = console_wait_packet(ctx);
        if (m) {
            exec_cmd(m);
            del_mpacket(m);
        }
    }
}