#ifndef __RTP_H__
#define __RTP_H__

#define RTP_MAX_PKT_SIZE (1400)

typedef struct {
#define RTP_HDR_SIZE  (12)
    uint8_t csrc:4;
    uint8_t extension:1;
    uint8_t padding:1;
    uint8_t version:2;
    uint8_t payload:7;
    uint8_t marker:1;
    uint16_t seq;
    uint32_t ts;
    uint32_t ssrc;
    uint8_t  buf[1];
} rtp_hdr_t;

// typedef struct {
// #define RTP_HDR_SIZE  (12)
//     uint8_t  version_p_x_cc;
//     uint8_t  m_pt;
//     uint16_t sequence_number;
//     uint32_t timestamp;
//     uint16_t ssrc;
//     uint16_t csrc;
//     uint8_t  buf[0];
// } rtp_hdr_t;
typedef struct _rtp_sink rtp_sink_t;

struct _rtp_sink {
    rtp_hdr_t *pket;
    int (*rtp_send)(rtp_sink_t *rtp_sink, uint8_t *pr, size_t size);
    int (*rtp_recv)(rtp_sink_t *rtp_sink, uint8_t *ptr, size_t size);
    int (*rtcp_send)(rtp_sink_t *rtp_sink, uint8_t *pr, size_t size);
    int (*rtcp_recv)(rtp_sink_t *rtp_sink, uint8_t *ptr, size_t size);
    int (*rtp_init_port_socket)(rtp_sink_t *rtp_sink, int port[2], int ip[2]);
    void (*rtp_socket_active)(rtp_sink_t *rtp_sink);
    void (*rtp_socket_close)(rtp_sink_t *rtp_sink);
    int tx_size;
    uint32_t time_stamp;
    uint32_t seq_num;
    int marker;
    int sample_rate;
    int ptime;
    uint8_t buffer[RTP_MAX_PKT_SIZE+2];
    void *rtp_sink_contex;
    int active;
};

void rtp_sink_set_protol(rtp_sink_t *rtp, char *protol);

void rtp_prase_sdp(rtp_sink_t *rtp, char *attr, char *val);

rtp_sink_t *rtp_sink_alloc(void);

#endif