#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

char *console = NULL;

int get_input(char *buf)
{
    int ch = 0xff;
    static int len = 0;
    int ret_len = 0;
    while (1) {
        ch = getchar() & 0xff;
        if (ch == 0xff) {
            break;
        }
        if (ch == '\r' || ch == '\n') {
            ret_len = len;
            len = 0;
            break;
        }
        buf[len++] = ch;
    }
    return ret_len;
}

void wifi_scan(void);
void wifi_connect(char *ssid, char* passwd);
void call_someone(const char* dst_name);

void prase_cmd(char *str)
{
	char *p = NULL;
    p = strtok(str, " ");
    printf("%s\n", p);
    if (0 == strcmp(p, "call")) {
    	p = strtok(NULL, " ");
        if (!p) {
            printf("please specify the call name\n");
        } else {      
            call_someone(p);
        }
    } else if (0 == strcmp(p, "scan")) {
        printf("wifi scan\n");
        wifi_scan();
    } else if (0 == strcmp(p, "connect")) {
        printf("connct wifi\n");
        char *ssid = strtok(NULL, " ");
        char *passwd = strtok(NULL, " ");
        wifi_connect(ssid,passwd);
    } else if (0 == strcmp(p, "hangup")) {
        printf("hanup");
    } else if (0 == strcmp(p, "setip")) {
        printf("setip\n");
    }
}

void console_task(void *param)
{
	int len = 0;
    while (1) {
        memset(console, 0, 512);
        len = get_input(console);
        if (len > 0) {
            prase_cmd(console);
        }
        vTaskDelay(50/portTICK_PERIOD_MS);
    }
}

void console_init(void)
{
    console = (char *)malloc(512);
    if (!console) printf("console malloc fail\n");
    xTaskCreate(console_task, "console_task", 1024*8, NULL, 5, NULL);
}
