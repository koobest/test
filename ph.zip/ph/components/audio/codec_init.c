/* Hello World Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s.h"
#include "es7210.h"

#define I2S_NUM 1


esp_err_t i2s_mclk_gpio_select(i2s_port_t i2s_num, gpio_num_t gpio_num)
{
    if (i2s_num >= I2S_NUM_MAX) {
        printf("Does not support i2s number(%d)", i2s_num);
        return ESP_ERR_INVALID_ARG;
    }
    if (gpio_num != GPIO_NUM_0 && gpio_num != GPIO_NUM_1 && gpio_num != GPIO_NUM_3) {
        printf("Only support GPIO0/GPIO1/GPIO3, gpio_num:%d", gpio_num);
        return ESP_ERR_INVALID_ARG;
    }
    printf("I2S%d, MCLK output by GPIO%d", i2s_num, gpio_num);
    if (i2s_num == I2S_NUM_0) {
        if (gpio_num == GPIO_NUM_0) {
            PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO0_U, FUNC_GPIO0_CLK_OUT1);
            WRITE_PERI_REG(PIN_CTRL, 0xFFF0);
        } else if (gpio_num == GPIO_NUM_1) {
            PIN_FUNC_SELECT(PERIPHS_IO_MUX_U0TXD_U, FUNC_U0TXD_CLK_OUT3);
            WRITE_PERI_REG(PIN_CTRL, 0xF0F0);
        } else {
            PIN_FUNC_SELECT(PERIPHS_IO_MUX_U0RXD_U, FUNC_U0RXD_CLK_OUT2);
            WRITE_PERI_REG(PIN_CTRL, 0xFF00);
        }
    } else if (i2s_num == I2S_NUM_1) {
        if (gpio_num == GPIO_NUM_0) {
            PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO0_U, FUNC_GPIO0_CLK_OUT1);
            WRITE_PERI_REG(PIN_CTRL, 0xFFFF);
        } else if (gpio_num == GPIO_NUM_1) {
            PIN_FUNC_SELECT(PERIPHS_IO_MUX_U0TXD_U, FUNC_U0TXD_CLK_OUT3);
            WRITE_PERI_REG(PIN_CTRL, 0xF0FF);
        } else {
            PIN_FUNC_SELECT(PERIPHS_IO_MUX_U0RXD_U, FUNC_U0RXD_CLK_OUT2);
            WRITE_PERI_REG(PIN_CTRL, 0xFF0F);
        }
    }
    return ESP_OK;
}

void i2s_mclK_matrix_out(int i2s_num, int io_num)
{
    i2s_mclk_gpio_select(0, 3);
    return;
#include "driver/gpio.h"
#include "esp_rom_gpio.h"
    PIN_FUNC_SELECT(GPIO_PIN_MUX_REG[io_num], PIN_FUNC_GPIO);
    gpio_set_direction(io_num, GPIO_MODE_OUTPUT);
    esp_rom_gpio_connect_out_signal(io_num, i2s_num == 0 ? 23 : 21, 0, 0);
}

void i2s1_if_init(void)
{
    i2s_config_t i2s_config = {
        .param_cfg = {
            .mode = I2S_MODE_MASTER | I2S_MODE_RX,
            .sample_rate = 16000,
            .communication_format = I2S_COMM_FORMAT_STAND_I2S,
            .slot_bits_cfg = (I2S_BITS_PER_SLOT_16BIT << SLOT_BIT_SHIFT) | I2S_BITS_PER_SAMPLE_16BIT,
            .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
#if SOC_I2S_SUPPORTS_TDM
            .slot_channel_cfg = (4 << SLOT_CH_SHIFT) | 2,
            .active_slot_mask = I2S_TDM_ACTIVE_CH0 | I2S_TDM_ACTIVE_CH0,
            .left_align_en = false,
            .big_edin_en = false,
            .bit_order_msb_en = false,
#endif
        },
        .dma_buf_count = 8,
        .dma_buf_len = 160,
        .use_apll = false,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = 10,
        .ws_io_num = 9,
        .data_in_num = 11,
        .data_out_num = -1,
    };
    i2s_driver_install(I2S_NUM, &i2s_config, 0, NULL);
    i2s_set_pin(I2S_NUM, &pin_config);
    i2s_mclK_matrix_out(I2S_NUM, 20);
}

void i2s0_if_init(void)
{
    i2s_config_t i2s_config = {
        .param_cfg = {
            .mode = I2S_MODE_MASTER | I2S_MODE_TX,
            .sample_rate = 16000,
            .communication_format = I2S_COMM_FORMAT_STAND_MSB,
            .slot_bits_cfg = (I2S_BITS_PER_SLOT_16BIT << SLOT_BIT_SHIFT) | I2S_BITS_PER_SAMPLE_32BIT,
            .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
#if SOC_I2S_SUPPORTS_TDM
            .slot_channel_cfg = (2 << SLOT_CH_SHIFT) | 2,
            .active_slot_mask = I2S_TDM_ACTIVE_CH0 | I2S_TDM_ACTIVE_CH1,
            .left_align_en = false,
            .big_edin_en = false,
            .bit_order_msb_en = false,
#endif
        },
        .dma_buf_count = 6,
        .dma_buf_len = 320*2,
        .use_apll = false,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = 8,
        .ws_io_num = 9,
        .data_out_num = 10,
        .data_in_num = 11
    };
    i2s_driver_install(0, &i2s_config, 0, NULL);
    i2s_set_pin(0, &pin_config);
    i2s_mclK_matrix_out(0, 12);
}

//I2S
void _app_main(void)
{
    Es7210Config codec = {
        .i2c_port_num = I2C_NUM_0,
        .i2c_cfg = {
            .mode = I2C_MODE_MASTER,
            .sda_io_num = 19,
            .scl_io_num = 20,
            .sda_pullup_en = 1,
            .scl_pullup_en = 1,
            .master.clk_speed = 100000,
        }
    };
    i2s0_if_init();
    i2s1_if_init();
    Es7210Init(&codec);
    uint8_t *buf = malloc(320*8);
    size_t bytes_written;
    while(1) {
        i2s_read(1, buf, 320*2*4, &bytes_written, (TickType_t)1000);
        i2s_write(0, buf, 320*2*4, &bytes_written, (TickType_t)1000);
    }
}

//I2S_PDM

void ___app_main(void)
{
    i2s_config_t i2s_config = {
        .param_cfg = {
            .mode = I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_PDM,
            .sample_rate = 48000,
            .communication_format = I2S_COMM_FORMAT_STAND_MSB,
            .slot_bits_cfg = (I2S_BITS_PER_SLOT_16BIT << SLOT_BIT_SHIFT) | I2S_BITS_PER_SAMPLE_16BIT,
            .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
#if SOC_I2S_SUPPORTS_TDM
            .slot_channel_cfg = (2 << SLOT_CH_SHIFT) | 2,
            .active_slot_mask = I2S_TDM_ACTIVE_CH0 | I2S_TDM_ACTIVE_CH1,
            .left_align_en = false,
            .big_edin_en = false,
            .bit_order_msb_en = false,
#endif
        },
        .dma_buf_count = 6,
        .dma_buf_len = 480*2,
        .use_apll = false,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = -1,
        .ws_io_num = 9,
        .data_out_num = 10,
        .data_in_num = -1
    };
    i2s_driver_install(0, &i2s_config, 0, NULL);
    i2s_set_pin(0, &pin_config);
    size_t bytes_written;
    uint16_t *buf = malloc(320*2*4);
    while(1) {
        i2s_write(0, buf, 320*2*4, &bytes_written, (TickType_t)1000);
    }
}

#include "soc/uart_struct.h"
#include "driver/uart.h"
void uart0_trans(uint8_t *data, int len)
{
    uart_set_baudrate(0, 2000000);
    uint16_t *p1 = (uint16_t *)data;
    int rem = len;
    int fifo_rem = 0;
    uint8_t *p = data;
    while(1) {
        fifo_rem = 128 - UART0.status.txfifo_cnt;
        int tx_len = fifo_rem > rem ? rem : fifo_rem;
        for (int i = 0; i < tx_len; i++) {
            UART0.ahb_fifo.val = *p++;
        }
        rem -= tx_len;
        if (rem == 0) break;
    }
}
void dump_i2s_config(void);

void app_main(void)
{
    Es7210Config codec = {
        .i2c_port_num = I2C_NUM_0,
        .i2c_cfg = {
            .mode = I2C_MODE_MASTER,
            .sda_io_num = 1,
            .scl_io_num = 2,
            .sda_pullup_en = 1,
            .scl_pullup_en = 1,
            .master.clk_speed = 100000,
        }
    };
    i2s1_if_init();
    Es7210Init(&codec);
    uint8_t *pbuf = malloc(320*4);
    size_t read_len;
    int len_rem = 1024*1024*3;
    dump_i2s_config();
    vTaskDelay(4000/portTICK_PERIOD_MS);
    while(1) {
        i2s_read(1, pbuf, 160*4, &read_len, (TickType_t)1000);
        uart0_trans(pbuf, 160*4);
        len_rem -= 160*4;
        if(len_rem < 160*4) break;
    }
}

void dump_i2s_config(void)
{
#include "soc/i2s_struct.h"
#define pI2S (&I2S1)
    printf("rx_reset: %x\n", pI2S->rx_conf.rx_reset);
    printf("rx_fifo_reset: %x\n", pI2S->rx_conf.rx_fifo_reset);
    printf("rx_start: %x\n", pI2S->rx_conf.rx_start);
    printf("rx_slave_mod: %x\n", pI2S->rx_conf.rx_slave_mod);
    printf("rx_mono: %x\n", pI2S->rx_conf.rx_mono);
    printf("rx_big_endian: %x\n", pI2S->rx_conf.rx_big_endian);
    printf("rx_update: %x\n", pI2S->rx_conf.rx_update);
    printf("rx_mono_fst_vld: %x\n", pI2S->rx_conf.rx_mono_fst_vld);
    printf("rx_pcm_conf: %x\n", pI2S->rx_conf.rx_pcm_conf);
    printf("rx_pcm_bypass: %x\n", pI2S->rx_conf.rx_pcm_bypass);
    printf("rx_stop_mode: %x\n", pI2S->rx_conf.rx_stop_mode);
    printf("rx_left_align: %x\n", pI2S->rx_conf.rx_left_align);
    printf("rx_24_fill_en: %x\n", pI2S->rx_conf.rx_24_fill_en);
    printf("rx_ws_idle_pol: %x\n", pI2S->rx_conf.rx_ws_idle_pol);
    printf("rx_bit_order: %x\n", pI2S->rx_conf.rx_bit_order);
    printf("rx_tdm_en: %x\n", pI2S->rx_conf.rx_tdm_en);
    printf("rx_pdm_en: %x\n", pI2S->rx_conf.rx_pdm_en);
    printf("rx_pdm2pcm_en: %x\n", pI2S->rx_conf.rx_pdm2pcm_en);
    printf("rx_sinc_dsr_16_en: %x\n", pI2S->rx_conf.rx_sinc_dsr_16_en);

    printf("rx_tdm_ws_width: %x\n", pI2S->rx_conf1.rx_tdm_ws_width);
    printf("rx_bck_div_num: %x\n", pI2S->rx_conf1.rx_bck_div_num);
    printf("rx_bits_mod: %x\n", pI2S->rx_conf1.rx_bits_mod);
    printf("rx_half_sample_bits: %x\n", pI2S->rx_conf1.rx_half_sample_bits);
    printf("rx_tdm_chan_bits: %x\n", pI2S->rx_conf1.rx_tdm_chan_bits);
    printf("rx_msb_shift: %x\n", pI2S->rx_conf1.rx_msb_shift);

 

    printf("rx_clkm_div_num: %x\n", pI2S->rx_clkm_conf.rx_clkm_div_num);
    printf("rx_clk_active: %x\n", pI2S->rx_clkm_conf.rx_clk_active);
    printf("rx_clk_sel: %x\n", pI2S->rx_clkm_conf.rx_clk_sel);
    printf("mclk_sel: %x\n", pI2S->rx_clkm_conf.mclk_sel);

 

    printf("rx_clkm_div_z: %x\n", pI2S->rx_clkm_div_conf.rx_clkm_div_z);
    printf("rx_clkm_div_y: %x\n", pI2S->rx_clkm_div_conf.rx_clkm_div_y);
    printf("rx_clkm_div_x: %x\n", pI2S->rx_clkm_div_conf.rx_clkm_div_x);
    printf("rx_clkm_div_yn1: %x\n\n", pI2S->rx_clkm_div_conf.rx_clkm_div_yn1);

 

    printf("rx_tdm_ctrl: %x\n\n", pI2S->rx_tdm_ctrl.val);

 

    printf("tx_reset: %x\n", pI2S->tx_conf.tx_reset);
    printf("tx_fifo_reset: %x\n", pI2S->tx_conf.tx_fifo_reset);
    printf("tx_start: %x\n", pI2S->tx_conf.tx_start);
    printf("tx_slave_mod: %x\n", pI2S->tx_conf.tx_slave_mod);
    printf("tx_mono: %x\n", pI2S->tx_conf.tx_mono);
    printf("tx_chan_equal: %x\n", pI2S->tx_conf.tx_chan_equal);
    printf("tx_big_endian: %x\n", pI2S->tx_conf.tx_big_endian);
    printf("tx_update: %x\n", pI2S->tx_conf.tx_update);
    printf("tx_mono_fst_vld: %x\n", pI2S->tx_conf.tx_mono_fst_vld);
    printf("tx_pcm_conf: %x\n", pI2S->tx_conf.tx_pcm_conf);
    printf("tx_pcm_bypass: %x\n", pI2S->tx_conf.tx_pcm_bypass);
    printf("tx_stop_en: %x\n", pI2S->tx_conf.tx_stop_en);
    printf("tx_left_align: %x\n", pI2S->tx_conf.tx_left_align);
    printf("tx_24_fill_en: %x\n", pI2S->tx_conf.tx_24_fill_en);
    printf("tx_ws_idle_pol: %x\n", pI2S->tx_conf.tx_ws_idle_pol);
    printf("tx_bit_order: %x\n", pI2S->tx_conf.tx_bit_order);
    printf("tx_tdm_en: %x\n", pI2S->tx_conf.tx_tdm_en);
    printf("tx_pdm_en: %x\n", pI2S->tx_conf.tx_pdm_en);
    printf("tx_chan_mod: %x\n", pI2S->tx_conf.tx_chan_mod);
    printf("sig_loopback: %x\n", pI2S->tx_conf.sig_loopback);


    printf("tx_tdm_ws_width: %x\n", pI2S->tx_conf1.tx_tdm_ws_width);
    printf("tx_bck_div_num: %x\n", pI2S->tx_conf1.tx_bck_div_num);
    printf("tx_bits_mod: %x\n", pI2S->tx_conf1.tx_bits_mod);
    printf("tx_half_sample_bits: %x\n", pI2S->tx_conf1.tx_half_sample_bits);
    printf("tx_tdm_chan_bits: %x\n", pI2S->tx_conf1.tx_tdm_chan_bits);
    printf("tx_msb_shift: %x\n", pI2S->tx_conf1.tx_msb_shift);
    // printf("tx_bck_no_dly: %x\n", pI2S->tx_conf1.tx_bck_no_dly);

    printf("tx_clkm_div_num: %x\n", pI2S->tx_clkm_conf.tx_clkm_div_num);
    printf("tx_clk_active: %x\n", pI2S->tx_clkm_conf.tx_clk_active);
    printf("tx_clk_sel: %x\n", pI2S->tx_clkm_conf.tx_clk_sel);
    printf("clk_en: %x\n", pI2S->tx_clkm_conf.clk_en);

    printf("tx_clkm_div_z: %x\n", pI2S->tx_clkm_div_conf.tx_clkm_div_z);
    printf("tx_clkm_div_y: %x\n", pI2S->tx_clkm_div_conf.tx_clkm_div_y);
    printf("tx_clkm_div_x: %x\n", pI2S->tx_clkm_div_conf.tx_clkm_div_x);
    printf("tx_clkm_div_yn1: %x\n", pI2S->tx_clkm_div_conf.tx_clkm_div_yn1);

    printf("tx_tdm_ctrl: %x\n\n", pI2S->tx_tdm_ctrl.val);
}