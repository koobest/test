#ifndef __AUDIO_H__
#define __AUDIO_H__
#include <stdio.h>
#include <string.h>

void audio_init(void);

int audio_write(uint8_t *buf, size_t size, int ms_blcok);

int audio_read(uint8_t *buf, size_t size, int ms_blcok);

void audio_ulaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size);

void audio_ulaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size);

void audio_alaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size);

void audio_alaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size);

void audio_ch_swap_16(uint16_t *buf, int size);

void get_audio_by_name(char *name, uint8_t **get, size_t *len);

void audio_stop(void);

#endif