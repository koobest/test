#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parse.h"

static int parse_message2(message_parse_contex_t *parse, uint8_t *buff, int len)
{
    uint8_t* pbuf = buff;
    int plen = len;
    //parse M_header
    if (parse->prased_sta == MSG_UNPARSWE) {
        if (plen < 4) {
            goto out;
        }
        do {            
            if (pbuf[0] == M_HD0 && pbuf[1] == M_HD1 && pbuf[2] == M_HD2 && pbuf[3] == M_HD3) {
                parse->Mpayload->M_Head = M_HEAD(pbuf[0],pbuf[1],pbuf[2],pbuf[3]);
                parse->prased_sta = MSG_HEAD_PARSED;
                parse->idx = 0;
                pbuf += 4;
                plen -= 4;
                break;
            } else {
                pbuf++;
                plen--;
            }
        } while (plen-3 > 0);
        if (parse->prased_sta != MSG_HEAD_PARSED) {
            goto out;
        }
    }
    //parse M_len
    if (parse->prased_sta == MSG_HEAD_PARSED) {
        if (plen < 2) {
            goto out;
        }
        // printf("---  %x %x\n", pbuf[0],pbuf[1]);
        parse->Mpayload->M_Len = M_LEM(pbuf[0],pbuf[1]);//(pbuf[0] - '0') * 10 + pbuf[1]-'0';//M_LEM(pbuf[0],pbuf[1]);
        if (parse->Mpayload->M_Len > MAX_PAYLOAD_SIZE) {
            parse->prased_sta = MSG_UNPARSWE;
            printf("M_Len error: %d\n", parse->Mpayload->M_Len);
            //Invalid frame
            plen = 0;
            goto out;
        }
        pbuf += 2;
        plen -= 2;
        parse->prased_sta = MSG_LEN_PARSED;
    }
    //parse M_type
    if (parse->prased_sta == MSG_LEN_PARSED) {
        if (plen < 1) {
            goto out;
        }
        parse->Mpayload->M_Type = *pbuf++;
        pbuf++;
        plen--;
        parse->prased_sta = MSG_TYPE_PARSED;
    }
   //parse M_body 10
    if (parse->prased_sta == MSG_TYPE_PARSED) {
        while (plen && parse->idx < parse->Mpayload->M_Len-2) {
            parse->Mpayload->M_Body[parse->idx] = *pbuf++;
            plen--;
            parse->idx++;
        }
        if (parse->idx == parse->Mpayload->M_Len-2) {
            parse->prased_sta = MSG_BODEY_PARSED;
        } else if (parse->idx < parse->Mpayload->M_Len-2) {
            goto out;
        }
    }
    //parse M_CRC 
    if (parse->prased_sta == MSG_BODEY_PARSED) {
        if (plen < 1) {
            goto out;
        }
        parse->Mpayload->M_CRC = pbuf[0];
        parse->prased_sta = MSG_CRC_PARSED;
        plen--;
    }
out:
    if (parse->flag) {
        if (parse->prased_sta != MSG_CRC_PARSED) {
            parse->prased_sta = MSG_UNPARSWE;
        }
        plen = 0;
    }
    return plen;
}

static Mpayload_t *new_mpacket(void)
{
    Mpayload_t *p = (Mpayload_t *)malloc(sizeof(Mpayload_t));
    if (p) memset(p, 0, sizeof(Mpayload_t));
    return p;
}

Mpayload_t *wait_packet(message_parse_contex_t *ctx)
{
    int left = 0;
    int rd_len = 0;
    int parse_len = 0;
    Mpayload_t *m = (Mpayload_t *)new_mpacket();
    if (!m) {
        printf("No mem\n");
        return NULL;
    }
    uint8_t *r_end = ctx->tmp + MAX_PACKET_SIZE;
    ctx->Mpayload = m;
    ctx->prased_sta = MSG_UNPARSWE;
    ctx->idx = 0;
    ctx->read_addr = ctx->tmp;
    ctx->parse_addr = ctx->tmp;

    while (ctx->prased_sta != MSG_CRC_PARSED) {
        // rd_len = ctx->stream_ctx.read(ctx->read_addr, r_end - ctx->read_addr);
        rd_len = ctx->stream_ctx.read(ctx->read_addr, r_end - ctx->read_addr);
        // printf("rd len: %d\n", rd_len);
        // read_msg_poll(ctx->read_addr, r_end - ctx->read_addr);
        parse_len = rd_len + ctx->read_addr - ctx->parse_addr;
        left = parse_message2(ctx, ctx->parse_addr, parse_len);
        // if (left <= 0) {
        //     ctx->read_addr = ctx->tmp;
        //     ctx->parse_addr = ctx->tmp;
        // } else {
        //     ctx->read_addr = ctx->read_addr + rd_len;
        //     ctx->parse_addr = ctx->parse_addr + parse_len - left;
        // }
    }
    return (Mpayload_t *)m;
}

void del_mpacket(void *p)
{
    if (p) free(p);
}