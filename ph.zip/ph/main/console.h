#ifndef __CONSOLE_H__
#define __CONSOLE_H__


// #define CONSOLE_CB_MAX 32
// typedef struct console_contex console_contex_t; 
// typedef void (*console_cb_t)(void *console, void *in_param, void **out_param);
// typedef struct {
//     int console_id;
//     console_cb_t cb[CONSOLE_CB_MAX];
// } console_contex_t;
// int console_register_cb(console_contex_t *contex, int id, int idx, console_cb_t cb);
// int console_exec_cb(console_contex_t *contex, int id, int idx);
// int console_unregister_cb(console_contex_t *contex, int id, int idx);

void init_uart_console(void);

void init_udp_parse_ctx(void);

#endif