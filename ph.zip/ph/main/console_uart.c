#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "parse.h"

message_parse_contex_t uart_parse_ctx;

static console_exec_cb_t uart_consol_cb[CMD_MAX];

static int uart_open(void)
{
    uart_config_t uart_config = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity    = 0,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    int intr_alloc_flags = 0;
    uart_driver_install(1, 1024*2, 0, 0, NULL, intr_alloc_flags);
    uart_param_config(1, &uart_config);
    uart_set_pin(1, -1, -1, -1, -1);
    // uart_set_pin(1, 26, 27, -1, -1);
    return 0;
}

static int uart_read_msg(uint8_t *buf, int max_size)
{
    int rd_len = 0;
    do {        
        rd_len = uart_read_bytes(1, buf, max_size, 400/portTICK_PERIOD_MS);
    } while (rd_len <= 0);
    return rd_len;
}

static int uart_write_mesg(uint8_t *buf, int max_size)
{
    return 0;
}

static int uart_deinit(void)
{
    return 0;
}

static int cmd_bordase_ctl_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
            printf("play cmd: %d\n", m->M_Body[1]);
        break;
        case 0x2:
            printf("set volum: %d\n", m->M_Body[1]);
        break;
        case 0x3:
            printf("sound type: %d\n", m->M_Body[1]);
        break;
        case 0x4:
            printf("split: %d\n", m->M_Body[1]);
        break;
        default:
        break;
    }
    return 0;
}

static int cmd_audio_trans_cb(Mpayload_t *m, void *param)
{
    printf("frame: %d\n", m->M_Body[0]);
    return 0;
}

static int cmd_file_trans_cb(Mpayload_t *m, void *param)
{
    printf("trans file: %d\n", m->M_Body[0]);
    return 0;
}

static int cmd_param_set_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
            printf("set ip: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x2:
            printf("set port: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x3:
            printf("ip mask: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x4:
            printf("phone no: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        default:
        break;
    }
    return 0;
}

static int cmd_param_set_ack_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
    case 0x1:
        printf("param set: %d\n", m->M_Body[1]);
    break;
    default:
    break;
    }
    return 0;
}

static int cmd_status_report_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
            printf("set ip: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x2:
            printf("set port: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x3:
            printf("ip mask: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x4:
            printf("phone no: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        default:
        break;
    }
    return 0;
}

void exec_cmd(Mpayload_t *m)
{
    switch(m->M_Type) {
        case CMD_BORDASE_CTL:
        case CMD_AUDIO_TRANS:
        case CMD_FILE_TRANS:
        case CMD_PARAM_SET:
        case CMD_PARAM_SET_ACK:
        case CMD_STATUS_REPORT:
            if (uart_consol_cb[m->M_Type])
            {
                uart_consol_cb[m->M_Type](m, NULL);
            }
        break;
        default:
        break;
    }
}

static void uart_console_task(void *param)
{
    Mpayload_t *m;
    while (1) {
        m = wait_packet(&uart_parse_ctx);
        if (m) {
            exec_cmd(m);
            del_mpacket(m);
        }
    }
}

void init_uart_console(void)
{
    uart_open();
    uart_parse_ctx.stream_ctx.open = uart_open;
    uart_parse_ctx.stream_ctx.read = uart_read_msg;
    uart_parse_ctx.stream_ctx.write = uart_write_mesg;
    uart_parse_ctx.stream_ctx.close = uart_deinit;
    uart_parse_ctx.flag = 0;

    memset(uart_consol_cb, 0, sizeof(uart_consol_cb));
    uart_consol_cb[CMD_BORDASE_CTL] = cmd_bordase_ctl_cb;
    uart_consol_cb[CMD_AUDIO_TRANS] = cmd_audio_trans_cb;
    uart_consol_cb[CMD_FILE_TRANS] = cmd_file_trans_cb;
    uart_consol_cb[CMD_PARAM_SET] = cmd_param_set_cb;
    uart_consol_cb[CMD_PARAM_SET_ACK] = cmd_param_set_ack_cb;
    uart_consol_cb[CMD_STATUS_REPORT] = cmd_status_report_cb;
    xTaskCreatePinnedToCore(uart_console_task, "uart_console_task", 1024*4, NULL, 8, NULL, 1);
}