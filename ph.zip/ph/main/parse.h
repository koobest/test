#ifndef __PARSE_H__
#define __PARSE_H__

typedef struct {
#define MAX_PAYLOAD_SIZE   (512)
#define MAX_PACKET_SIZE    (MAX_PAYLOAD_SIZE+6)
#define M_HD0  (0xaa)
#define M_HD1  (0xbb)
#define M_HD2  (0xcc)
#define M_HD3  (0xdd)
#define M_HEAD(b0,b1,b2,b3) ((b0)<<24) | ((b1) << 16) | ((b2) <<8) | (b3)
    uint32_t M_Head;
#define M_LEM(b0,b1) ((b0) << 8 | (b1))
    uint16_t M_Len;
    uint8_t M_Type;
    uint8_t M_Body[MAX_PAYLOAD_SIZE];
    uint8_t M_CRC;
} Mpayload_t;

typedef struct {
    int (*open)(void);
    int (*read)(uint8_t *buffer, int size);
    int (*write)(uint8_t *buffer, int size);
    int (*close)(void);
} message_stream_contex_t;

typedef struct {
    Mpayload_t *Mpayload;
    message_stream_contex_t stream_ctx;
#define MSG_UNPARSWE     0
#define MSG_HEAD_PARSED  1
#define MSG_LEN_PARSED   2
#define MSG_TYPE_PARSED  3
#define MSG_BODEY_PARSED 4
#define MSG_CRC_PARSED   5
    uint16_t prased_sta;
    uint16_t idx;
    uint8_t tmp[MAX_PACKET_SIZE];
    uint8_t *read_addr;
    uint8_t *parse_addr;
    int flag;
} message_parse_contex_t;

enum {
    CMD_BORDASE_CTL    = 0x1,
    CMD_AUDIO_TRANS    = 0x2,
    CMD_FILE_TRANS     = 0x3,
    CMD_PARAM_SET      = 0x4,
    CMD_PARAM_SET_ACK  = 0x5,
    CMD_STATUS_REPORT  = 0x6,
    CMD_MAX            = 0x7,
};

typedef int (*console_exec_cb_t)(Mpayload_t *m, void *param);

Mpayload_t *wait_packet(message_parse_contex_t *ctx);

void del_mpacket(void *p);
#endif