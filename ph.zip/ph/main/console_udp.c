#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include "lwip/err.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"
#include "parse.h"
#include "audio.h"

message_parse_contex_t udp_parse_ctx;
static console_exec_cb_t udp_consol_cb[CMD_MAX];
int socketfd;

static int udp_open(void)
{
    struct sockaddr_in own_addr;
    int err = -1;
    int opt = 1;
    memset(&own_addr, 0, sizeof(own_addr));
    own_addr.sin_family = AF_INET;
    own_addr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    own_addr.sin_port = htons(8000);
    socketfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (socketfd < 0) {
        printf("sock\net");
        return -1;
    }
    err = setsockopt(socketfd, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt));
    err = bind(socketfd, (struct sockaddr*)&own_addr, sizeof(struct sockaddr_in));
    if (err < 0) {
        // printf("bind\n");
        close(socketfd);
        return -1;
    }
    return 0;
}

static int udp_read(uint8_t *buf, int len)
{
    struct sockaddr_in dest_addr;
    socklen_t addr_len;
    int rxlen = recvfrom(socketfd, buf, len, 0, (struct sockaddr *)&dest_addr, &addr_len);
//         audio_ch_swap_16(recv_msg, len>0 ? len : 0);
//         audio_write((uint8_t*)recv_msg, len>0 ? len : 0, 100);
    return rxlen > 0 ? rxlen : 0;
}

static int udp_write(uint8_t *buf, int len)
{
    return 0;
}


static int udp_close(void)
{
    return 0;
}

static int cmd_bordase_ctl_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
            printf("play cmd: %d\n", m->M_Body[1]);
        break;
        case 0x2:
            printf("set volum: %d\n", m->M_Body[1]);
        break;
        case 0x3:
            printf("sound type: %d\n", m->M_Body[1]);
        break;
        case 0x4:
            printf("split: %d\n", m->M_Body[1]);
        break;
        default:
        break;
    }
    return 0;
}

static int cmd_audio_trans_cb(Mpayload_t *m, void *param)
{
    uint16_t *audio_buf = (uint16_t *)(m->M_Body-1);
    int audio_len = m->M_Len-2;
    // uint8_t *pr = (uint8_t *)audio_buf-1;
    // for (int i = 0; i < audio_len; i++) {
    //     printf("%x ", pr[i]);
    // }
    // printf("\n");
    audio_ch_swap_16(audio_buf, audio_len>0 ? audio_len : 0);
    audio_write((uint8_t*)audio_buf, audio_len>0 ? audio_len : 0, 100);
    // printf("frame len: %d\n", audio_len);
    return 0;
}

static int cmd_file_trans_cb(Mpayload_t *m, void *param)
{
    printf("trans file: %d\n", m->M_Body[0]);
    return 0;
}

static int cmd_param_set_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
            printf("set ip: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x2:
            printf("set port: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x3:
            printf("ip mask: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x4:
            printf("phone no: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        default:
        break;
    }
    return 0;
}

static int cmd_param_set_ack_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
    case 0x1:
        printf("param set: %d\n", m->M_Body[1]);
    break;
    default:
    break;
    }
    return 0;
}

static int cmd_status_report_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
            printf("set ip: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x2:
            printf("set port: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x3:
            printf("ip mask: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x4:
            printf("phone no: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        default:
        break;
    }
    return 0;
}

void exec_cmd(Mpayload_t *m)
{
    switch(m->M_Type) {
        case CMD_BORDASE_CTL:
        case CMD_AUDIO_TRANS:
        case CMD_FILE_TRANS:
        case CMD_PARAM_SET:
        case CMD_PARAM_SET_ACK:
        case CMD_STATUS_REPORT:
            if (udp_consol_cb[m->M_Type])
            {
                udp_consol_cb[m->M_Type](m, NULL);
            }
        break;
        default:
        break;
    }
}

static void udp_console_task(void *param)
{
    Mpayload_t *m;
    while (1) {
        m = wait_packet(&udp_parse_ctx);
        if (m) {
            exec_cmd(m);
            del_mpacket(m);
        }
    }
}

void init_udp_parse_ctx(void)
{
    udp_open();

    udp_parse_ctx.stream_ctx.open = udp_open;
    udp_parse_ctx.stream_ctx.read = udp_read;
    udp_parse_ctx.stream_ctx.write = udp_write;
    udp_parse_ctx.stream_ctx.close = udp_close;
    udp_parse_ctx.flag = 1;

    memset(udp_consol_cb, 0, sizeof(udp_consol_cb));
    udp_consol_cb[CMD_BORDASE_CTL] = cmd_bordase_ctl_cb;
    udp_consol_cb[CMD_AUDIO_TRANS] = cmd_audio_trans_cb;
    udp_consol_cb[CMD_FILE_TRANS] = cmd_file_trans_cb;
    udp_consol_cb[CMD_PARAM_SET] = cmd_param_set_cb;
    udp_consol_cb[CMD_PARAM_SET_ACK] = cmd_param_set_ack_cb;
    udp_consol_cb[CMD_STATUS_REPORT] = cmd_status_report_cb;
    xTaskCreatePinnedToCore(udp_console_task, "udp_console_task", 1024*4, NULL, 8, NULL, 1);
}