#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"

#include "lwip/err.h"
#include "lwip/sys.h"
#include <osip2/osip_mt.h>
#include <eXosip2/eXosip2.h>
// #include <eXosip2/eX_setup.h>

void app_main(void)
{
    // eXosip_event_t *je;
    // osip_message_t *reg = NULL;
    // osip_message_t *invite = NULL;
    // osip_message_t *ack = NULL;
    // osip_message_t *info = NULL;
    // osip_message_t *message = NULL;
    // int call_id, dialog_id;
    // int ret;
    esp_netif_init();
    int ret; 
    struct eXosip_t *excontext = eXosip_malloc();
    ret = eXosip_init(excontext);
    if (ret != 0) {
        printf("init fail\n");
    }
    ret = eXosip_listen_addr(excontext, IPPROTO_UDP, "192.168.0.1", 5061, AF_INET, 0);
    if (ret < 0) {
        printf("listen fail\n");
    }
    printf("init done\n");
}