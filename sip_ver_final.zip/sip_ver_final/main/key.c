#include <stdio.h>
#include "string.h"
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "driver/gpio.h"

static int g_init_flag = 0;
static QueueHandle_t xQueue;

typedef struct {
    int io;
    int key_id;
    int key_stat;
    void (*on_cb)(void);
    void (*off_cb)(void);
} key_ifo_t;

key_ifo_t key_ifo[3];

static void gpio_isr_cb(void *arg)
{
	key_ifo_t *key = (key_ifo_t*)arg;
	portBASE_TYPE high_priority_task_awoken = 0;
	gpio_intr_disable(key->io);
    xQueueSendFromISR(xQueue, (void * )&(key->key_id), &high_priority_task_awoken);
}

static void gpio_task(void*param)
{
    int id;
    TickType_t tick;
    while(1) {
        xQueueReceive(xQueue, &id, (TickType_t)portMAX_DELAY);
        if ( key_ifo[id].key_stat == 0)
        {
            key_ifo[id].on_cb();
            key_ifo[id].key_stat = 1;
            vTaskDelay(100/portTICK_PERIOD_MS);
            gpio_intr_enable(key_ifo[id].io);
            printf("key on\n");
        } else if (key_ifo[id].key_stat == 1)
        {
        	key_ifo[id].off_cb();
            key_ifo[id].key_stat = 0;
            vTaskDelay(100/portTICK_PERIOD_MS);
            gpio_intr_enable(key_ifo[id].io);
            printf("key off %d\n", id);
        }
    }
}

static void gpio_global_init(void)
{
	if (!g_init_flag) {
		xQueue = xQueueCreate(2, sizeof(int));
		xTaskCreate(gpio_task, "gpio_task", 1024*4, NULL, 3, NULL);
		gpio_install_isr_service(0);
		g_init_flag = 1;
	}
}

static void key_gpio_init(int io)
{
	gpio_intr_disable(io);
    gpio_reset_pin(io);
    gpio_set_direction(io, GPIO_MODE_INPUT);
    gpio_set_intr_type(io, GPIO_INTR_POSEDGE);
    gpio_intr_enable(io);
}

void bind_key(int key, int id, void (*on_cb)(void), void (*off_cb)(void))
{
	key_ifo[id].key_id = id;
	key_ifo[id].io = key;
    key_ifo[id].on_cb = on_cb;
    key_ifo[id].off_cb = off_cb;
    key_ifo[id].key_stat = 0;
    gpio_global_init();
    gpio_isr_handler_add(key, gpio_isr_cb, (void *)&key_ifo[id]);
    key_gpio_init(key);
}