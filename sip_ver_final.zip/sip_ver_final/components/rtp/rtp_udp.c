#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include "lwip/err.h"
#include "lwip/sys.h"
#include "rtp.h"

typedef struct {
    rtp_sink_t *rt_sink;
    int rtp_port;
    // int rtcp_fd;
    int rtp_fd;
    int ip;
    struct sockaddr_in  rtp_client;
} rtp_udp_contex_t;


static int rtp_udp_send(rtp_udp_contex_t *contex, uint8_t *buf, size_t size)
{
    int tx_len = -1;
    struct sockaddr_in  rtp_client;

    rtp_client.sin_family = AF_INET;
    rtp_client.sin_port = htons(contex->port);
    rtp_client.sin_addr.s_addr = contex->ip; 
    socklen_t client_len = sizeof(struct sockaddr_in);
    if (!contex || !buf) return tx_len;
    tx_len = sendto(contex->rtp_fd, buf, size, 0, (struct sockaddr *)&rtp_client, client_len);
    return (tx_len == size) ? tx_len : -1;
}

static int rtp_udp_recv(rtp_udp_contex_t *contex, uint8_t *buf, size_t size)
{
    int rx_len = -1;
    struct sockaddr_in  rtp_client;
    socklen_t client_len = sizeof(struct sockaddr_in);
    if (!contex || !buf) return rx_len;
    rx_len = recvfrom(contex->rtp_fd, buf, size, 0, (struct sockaddr *)&rtp_client, &client_len);
    return (rx_len == size) ? rx_len : -1;
}

int init_rtp_udp(void)
{
    ；
}

void rtp_udp_port_active(void)
{
    ;
}

int rtp_udp_init_contex(void)
{
    ;
}