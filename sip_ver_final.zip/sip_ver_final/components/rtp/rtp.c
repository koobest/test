#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "esp_system.h"
#include <netinet/in.h>
#include "rtp.h"

typedef struct {
    uint32_t wd0;
    uint32_t wd1;
    uint32_t wd2;
    uint8_t  buf[0];
} rtp_hdr_t;


uint8_t *rtp_trans_malloc_packet(size_t payload_size)
{
    uint8_t *packet = malloc(sizeof(rtp_hdr_t)+payload_size);
    if (packet == NULL) return NULL;
    memset(packet, 0, sizeof(rtp_hdr_t));
    return packet;
}

void rtp_init_packet_hdr(void *ptr, uint32_t crc, uint32_t type, uint32_t seq, uint32_t time_stramp, uint32_t ssrc)
{
    rtp_hdr_t *hdr = (rtp_hdr_t*)ptr;
    hdr->wd0 = (0x80 | (crc & 0xf)) | ((type<<8) & 0x7f00) | ((seq<<8) & 0xff0000) | ((seq<<24) & 0xff000000);
    hdr->wd1 = ntohl(time_stramp);
    hdr->wd2 = ntohl(ssrc);
}

void rtp_fill_packet(void *ptr, uint8_t *payload, size_t payload_size)
{
    uint32_t *hdr = (uint32_t*)ptr+3;
    memcpy(hdr, payload, payload_size);
}

void rtp_trans_free_packet(void* ptr)
{
    if(ptr) free(ptr);
}

_rtp_hdr_t * rtp_hdr_malloc(void)
{
    _rtp_hdr_t* hdr = malloc(sizeof(_rtp_hdr_t)+RTP_MAX_PKT_SIZE+2);
    if (!hdr) {
        return NULL;
    }
    memset(hdr, 0, sizeof(_rtp_hdr_t)+RTP_MAX_PKT_SIZE+2);
    return hdr;
}

