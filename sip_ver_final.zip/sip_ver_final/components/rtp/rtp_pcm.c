#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "rtp.h"
#include "audio.h"

#define RTP_V  2
#define RTP_P  0
#define RTP_TP 0  //PCM-U

rtp_sink_t *rtp_sink_new_pcm(void)
{
    rtp_sink_t *rtp_sink = (rtp_sink_t *)malloc(sizeof(rtp_sink_t));
    if (!rtp_sink) {
        goto error;
    }
    memset(rtp_sink, 0, sizeof(rtp_sink_t));
    rtp_sink->pket = rtp_hdr_malloc();
   
    if (!rtp_sink->pket) {
        goto error;
    }

    rtp_sink->pket->extension = 0;
    rtp_sink->pket->padding = 0;
    rtp_sink->pket->version = RTP_V;
    rtp_sink->pket->payload = RTP_TP;
    rtp_sink->pket->marker = 1;

    rtp_sink->tx_size = 0;
    rtp_sink->time_stamp = 100;
    rtp_sink->seq_num = 0x55;
    rtp_sink->marker = 1;
    return rtp_sink;
error:
    if (rtp_sink) {
        if (rtp_sink->pket) {
            free(rtp_sink->pket);
        }
        free(rtp_sink);
    }
    return NULL;
}

void rtp_sink_set_sample_rate(rtp_sink_t *rtp, int sample_rate)
{
    if(rtp) {
        rtp->sample_rate = sample_rate;
    }
}

int rtp_sink_tx(rtp_sink_t *rtp, uint8_t *buf, size_t tx_len)
{
    _rtp_hdr_t *hdr = rtp->pket;
    hdr->seq = rtp->seq_num;
    hdr->ts = rtp->time_stamp;
    hdr->marker = rtp->marker;
    memcpy(hdr->buf, buf, tx_len);
    int len = rtp->rtp_send((uint8_t *)hdr, RTP_HDR_SIZE+tx_len);
    rtp->marker = 0;
    rtp->seq_num++;
    rtp->time_stamp += rtp->sample_rate;
    return len;
}

int rtp_sink_rx(rtp_sink_t *rtp, uint8_t *buf, size_t tx_len)
{
    uint8_t *rx = (uint8_t *)malloc(RTP_MAX_PKT_SIZE+2);
    int len = rtp->rtp_recv(rx, RTP_MAX_PKT_SIZE+2);
    _rtp_hdr_t *hdr = (_rtp_hdr_t*)rx;
    if (len > 12) {
        len -= RTP_HDR_SIZE;
        memcpy(buf, rx+RTP_HDR_SIZE, len);
    } else {
        len = 0;
    }
    free(rx);
    return len;
}