#ifndef __RTP_H__
#define __RTP_H__

#define RTP_MAX_PKT_SIZE 1400

typedef struct {
#define RTP_HDR_SIZE  (4)
    uint8_t csrc:4;
    uint8_t extension:1;
    uint8_t padding:1;
    uint8_t version:2;
    uint8_t payload:7;
    uint8_t marker:1;
    uint16_t seq;
    uint32_t ts;
    uint32_t ssrc;
    uint8_t  buf[0];
} _rtp_hdr_t;

typedef struct {
    _rtp_hdr_t *pket;
    int (*rtp_send)(uint8_t *pr, size_t size);
    int (*rtp_recv)(uint8_t *ptr, size_t size);
    int tx_size;
    uint32_t time_stamp;
    uint32_t seq_num;
    int marker;
    int sample_rate;
    // char rtp_ip[32];
    // int rtp_port;
    // int rtcp_fd;
    // int rtp_fd;
    // struct sockaddr_in  rtp_client;
} rtp_sink_t;


rtp_sink_t *rtp_new_instance(void);

void rtp_hdr_dump(void *ptr);
uint8_t *rtp_trans_malloc_packet(size_t payload_size);
void rtp_init_packet_hdr(void *ptr, uint32_t crc, uint32_t type, uint32_t seq, uint32_t time_stramp, uint32_t ssrc);
void rtp_fill_packet(void *ptr, uint8_t *payload, size_t payload_size);
void rtp_trans_free_packet(void* ptr);
_rtp_hdr_t * rtp_hdr_malloc(void);
#endif