#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s.h"
#include "driver/gpio.h"
#include "driver/rmt.h"
#include "es8388.h"
#include "g711.h"


#define SAMPLE_RATE     (8000)
#define I2S_NUM         (0)
#define I2S_MCLK_IO      (14)
#define I2S_BCK_IO      (13)
#define I2S_WS_IO       (2)
#define I2S_DI_IO       (35)
#define I2S_DO_IO       (32)

static void i2s_mclk_out(void)
{
    rmt_item32_t morse_esp[] = {
        {{{ 32767, 1, 32767, 0 }}},
        {{{ 0, 1, 0, 0 }}}
    };
    rmt_config_t config = {
        .rmt_mode = RMT_MODE_TX,                    
        .channel = 0,                      
        .gpio_num = I2S_MCLK_IO,                           
        .clk_div = 80,                              
        .mem_block_num = 1,                         
        .flags = 0,                                 
        .tx_config = {                              
            .carrier_freq_hz = 2048000,
            .carrier_level = RMT_CARRIER_LEVEL_HIGH,
            .idle_level = RMT_IDLE_LEVEL_HIGH,       
            .carrier_duty_percent = 50,             
            .carrier_en = true,                    
            .loop_en = false,                       
            .idle_output_en = true,                 
        }
    };

    rmt_config(&config);
    rmt_driver_install(config.channel, 0, 0);
    rmt_write_items(0, morse_esp, sizeof(morse_esp) / sizeof(morse_esp[0]), 0);
}

static void audio_int_codec(void)
{
    audio_hal_codec_config_t es83xx_init = {
        .adc_input  = AUDIO_HAL_ADC_INPUT_LINE1,
        .dac_output = AUDIO_HAL_DAC_OUTPUT_LINE1,
        .codec_mode = AUDIO_HAL_CODEC_MODE_BOTH,
        .i2s_iface = {
            .mode = AUDIO_HAL_MODE_SLAVE,
            .fmt = AUDIO_HAL_I2S_NORMAL,
            .samples = AUDIO_HAL_08K_SAMPLES,
            .bits = AUDIO_HAL_BIT_LENGTH_16BITS,
        },
    };
    es8388_init(&es83xx_init);
    es8388_config_i2s(es83xx_init.codec_mode, &es83xx_init.i2s_iface);
    es8388_set_voice_volume(50);
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
}

static void audio_init_i2s(void)
{
    i2s_config_t i2s_config = {
        .mode = I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX,
        .sample_rate = SAMPLE_RATE,
        .bits_per_sample = 16,
        .channel_format = I2S_CHANNEL_FMT_ONLY_RIGHT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .dma_buf_count = 8,
        .dma_buf_len = 160,
        .use_apll = false,
        .tx_desc_auto_clear = true,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = I2S_BCK_IO,
        .ws_io_num = I2S_WS_IO,
        .data_out_num = I2S_DO_IO,     
        .data_in_num = I2S_DI_IO,
    };
    i2s_driver_install(I2S_NUM, &i2s_config, 0, NULL);
    i2s_set_pin(I2S_NUM, &pin_config);
    i2s_mclk_out();
}

static RingbufHandle_t rb;

static void audio_task(void *arg)
{
    StaticRingbuffer_t *buffer_struct = (StaticRingbuffer_t *)malloc(sizeof(StaticRingbuffer_t));
    uint8_t *buffer_storage = heap_caps_calloc(1, 1024*18, MALLOC_CAP_SPIRAM);
    if (!buffer_storage) {
        printf("audio buffer alloc fail\n");
        goto out;
    }
    rb = xRingbufferCreateStatic(1024*16, RINGBUF_TYPE_BYTEBUF, buffer_storage, buffer_struct);

    uint8_t *buf = NULL;
    size_t size = 0;
    size_t i2s_bytes_write;

    audio_int_codec();
    audio_init_i2s();

    while(1) {
        buf = xRingbufferReceive(rb, &size, (TickType_t)portMAX_DELAY);
        if (!buf) continue;
        i2s_write(I2S_NUM, buf, size, &i2s_bytes_write, (TickType_t)portMAX_DELAY);
        vRingbufferReturnItem(rb, buf);
    }
out:
    if (buffer_struct) {
        free(buffer_struct);
    }
    if (buffer_storage) {
        free(buffer_storage);
    }
    vTaskDelete(NULL);
}

void audio_init(void)
{
    xTaskCreatePinnedToCore(audio_task, "audio_task", 1024*4, NULL, 4, NULL, 1);
}

void audio_set_vol(int vol)
{
    // es8311_codec_set_voice_volume(vol);
}

int audio_write(uint8_t *buf, size_t size, int ms_blcok)
{
    xRingbufferSend(rb, buf, size, ms_blcok);
    return size;
}

int audio_read(uint8_t *buf, size_t size, int ms_blcok)
{
    size_t i2s_bytes_read = 0;
    i2s_read(I2S_NUM, buf, size, &i2s_bytes_read, ms_blcok);
    return i2s_bytes_read;
}

void audio_ulaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size)
{
    for (int i = 0; i < size/2; i++) {
        buf_ret[i] = esp_g711u_encode(buf[i]);
    }
}

void audio_ulaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size)
{
    for (int i = 0; i < size; i++) {
        buf_ret[i] = esp_g711u_decode(buf[i]);
    }
}

void audio_ch_swap_16(uint16_t *buf, int size)
{
    int size_swap = size/2;
    uint16_t swap;
    for(int i = 0; i < size_swap-1; i += 2) {
        swap = buf[i];
        buf[i] = buf[i+1];
        buf[i+1] = swap;
    }
}

void audio_stop(void)
{
    size_t size;
    char *buf = xRingbufferReceive(rb, &size, (TickType_t)0);
    if (buf) {
        vRingbufferReturnItem(rb, buf);
    }
    i2s_zero_dma_buffer(I2S_NUM);
}

extern const uint8_t dudu_start[]    asm("_binary_dudu_wav_start");
extern const uint8_t dudu_end[]      asm("_binary_dudu_wav_end");

extern const uint8_t connect_start[] asm("_binary_connect_wav_start");
extern const uint8_t connect_end[]   asm("_binary_connect_wav_end");
extern const uint8_t null_start[]    asm("_binary_null_call_wav_start");
extern const uint8_t null_end[]      asm("_binary_null_call_wav_end");


void get_audio_by_name(char *name, uint8_t **get, size_t *len)
{
    if (name == NULL) {
        *get = NULL;
        *len = 0;
        return;
    }
    if(strcmp(name, "connect") == 0) {
        *get = connect_start+44;
        *len = connect_end - connect_start-44;
    } else if (strcmp(name, "null") == 0) {
        *get = null_start+44;
        *len = null_end - null_start-44;
    } else if (strcmp(name, "dudu") == 0) {
        *get = dudu_start+44;
        *len = dudu_end - dudu_start-44;
    } else {
        *get = NULL;
        *len = 0;
    }
}