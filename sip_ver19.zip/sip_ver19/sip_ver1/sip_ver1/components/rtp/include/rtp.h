#ifndef __RTP_H__
#define __RTP_H__

void rtp_hdr_dump(void *ptr);
uint8_t *rtp_trans_malloc_packet(size_t payload_size);
void rtp_init_packet_hdr(void *ptr, uint8_t crc, uint8_t type, uint16_t seq, uint32_t time_stramp, uint32_t ssrc);
void rtp_fill_packet(void *ptr, uint8_t *payload, size_t payload_size);
void rtp_trans_free_packet(void* ptr);

#endif