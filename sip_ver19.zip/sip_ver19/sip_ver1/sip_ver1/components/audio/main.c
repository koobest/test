/* Hello World Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s.h"
#include "es7210.h"
#include "es8311.h"

#define I2S_NUM 1

void i2s_mclK_matrix_out(int i2s_num, int io_num)
{
#include "driver/gpio.h"
#include "esp_rom_gpio.h"
    PIN_FUNC_SELECT(GPIO_PIN_MUX_REG[io_num], PIN_FUNC_GPIO);
    gpio_set_direction(io_num, GPIO_MODE_OUTPUT);
    esp_rom_gpio_connect_out_signal(io_num, i2s_num == 0 ? 23 : 21, 0, 0);
}

void i2s1_if_init(void)
{
    i2s_config_t i2s_config = {
        .param_cfg = {
            .mode = I2S_MODE_MASTER | I2S_MODE_RX | I2S_MODE_TX,
            .sample_rate = 16000,
            .communication_format = I2S_COMM_FORMAT_STAND_MSB,
            .slot_bits_cfg = (I2S_BITS_PER_SLOT_16BIT << SLOT_BIT_SHIFT) | I2S_BITS_PER_SAMPLE_16BIT,
            .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
            .slot_channel_cfg = (2 << SLOT_CH_SHIFT) | 2,
            .active_slot_mask = I2S_TDM_ACTIVE_CH0 | I2S_TDM_ACTIVE_CH1,
            .left_align_en = false,
            .big_edin_en = false,
            .bit_order_msb_en = false,
        },
        .dma_buf_count = 8,
        .dma_buf_len = 320,
        .use_apll = false,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = 40,
        .ws_io_num = 41,
        .data_in_num = -1,
        .data_out_num = 39,
    };
    i2s_driver_install(1, &i2s_config, 0, NULL);
    i2s_set_pin(1, &pin_config);
    // i2s_mclK_matrix_out(1, 42);
}

void i2s0_if_init(void)
{
    i2s_config_t i2s_config = {
        .param_cfg = {
            .mode = I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX,
            .sample_rate = 16000,
            .communication_format = I2S_COMM_FORMAT_STAND_MSB,
            .slot_bits_cfg = (I2S_BITS_PER_SLOT_16BIT << SLOT_BIT_SHIFT) | I2S_BITS_PER_SAMPLE_16BIT,
            .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
            .slot_channel_cfg = (4 << SLOT_CH_SHIFT) | 2,
            .active_slot_mask =  I2S_TDM_ACTIVE_CH0 | I2S_TDM_ACTIVE_CH3,
            .left_align_en = false,
            .big_edin_en = false,
            .bit_order_msb_en = false,
        },
        .dma_buf_count = 6,
        .dma_buf_len = 320*2,
        .use_apll = false,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = 10,
        .ws_io_num = 9,
        .data_out_num = -1,
        .data_in_num = 11
    };
    i2s_driver_install(0, &i2s_config, 0, NULL);
    i2s_set_pin(0, &pin_config);
    i2s_mclK_matrix_out(0, 20);
}

#include "string.h"

void app_main(void)
{
    Es7210Config codec = {
        .i2c_port_num = I2C_NUM_0,
        .i2c_cfg = {
            .mode = I2C_MODE_MASTER,
            .sda_io_num = 1,
            .scl_io_num = 2,
            .sda_pullup_en = 1,
            .scl_pullup_en = 1,
            .master.clk_speed = 100000,
        }
    };
    Es8311Config codec_8311 = {
        .esMode = ES_MODE_SLAVE,
        .i2c_port_num = I2C_NUM_0,
        .i2c_cfg = { \
            .mode = I2C_MODE_MASTER,
            .sda_io_num = 1,
            .scl_io_num = 2,
            .sda_pullup_en = 1,
            .scl_pullup_en = 1,
            .master.clk_speed = 100000,
        },
        .adcInput = ADC_INPUT_LINPUT1_RINPUT1,
        .dacOutput = DAC_OUTPUT_LOUT1|DAC_OUTPUT_ROUT1,
    };

    i2s0_if_init();
    i2s1_if_init();

    Es7210Init(&codec);
    Es8311Init(&codec_8311);
    Es8311Start(ES_MODULE_DAC);
    PIN_FUNC_SELECT(GPIO_PIN_MUX_REG[38], PIN_FUNC_GPIO);
    gpio_set_direction(38, GPIO_MODE_OUTPUT);
    gpio_set_level(38, 1);
void dump_i2s_config(void);
    dump_i2s_config();
    uint8_t *buf = malloc(320*8);
    size_t bytes_written;
    while(1) {
         i2s_read(0, buf, 320*2*4, &bytes_written, (TickType_t)1000);
        // memset(buf, 0x23, 320*2*4);
        i2s_write(1, buf, 320*2*4, &bytes_written, (TickType_t)1000);
    }
}

void dump_i2s_config(void)
{
#include "soc/i2s_struct.h"
#define pI2S (&I2S0)
    printf("rx_reset: %x\n", pI2S->rx_conf.rx_reset);
    printf("rx_fifo_reset: %x\n", pI2S->rx_conf.rx_fifo_reset);
    printf("rx_start: %x\n", pI2S->rx_conf.rx_start);
    printf("rx_slave_mod: %x\n", pI2S->rx_conf.rx_slave_mod);
    printf("rx_mono: %x\n", pI2S->rx_conf.rx_mono);
    printf("rx_big_endian: %x\n", pI2S->rx_conf.rx_big_endian);
    printf("rx_update: %x\n", pI2S->rx_conf.rx_update);
    printf("rx_mono_fst_vld: %x\n", pI2S->rx_conf.rx_mono_fst_vld);
    printf("rx_pcm_conf: %x\n", pI2S->rx_conf.rx_pcm_conf);
    printf("rx_pcm_bypass: %x\n", pI2S->rx_conf.rx_pcm_bypass);
    printf("rx_stop_mode: %x\n", pI2S->rx_conf.rx_stop_mode);
    printf("rx_left_align: %x\n", pI2S->rx_conf.rx_left_align);
    printf("rx_24_fill_en: %x\n", pI2S->rx_conf.rx_24_fill_en);
    printf("rx_ws_idle_pol: %x\n", pI2S->rx_conf.rx_ws_idle_pol);
    printf("rx_bit_order: %x\n", pI2S->rx_conf.rx_bit_order);
    printf("rx_tdm_en: %x\n", pI2S->rx_conf.rx_tdm_en);
    printf("rx_pdm_en: %x\n", pI2S->rx_conf.rx_pdm_en);
    printf("rx_pdm2pcm_en: %x\n", pI2S->rx_conf.rx_pdm2pcm_en);
    printf("rx_sinc_dsr_16_en: %x\n", pI2S->rx_conf.rx_sinc_dsr_16_en);

    printf("rx_tdm_ws_width: %x\n", pI2S->rx_conf1.rx_tdm_ws_width);
    printf("rx_bck_div_num: %x\n", pI2S->rx_conf1.rx_bck_div_num);
    printf("rx_bits_mod: %x\n", pI2S->rx_conf1.rx_bits_mod);
    printf("rx_half_sample_bits: %x\n", pI2S->rx_conf1.rx_half_sample_bits);
    printf("rx_tdm_chan_bits: %x\n", pI2S->rx_conf1.rx_tdm_chan_bits);
    printf("rx_msb_shift: %x\n", pI2S->rx_conf1.rx_msb_shift);

 

    printf("rx_clkm_div_num: %x\n", pI2S->rx_clkm_conf.rx_clkm_div_num);
    printf("rx_clk_active: %x\n", pI2S->rx_clkm_conf.rx_clk_active);
    printf("rx_clk_sel: %x\n", pI2S->rx_clkm_conf.rx_clk_sel);
    printf("mclk_sel: %x\n", pI2S->rx_clkm_conf.mclk_sel);

 

    printf("rx_clkm_div_z: %x\n", pI2S->rx_clkm_div_conf.rx_clkm_div_z);
    printf("rx_clkm_div_y: %x\n", pI2S->rx_clkm_div_conf.rx_clkm_div_y);
    printf("rx_clkm_div_x: %x\n", pI2S->rx_clkm_div_conf.rx_clkm_div_x);
    printf("rx_clkm_div_yn1: %x\n\n", pI2S->rx_clkm_div_conf.rx_clkm_div_yn1);

    printf("rx_tdm_ctrl: %x\n\n", pI2S->rx_tdm_ctrl.val);

    printf("tx_reset: %x\n", pI2S->tx_conf.tx_reset);
    printf("tx_fifo_reset: %x\n", pI2S->tx_conf.tx_fifo_reset);
    printf("tx_start: %x\n", pI2S->tx_conf.tx_start);
    printf("tx_slave_mod: %x\n", pI2S->tx_conf.tx_slave_mod);
    printf("tx_mono: %x\n", pI2S->tx_conf.tx_mono);
    printf("tx_chan_equal: %x\n", pI2S->tx_conf.tx_chan_equal);
    printf("tx_big_endian: %x\n", pI2S->tx_conf.tx_big_endian);
    printf("tx_update: %x\n", pI2S->tx_conf.tx_update);
    printf("tx_mono_fst_vld: %x\n", pI2S->tx_conf.tx_mono_fst_vld);
    printf("tx_pcm_conf: %x\n", pI2S->tx_conf.tx_pcm_conf);
    printf("tx_pcm_bypass: %x\n", pI2S->tx_conf.tx_pcm_bypass);
    printf("tx_stop_en: %x\n", pI2S->tx_conf.tx_stop_en);
    printf("tx_left_align: %x\n", pI2S->tx_conf.tx_left_align);
    printf("tx_24_fill_en: %x\n", pI2S->tx_conf.tx_24_fill_en);
    printf("tx_ws_idle_pol: %x\n", pI2S->tx_conf.tx_ws_idle_pol);
    printf("tx_bit_order: %x\n", pI2S->tx_conf.tx_bit_order);
    printf("tx_tdm_en: %x\n", pI2S->tx_conf.tx_tdm_en);
    printf("tx_pdm_en: %x\n", pI2S->tx_conf.tx_pdm_en);
    printf("tx_chan_mod: %x\n", pI2S->tx_conf.tx_chan_mod);
    printf("sig_loopback: %x\n", pI2S->tx_conf.sig_loopback);


    printf("tx_tdm_ws_width: %x\n", pI2S->tx_conf1.tx_tdm_ws_width);
    printf("tx_bck_div_num: %x\n", pI2S->tx_conf1.tx_bck_div_num);
    printf("tx_bits_mod: %x\n", pI2S->tx_conf1.tx_bits_mod);
    printf("tx_half_sample_bits: %x\n", pI2S->tx_conf1.tx_half_sample_bits);
    printf("tx_tdm_chan_bits: %x\n", pI2S->tx_conf1.tx_tdm_chan_bits);
    printf("tx_msb_shift: %x\n", pI2S->tx_conf1.tx_msb_shift);
    // printf("tx_bck_no_dly: %x\n", pI2S->tx_conf1.tx_bck_no_dly);

    printf("tx_clkm_div_num: %x\n", pI2S->tx_clkm_conf.tx_clkm_div_num);
    printf("tx_clk_active: %x\n", pI2S->tx_clkm_conf.tx_clk_active);
    printf("tx_clk_sel: %x\n", pI2S->tx_clkm_conf.tx_clk_sel);
    printf("clk_en: %x\n", pI2S->tx_clkm_conf.clk_en);

    printf("tx_clkm_div_z: %x\n", pI2S->tx_clkm_div_conf.tx_clkm_div_z);
    printf("tx_clkm_div_y: %x\n", pI2S->tx_clkm_div_conf.tx_clkm_div_y);
    printf("tx_clkm_div_x: %x\n", pI2S->tx_clkm_div_conf.tx_clkm_div_x);
    printf("tx_clkm_div_yn1: %x\n", pI2S->tx_clkm_div_conf.tx_clkm_div_yn1);

    printf("tx_tdm_ctrl: %x\n\n", pI2S->tx_tdm_ctrl.val);
}