#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s.h"
#include "driver/gpio.h"
#include "es8311.h"

#define SAMPLE_RATE     (16000)
#define I2S_NUM         (0)
#define I2S_BCK_IO      (19)
#define I2S_WS_IO       (21)
#define I2S_DI_IO       (4)
#define I2S_DO_IO       (5)


//13

#define AUDIO_CODEC_DEFAULT_CONFIG(){                   \
        .adc_input  = AUDIO_HAL_ADC_INPUT_LINE1,        \
        .dac_output = AUDIO_HAL_DAC_OUTPUT_ALL,         \
        .codec_mode = AUDIO_HAL_CODEC_MODE_BOTH,        \
        .i2s_iface = {                                  \
            .mode = AUDIO_HAL_MODE_SLAVE,               \
            .fmt = AUDIO_HAL_I2S_NORMAL,                \
            .samples = AUDIO_HAL_48K_SAMPLES,           \
            .bits = AUDIO_HAL_BIT_LENGTH_16BITS,        \
        },                                              \
};

void audio_init(void)
{
    int I2S_PCM_U_DECOMPRESS = 2;
    int I2S_PCM_U_COMPRESS = 3;

    i2s_config_t i2s_config = {
        .mode = I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX,
        .sample_rate = SAMPLE_RATE,
        .bits_per_sample = 16,
        .channel_format = I2S_CHANNEL_FMT_ONLY_RIGHT,                           //2-channels
        .communication_format = I2S_COMM_FORMAT_STAND_MSB,
        .dma_buf_count = 8,
        .dma_buf_len = 60,
        .use_apll = false,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1                                //Interrupt level 1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = 5,
        .ws_io_num = 25,
        .data_out_num = 26,     
        .data_in_num = 35,                                             //Not used
    };
    i2s_driver_install(I2S_NUM, &i2s_config, 0, NULL);
    i2s_set_pin(I2S_NUM, &pin_config);
#if 1
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO0_U, FUNC_GPIO0_CLK_OUT1);
    WRITE_PERI_REG(PIN_CTRL, 0xFFF0);
    vTaskDelay(2000/portTICK_PERIOD_MS);
    audio_hal_codec_config_t es8311_cfg = AUDIO_CODEC_DEFAULT_CONFIG();
    es8311_codec_init(&es8311_cfg);
    es8311_codec_config_i2s(es8311_cfg.codec_mode, &es8311_cfg.i2s_iface);
    es8311_codec_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
    es8311_codec_set_voice_volume(70);
#endif
}

int audio_write(uint8_t *buf, size_t size, int ms_blcok)
{
    size_t i2s_bytes_write = 0;
    i2s_write(I2S_NUM, buf, size, &i2s_bytes_write, ms_blcok);
    return i2s_bytes_write;
}

int audio_read(uint8_t *buf, size_t size, int ms_blcok)
{
    size_t i2s_bytes_read = 0;
    i2s_read(I2S_NUM, buf, size, &i2s_bytes_read, ms_blcok);
    return i2s_bytes_read;
}