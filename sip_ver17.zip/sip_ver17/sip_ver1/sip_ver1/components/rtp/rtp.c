#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "esp_system.h"
#include <netinet/in.h>

typedef struct {
    uint32_t wd0;
    uint32_t wd1;
    uint32_t wd2;
    uint8_t  buf[1];
} rtp_hdr_t;


void rtp_hdr_dump(void *ptr)
{
    // uint32_t *hdr = (uint32_t*)ptr;
    // printf("seq: %d\n", 0xffff & (hdr[0]>>16));
    // printf("type: %d\n",  0x7f & (hdr[0]>>9));
    // printf("crc: %x\n",  0xff &(hdr[0]>>4));
    // printf("time stramp: %x\n", hdr[1]);
    // printf("ssrc: %x\n", hdr[2]);
}

uint8_t *rtp_trans_malloc_packet(size_t payload_size)
{
    uint8_t *packet = malloc(sizeof(rtp_hdr_t)+payload_size);
    if (packet == NULL) return NULL;
    memset(packet, 0, sizeof(rtp_hdr_t));
    return packet;
}

void rtp_init_packet_hdr(void *ptr, uint32_t crc, uint32_t type, uint32_t seq, uint32_t time_stramp, uint32_t ssrc)
{
    rtp_hdr_t *hdr = (rtp_hdr_t*)ptr;
    hdr->wd0 = (0x80 | (crc & 0xf)) | ((type<<8) & 0x7f00) | ((seq<<8) & 0xff0000) | ((seq<<24) & 0xff000000);
    hdr->wd1 = ntohl(time_stramp);
    hdr->wd2 = ntohl(ssrc);
}

void rtp_fill_packet(void *ptr, uint8_t *payload, size_t payload_size)
{
    uint32_t *hdr = (uint32_t*)ptr+3;
    memcpy(hdr, payload, payload_size);
}

void rtp_trans_free_packet(void* ptr)
{
    if(ptr) free(ptr);
}

void rtp_trans_packet(void *ptr, size_t packet_size)
{
    ;
}

// void rtp_task(void *param)
// {
//     printf("rtp_task\n");
//     int test_port = (int)param;
//     int sock_fd;
//     int recv_num;
//     int send_num;
//     socklen_t client_len;
//     char *recv_buf = (char *)malloc(256);
//     memset(recv_buf, 0, 256);
//     struct sockaddr_in  addr_serv;
//     struct sockaddr_in  addr_client;//服务器和客户端地址
//     sock_fd = socket(AF_INET,SOCK_DGRAM,0);
//     if(sock_fd < 0){
//             printf("socket error\n");
//     } else{
//             printf("sock sucessful\n");
//     }
//     memset(&addr_serv,0,sizeof(struct sockaddr_in));
//     addr_serv.sin_family = AF_INET;
//     addr_serv.sin_port = htons(16900);
//     addr_serv.sin_addr.s_addr = inet_addr("192.168.1.6");
//     client_len = sizeof(struct sockaddr_in);
//     if(bind(sock_fd,(struct sockaddr *)&addr_serv,sizeof(struct sockaddr_in))<0 ){
//         printf("bind error\n");
//     } else{
//         printf("bind sucess\n");
//     }
//     addr_client.sin_family = AF_INET;
//     addr_client.sin_port = htons(test_port);
//     addr_client.sin_addr.s_addr = inet_addr("192.168.1.111");

//     send_num = sendto(sock_fd,recv_buf,18,0,(struct sockaddr *)&addr_client,client_len);
//     if(send_num < 0){
//             printf("sendto error");
//     } else{
//             printf("send sucessful\n");
//     }
//     uint32_t seq_num = 0;
//     uint32_t time_stamp = 0;
//     while (1)
//     {
//         recv_num = recvfrom(sock_fd,recv_buf,256,0,(struct sockaddr *)&addr_client,&client_len);
//         rtp_init_packet_hdr(recv_buf, 0, 0, seq_num++, time_stamp++, 0x59ed63d2);
//         send_num = sendto(sock_fd,recv_buf,recv_num,0,(struct sockaddr *)&addr_client,client_len);
//     }
// }