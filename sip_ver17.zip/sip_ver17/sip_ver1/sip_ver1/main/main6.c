#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_heap_caps.h"
#include <netinet/in.h>
#include <eXosip2/eXosip.h>
#include "lwip/err.h"
#include "lwip/sys.h"
#include <osip2/osip_mt.h>
#include <eXosip2/eXosip2.h>
#include <rtp.h>

typedef struct {
    struct eXosip_t *eXosip;
    char *ip;
    int port;
    int rtp_port;
    void *audio;
    void *net_work;
    void *control;
    void *task_handle;
    void *audio_task_handle;
    void *idle_task_handle;
} session_t;

session_t *session;

enum {
    SESSION_UNITED,
    SESSION_INITED,
    SESSION_HANDLE,
    SESSION_DONE,
};

int session_init_exosip(session_t *session, const char *ip, int port)
{
    int ret = -1;
    session->eXosip = eXosip_malloc();
    if (session->eXosip == NULL) {
        return -1;
    }
    ret = eXosip_init(session->eXosip);
    if(ret!=0) {
        printf("Couldn't initialize eXosip contex!\n");
        return -1;
    }
    ret = eXosip_listen_addr(session->eXosip, IPPROTO_UDP, ip, port, AF_INET, 0);
    if(ret != 0) {
        printf("Couldn't initialize transport layer!\n");
        eXosip_quit(session->eXosip);
    }
    return 0;
}

int session_call(session_t *session, const char* dst_name)
{
    char *invate_sdp =
        "v=0\r\n"
        "o=yate 1618414934 1618414934 IN IP4 %s\r\n"
        "s=SIP Call\r\n"
        "c=IN IP4 %s\r\n"
        "t=0 0\r\n"
        "m=audio %d RTP/AVP 0 8 11 98 97 105 106 101\r\n"
        "a=rtpmap:0 PCMU/8000\r\n"
        "a=rtpmap:8 PCMA/8000\r\n"
        "a=rtpmap:11 L16/8000\r\n"
        "a=rtpmap:98 iLBC/8000\r\n"
        "a=fmtp:98 mode=20\r\n"
        "a=rtpmap:97 iLBC/8000\r\n"
        "a=fmtp:97 mode=30\r\n"
        "a=rtpmap:105 iSAC/16000\r\n"
        "a=rtpmap:106 iSAC/32000\r\n"
        "a=rtpmap:101 telephone-event/8000\r\n"
        "a=ptime:30\r\n"
        "\r\n";

    int ret = -1;
    osip_message_t *invite=NULL;
    char source[64];
    char dest[64];
    uint8_t *invite_msg = malloc(512);
    memset(invite_msg, 0, 512);
    memset(source, 0, 64);
    memset(dest, 0, 64);
    snprintf(source, 64, "sip:133@%s", session->ip);
    snprintf(dest, 64, "sip:kooho@%s:5060", dst_name);
    ret = eXosip_call_build_initial_invite(session->eXosip, &invite, dest, source, NULL,"Exosip call");
    if (ret != 0) {
        printf("Build INVITE failed!\n");
        goto out;
    }
    snprintf((char *)invite_msg, 512, invate_sdp, session->ip, session->ip, session->rtp_port);
    osip_message_set_body(invite, (char *)invite_msg, strlen((char *)invite_msg));
    osip_message_set_content_type(invite,"application/sdp");
    eXosip_lock(session->eXosip);
    ret = eXosip_call_send_initial_invite(session->eXosip, invite); //invite SIP INVITE message to send
    eXosip_unlock(session->eXosip);
    if (ret != 0) {
        goto out;
    }
    ret = 0;
out:
    if (invite_msg) {
        free(invite_msg);
    }
    return ret;
}

int init_rtp_socket_udp(struct sockaddr_in *src, char* ip_src, int src_port, struct sockaddr_in *dst, char* ip_dst, int dst_port)
{
    memset(src, 0, sizeof(struct sockaddr_in));
	src->sin_family = AF_INET;
    src->sin_port = htons((uint16_t)src_port);
    src->sin_addr.s_addr = inet_addr(ip_src);
    memset(dst, 0, sizeof(struct sockaddr_in));
    dst->sin_family = AF_INET;
    dst->sin_port = htons((uint16_t)dst_port);
    dst->sin_addr.s_addr = inet_addr(ip_dst);

    int sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd < 0) {
        return -1;
    }
    if (bind(sock_fd, (struct sockaddr *)src, sizeof(struct sockaddr_in))<0 ) {
        printf("bind error\n");
        close(sock_fd);
        sock_fd = -1;
    }
    return sock_fd;
}

static void rtpc_task(void *param)
{
    vTaskDelay(200/portTICK_PERIOD_MS);
    int rtcp_port = (int)param + 1;
    char recv_buf[18];
    struct sockaddr_in  addr_serv;
    struct sockaddr_in  addr_client;
    socklen_t client_len = sizeof(struct sockaddr_in);
    int fd = init_rtp_socket_udp(&addr_serv, "192.168.0.101", 16901, &addr_client, "192.168.0.101", rtcp_port);
    if (fd < 0) {
        goto out;
    }
    int len = sendto(fd, recv_buf, 18, 0, (struct sockaddr *)&addr_client,client_len);
    if (len < 0) {
        printf("sendto error");
        goto out;
    }
    while (1) {
        recvfrom(fd, recv_buf, 18, 0, (struct sockaddr *)&addr_client, &client_len);
        vTaskDelay(1000/portTICK_PERIOD_MS);
    }
out:
    if (fd > 0) {
        close(fd);
    }
    vTaskDelete(NULL);
}

static void rtp_task(void *param)
{
    vTaskDelay(500/portTICK_PERIOD_MS);
    int rtp_port = (int)param + 1;
    struct sockaddr_in  addr_serv;
    struct sockaddr_in  addr_client;
    char *recv_buf = (char *)malloc(256);
    char *trans_buf = (char *)malloc(256);
    int recv_num = 0;
    int send_num = 0;
    socklen_t client_len = sizeof(struct sockaddr_in);
	int fd = init_rtp_socket_udp(&addr_serv, "192.168.0.101", 16900, &addr_client, "192.168.0.101", rtp_port);
	if (fd < 0) {
        goto out;
	}
    send_num = sendto(fd,recv_buf, 18, 0,(struct sockaddr *)&addr_client,client_len);
    if (send_num < 0){
        printf("sendto error");
        goto out;
    }
    uint32_t seq_num = 0;
    uint32_t time_stamp = 0;
    while (1) {
        recv_num = recvfrom(fd, recv_buf, 256, 0, (struct sockaddr *)&addr_client,&client_len);
        rtp_init_packet_hdr(trans_buf, 0, 0, seq_num++, time_stamp++, 0x59ed63d2);
        send_num = sendto(fd,trans_buf,recv_num,0,(struct sockaddr *)&addr_client,client_len);
    }
out:
    if (fd > 0) {
        close(fd);
    }
    vTaskDelete(NULL);
}

static void rtp_session_active(char *dstip, int port)
{
    xTaskCreate(rtpc_task, "rtpc_task", 1024*4, (void *)port, 8, NULL);
    xTaskCreate(rtp_task, "rtp_task", 1024*4, (void *)port, 8, NULL);
}

void session_call_handle_event(session_t *session)
{
    int call_id = 0;
    int dialog_id = 0;
    osip_message_t *ack=NULL;
    eXosip_event_t *event = eXosip_event_wait(session->eXosip, 20, 0);
    if (event == NULL) {
        printf("Wait event time over!\n");
        return;
    }
    switch (event->type) {
        default:
            break;
        case EXOSIP_CALL_INVITE:
        case EXOSIP_CALL_ACK:
            break;
        case EXOSIP_CALL_PROCEEDING:
            printf("proceeding!\n");
            break;
        case EXOSIP_CALL_RINGING:
            printf("UAC: ringing!\n");
            break;
        case EXOSIP_CALL_ANSWERED: //收到200 OK，表示请求已经被成功接受，用户应答
            printf("session connected!\n");
            call_id = event->cid;
            dialog_id = event->did;
            osip_body_t *body;
            printf("UAC: call_id is %d, dialog_id is %d\n",event->cid,event->did);
            eXosip_call_build_ack(session->eXosip, event->did, &ack);
            eXosip_call_send_ack(session->eXosip, event->did, ack);
            osip_message_get_body(event->response, 0, &body);
            printf("get body: %s\n", body->body);
            rtp_session_active("192.168.1.5", 1232);
            break;
        case EXOSIP_CALL_CLOSED:
            break;
    }
    eXosip_event_free(event);
}

int session_global_init(void)
{
    session = (session_t *)malloc(sizeof(session_t));
    if (!session) return -1;
    return session_init_exosip(session, "192.168.0.1", 10000);
}

void net_config(void);
void console_init(void);


void app_main(void)
{
    console_init();
    net_config();
    session_global_init();
}