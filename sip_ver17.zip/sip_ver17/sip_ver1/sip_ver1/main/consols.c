#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

char *console = NULL;

int get_input(char *buf)
{
    int ch = 0xff;
    int len = 0;
    while (1) {
        ch = getchar() & 0xff;
        if (ch == 0xff) {
            continue;
        }
        if (ch == '\r' || ch == '\n') {
            break;
        }
        buf[len++] = ch;
    }
    return len;
}

void prase_cmd(char *str)
{
	char *p = NULL;
    p = strtok(str, " ");
    printf("%s\n", p);
    if (0 == strcmp(p, "call")) {
    	p = strtok(NULL, " ");
        
    }
}

void console_task(void *param)
{
	int len = 0;
    while (1) {
        memset(console, 0, 512);
        len = get_input(console);
        if (len > 0) {
            prase_cmd(console);
        }
        vTaskDelay(50/portTICK_PERIOD_MS);
    }
}

void console_init(void)
{
    console = (char *)malloc(512);
    if (!console) printf("console malloc fail\n");
    xTaskCreate(console_task, "console_task", 1024*4, NULL, 5, NULL);
}
