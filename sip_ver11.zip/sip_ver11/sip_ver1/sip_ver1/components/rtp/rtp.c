#if 0
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_heap_caps.h"
#include <netinet/in.h>
#include "lwip/err.h"
#include "lwip/sys.h"

static int session[10] = {0};

void session_acctive(void)
{
    ;
}

void sip_task(void *param)
{
    while(1) {
        
    }
}

void rtp_init(void)
{
    int recv_num;
    int send_num;
    struct sockaddr_in servaddr;
    int client_socket = -1;
    memset(&servaddr, 0, sizeof(struct sockaddr_in));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(169000);
    servaddr.sin_addr.s_addr = inet_addr("192.168.1.111");
    client_socket = socket(PF_INET, SOCK_DGRAM, 0);
    if (client_socket < 0) {
        printf("socket fail\n");
        return;
    }
    printf("client init done\n");
    char buf[50] = "hello world\0";
    socklen_t client_len;
    struct sockaddr_in  addr_client;//服务器和客户端地址
        send_num = sendto(client_socket,buf,recv_num,0,(struct sockaddr *)&addr_client,client_len);
        if(send_num < 0){
                printf("sendto error");
        } else{
                printf("send sucessful\n");
        }
    return;
}
#endif