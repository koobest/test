#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s.h"
#include "driver/gpio.h"
#include "es8311.h"

#define SAMPLE_RATE     (16000)
#define I2S_NUM         (0)
#define I2S_BCK_IO      (19)
#define I2S_WS_IO       (21)
#define I2S_DI_IO       (4)
#define I2S_DO_IO       (5)


//13

void audio_init(void)
{
    int I2S_PCM_A_DECOMPRESS = 0;
    int I2S_PCM_A_COMPRESS = 1;

    i2s_config_t i2s_config = {
        .mode = I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX,
        .sample_rate = SAMPLE_RATE,
        .bits_per_sample = 16,
        .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,                           //2-channels
        .communication_format = I2S_COMM_FORMAT_STAND_MSB,
        .dma_buf_count = 8,
        .dma_buf_len = 60,
        .use_apll = false,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1                                //Interrupt level 1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = I2S_BCK_IO,
        .ws_io_num = I2S_WS_IO,
        .data_out_num = I2S_DO_IO,
        .data_in_num = I2S_DI_IO                                               //Not used
    };
    i2s_driver_install(I2S_NUM, &i2s_config, 0, NULL);
    i2s_set_pin(I2S_NUM, &pin_config);
    i2s_stop(I2S_NUM);
    // I2S0.conf1.tx_pcm_bypass = 1;
    // I2S0.conf1.rx_pcm_bypass = 0;
    // I2S0.conf1.rx_pcm_conf = I2S_PCM_A_COMPRESS;
    i2s_start(I2S_NUM);

    Es8311Config cfg =
    { 
        .esMode = ES_MODE_SLAVE, 
        .i2c_port_num = I2C_NUM_0, 
        .i2c_cfg = { 
            .mode = I2C_MODE_MASTER, 
            .sda_io_num = 0, 
            .scl_io_num = 2, 
            .sda_pullup_en = 1,
            .scl_pullup_en = 1,
            .master.clk_speed = 10000,
        }, 
        .adcInput = ADC_INPUT_LINPUT1_RINPUT1,
        .dacOutput = DAC_OUTPUT_ROUT1 | DAC_OUTPUT_ROUT2 | DAC_OUTPUT_LOUT1 | DAC_OUTPUT_LOUT2,
    };
    Es8311Init(&cfg);
    Es8311Start(ES_MODULE_ADC_DAC);
    Es8311SetVoiceVolume(30);
}

int audio_write(uint8_t *buf, size_t size, int ms_blcok)
{
    size_t i2s_bytes_write = 0;
    i2s_write(I2S_NUM, buf, size, &i2s_bytes_write, ms_blcok);
    return i2s_bytes_write;
}

int audio_read(uint8_t *buf, size_t size, int ms_blcok)
{
    size_t i2s_bytes_read = 0;
    i2s_read(I2S_NUM, buf, size, &i2s_bytes_read, ms_blcok);
    return i2s_bytes_read;
}