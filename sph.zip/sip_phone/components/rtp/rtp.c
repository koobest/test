#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include "lwip/err.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"
#include "rtp.h"
#include "audio.h"

#define RTP_V  2
#define RTP_P  0
//PCM-U
#define RTP_TP 0

typedef struct {
    int rtp_port[2];// 0: src, 1: dst
    int rtcp_port[2];// 0: src, 1: dst
    int ip[2];// 0: src, 1: dst
    int rtcp_fd;// 0: src, 1: dst
    int rtp_fd;// 0: src, 1: dst
    int ref_cnt;
} rtp_udp_contex_t;

static rtp_hdr_t * rtp_hdr_malloc(void)
{
    rtp_hdr_t* hdr = (rtp_hdr_t *)malloc(sizeof(rtp_hdr_t)+RTP_MAX_PKT_SIZE+2);
    if (!hdr) {
        return NULL;
    }
    memset(hdr, 0, sizeof(rtp_hdr_t)+RTP_MAX_PKT_SIZE+2);
    return hdr;
}

static int rtp_send(rtp_udp_contex_t *contex, uint8_t *pr, size_t size)
{
    int tx_len = -1;
    struct sockaddr_in  rtp_client;

    rtp_client.sin_family = AF_INET;
    rtp_client.sin_port = htons(contex->rtp_port[1]);
    rtp_client.sin_addr.s_addr = contex->ip[1]; 
    socklen_t client_len = (socklen_t)sizeof(rtp_client);
    if (!contex || !pr) return tx_len;
    tx_len = sendto(contex->rtp_fd, pr, size, 0, (struct sockaddr *)&rtp_client, client_len);
    return (tx_len == size) ? tx_len : -1;
}

static int rtp_recv(rtp_udp_contex_t *contex, uint8_t *pr, size_t size)
{
    int rx_len = -1;
    struct sockaddr_in  rtp_client;
    socklen_t client_len = (socklen_t)sizeof(rtp_client);
    if (!contex || !pr) return rx_len;
    rx_len = recvfrom(contex->rtp_fd, pr, size, 0, (struct sockaddr *)&rtp_client, &client_len);
    return (rx_len == size) ? rx_len : -1;
}

static int rtcp_send(rtp_sink_t *rtp_sink, uint8_t *pr, size_t size)
{
    rtp_udp_contex_t *contex = (rtp_udp_contex_t *)rtp_sink->rtp_sink_contex;
    int tx_len = -1;
    struct sockaddr_in  rtcp_client;

    rtcp_client.sin_family = AF_INET;
    rtcp_client.sin_port = htons(contex->rtcp_port[1]+1);
    rtcp_client.sin_addr.s_addr = contex->ip[1]; 
    socklen_t client_len = (socklen_t)sizeof(rtcp_client);
    if (!contex || !pr) return tx_len;
    tx_len = sendto(contex->rtcp_fd, pr, size, 0, (struct sockaddr *)&rtcp_client, client_len);
    return (tx_len == size) ? tx_len : -1;
}

static int rtcp_recv(rtp_sink_t *rtp_sink, uint8_t *pr, size_t size)
{
    rtp_udp_contex_t *contex = (rtp_udp_contex_t *)rtp_sink->rtp_sink_contex;
    int rx_len = -1;
    struct sockaddr_in  rtcp_client;
    socklen_t client_len = (socklen_t)sizeof(rtcp_client);
    if (!contex || !pr) return rx_len;
    rx_len = recvfrom(contex->rtcp_fd, pr, size, 0, (struct sockaddr *)&rtcp_client, &client_len);
    return (rx_len == size) ? rx_len : -1;
}

typedef struct {
    uint32_t wd0;
    uint32_t wd1;
    uint32_t wd2;
    uint8_t  buf[1];
} __rtp_hdr_t;

static void rtp_init_packet_hdr(void *ptr, uint32_t crc, uint32_t type, uint32_t seq, uint32_t time_stramp, uint32_t ssrc)
{
    __rtp_hdr_t *hdr = (__rtp_hdr_t*)ptr;
    hdr->wd0 = (0x80 | (crc & 0xf)) | ((type<<8) & 0x7f00) | ((seq<<8) & 0xff0000) | ((seq<<24) & 0xff000000);
    hdr->wd1 = ntohl(time_stramp);
    hdr->wd2 = ntohl(ssrc);
}

static int rtp_sink_tx(rtp_sink_t *rtp_sink, uint8_t *buf, size_t tx_len)
{
    rtp_hdr_t *hdr = rtp_sink->pket;
    // hdr->seq = rtp_sink->seq_num;
    // hdr->ts = rtp_sink->time_stamp;
    // hdr->marker = rtp_sink->marker;

    rtp_init_packet_hdr(hdr, 0, 0, rtp_sink->seq_num, rtp_sink->time_stamp, 0x59ed63d2);

    memcpy(hdr->buf, buf, tx_len);
    int len = rtp_send((rtp_udp_contex_t*)rtp_sink->rtp_sink_contex, (uint8_t *)hdr, RTP_HDR_SIZE+tx_len);
    rtp_sink->marker = 0;
    rtp_sink->seq_num++;
    rtp_sink->time_stamp += rtp_sink->sample_rate*rtp_sink->ptime/1000;
    return len;
}

static int rtp_sink_rx(rtp_sink_t *rtp_sink, uint8_t *buf, size_t rx_len)
{
    uint8_t *rx = rtp_sink->buffer;
    int len = rtp_recv((rtp_udp_contex_t*)rtp_sink->rtp_sink_contex, rx, rx_len+RTP_HDR_SIZE);
    if (len > 12) {
        len -= RTP_HDR_SIZE;
        memcpy(buf, rx+RTP_HDR_SIZE, len);
    } else {
        len = 0;
    }
    return len;
}

static rtp_udp_contex_t *rtp_udp_contex_new(void)
{
    rtp_udp_contex_t *contex = malloc(sizeof(rtp_udp_contex_t));
    if (contex) {
       memset(contex, 0, sizeof(rtp_udp_contex_t)); 
    }
    return contex;
}

static int wait_rtp_done(rtp_sink_t *rtp)
{
    rtp_udp_contex_t *contex;
    if (!rtp) return 1;
    contex = (rtp_udp_contex_t *)rtp->rtp_sink_contex;
    return contex->ref_cnt == 0;
}

static void rtp_udp_ref_inc(rtp_sink_t *rtp)
{
    rtp_udp_contex_t *contex;
    if (!rtp) return;
    contex = (rtp_udp_contex_t *)rtp->rtp_sink_contex;
    contex->ref_cnt++;
}

static void rtp_udp_ref_dec(rtp_sink_t *rtp)
{
    rtp_udp_contex_t *contex;
    if (!rtp) return;
    contex = (rtp_udp_contex_t *)rtp->rtp_sink_contex;
    contex->ref_cnt--;
}

static void rtp_udp_close_socket(rtp_sink_t *rtp_sink)
{
    rtp_udp_contex_t *contex;
    if (rtp_sink) {
        contex = (rtp_udp_contex_t *)rtp_sink->rtp_sink_contex;
        rtp_sink->active = 0;
        if (contex->rtcp_fd > 0) close(contex->rtcp_fd);
        if (contex->rtp_fd > 0) close(contex->rtp_fd);
        contex->rtcp_fd = -1;
        contex->rtp_fd = -1;
        while (wait_rtp_done(rtp_sink) == 0) {
            vTaskDelay(10/portTICK_PERIOD_MS);
        }
        free(contex);
        rtp_sink->rtp_sink_contex = NULL;
    }
}

static void rtp_task_rx(void *param)
{
    printf("rtp rx task\n");
    rtp_udp_contex_t *contex;
    rtp_sink_t *rtp = (rtp_sink_t*)param;
    contex = (rtp_udp_contex_t *)rtp->rtp_sink_contex;
    int rtp_audio_len = rtp->ptime*rtp->sample_rate/1000;
    int recv_num = 0;
    char *recv_buf = (char *)malloc(rtp_audio_len);
    char *trans_audio = (char *)malloc(rtp_audio_len*2);
    rtp_udp_ref_inc(rtp);
    while (rtp->active) {
       recv_num = rtp_sink_rx(rtp, (uint8_t *)recv_buf, rtp_audio_len);
       if (recv_num < 0) goto out;
       audio_ulaw_dec((uint16_t *)trans_audio, (uint8_t *)recv_buf, recv_num);
       audio_ch_swap_16((uint16_t *)trans_audio, recv_num*2);
       audio_write((uint8_t *)trans_audio, recv_num*2, 0);
    }
out:
    if (recv_buf) free(recv_buf);
    if (trans_audio) free(trans_audio);
    printf("exit RTP RX task\n");
    rtp_udp_ref_dec(rtp);
    vTaskDelete(NULL);
}

static void rtp_task_tx(void *param)
{
#define AUDIO_LEN 160
    printf("rtp tx task\n");
    rtp_udp_contex_t *contex;
    rtp_sink_t *rtp = (rtp_sink_t*)param;
    contex = (rtp_udp_contex_t *)rtp->rtp_sink_contex;
    const int audio_len = AUDIO_LEN*2;
    const int rtp_len = AUDIO_LEN;
    int send_num = 0;
    char *trans_buf = (char *)malloc(rtp_len);
    char *recv_audio = (char *)malloc(audio_len);
    rtp_udp_ref_inc(rtp);
    while (rtp->active) {
       audio_read((uint8_t *)recv_audio, audio_len, 10);
       audio_ch_swap_16((uint16_t *)recv_audio, audio_len);
       audio_ulaw_enc((uint8_t *)trans_buf, (uint16_t *)recv_audio, audio_len);
       send_num = rtp_sink_tx(rtp, (uint8_t *)trans_buf, rtp_len);
       if (send_num < 0) goto out;
       vTaskDelay(rtp->ptime/portTICK_PERIOD_MS);
    }
out:
    if (trans_buf) free(trans_buf);
    if (recv_audio) free(recv_audio);
    printf("exit RTP TX task\n");
    rtp_udp_ref_dec(rtp);
    vTaskDelete(NULL);
}
static void rtcp_task(void *param)
{
    printf("RTCP task\n");
    uint8_t bufer[18];
    rtp_udp_contex_t *contex;
    rtp_sink_t *rtp = (rtp_sink_t*)param;
    contex = (rtp_udp_contex_t *)rtp->rtp_sink_contex;
    vTaskDelay(200/portTICK_PERIOD_MS);
    rtp_udp_ref_inc(rtp);
    int len = rtcp_send(rtp, bufer, 18);
    if (len < 0) {
        // printf("RTCP sendto error\n");
        goto out;
    }
    xTaskCreatePinnedToCore(rtp_task_rx, "rtp_task_rx", 1024*4, (void *)rtp, 8, NULL, 1);
    xTaskCreatePinnedToCore(rtp_task_tx, "rtp_task_tx", 1024*4, (void *)rtp, 8, NULL, 1);
    while (rtp->active) {
       if( rtcp_recv(rtp, bufer, 18) < 0) {
          goto out;
       }
       vTaskDelay(1000/portTICK_PERIOD_MS);
    }
out:
    printf("exit RTCP task\n");
    rtp_udp_ref_dec(rtp);
    vTaskDelete(NULL);
}

static void rtp_sink_active(rtp_sink_t *rtp)
{
    if (rtp) {
        rtp->active = 1;
        xTaskCreatePinnedToCore(rtcp_task, "rtcp_task", 1024*4, (void *)rtp, 8, NULL, 1);
    }
}

static int rtp_udp_socket_init(rtp_sink_t *rtp_sink, int port[2], int ip[2])
{
    int sock_fd_rtp = -1; 
    int sock_fd_rtcp = -1;
    struct sockaddr_in  socket_addr;
    memset(&socket_addr, 0, sizeof(struct sockaddr_in));
    socket_addr.sin_family = AF_INET;
    socket_addr.sin_addr.s_addr = ip[0];
    socket_addr.sin_port = htons((uint16_t)port[0]);
    sock_fd_rtp = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd_rtp < 0) {
        goto error;
    }
    if (bind(sock_fd_rtp, (struct sockaddr *)&socket_addr, sizeof(struct sockaddr_in))<0 ) {
        printf("rtp socket bind error\n");
        goto error;
    }

    socket_addr.sin_port = htons((uint16_t)(port[0]+1));
    sock_fd_rtcp = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd_rtcp < 0) {
        return -1;
    }
    if (bind(sock_fd_rtcp, (struct sockaddr *)&socket_addr, sizeof(struct sockaddr_in))<0 ) {
        printf("rtcp socket bind error\n");
        goto error;
    }
    rtp_udp_contex_t *rtp_cnx = (rtp_udp_contex_t*)(rtp_sink->rtp_sink_contex);
    rtp_cnx->rtp_port[0] = port[0];
    rtp_cnx->rtp_port[1] = port[1];
    rtp_cnx->rtcp_port[0] = port[0]+1;
    rtp_cnx->rtcp_port[1] = port[1]+1;
    rtp_cnx->rtp_fd = sock_fd_rtp;
    rtp_cnx->rtcp_fd = sock_fd_rtcp;
    rtp_cnx->ip[0] = ip[0];
    rtp_cnx->ip[1] = ip[1];
    return 0;
error:
    if (sock_fd_rtp) close(sock_fd_rtp);
    if (sock_fd_rtcp) close(sock_fd_rtcp);
    return -1;
}

static int rtp_sink_init_udp(rtp_sink_t *rtp_sink)
{
    rtp_sink->rtp_sink_contex = (void *)rtp_udp_contex_new();
    if (!rtp_sink->rtp_sink_contex) {
        return -1;
    }
    rtp_sink->rtp_send = rtp_sink_tx;
    rtp_sink->rtp_recv = rtp_sink_rx;
    rtp_sink->rtcp_send = rtcp_send;
    rtp_sink->rtcp_recv = rtcp_recv;
    rtp_sink->rtp_init_port_socket = rtp_udp_socket_init;
    rtp_sink->rtp_socket_active = rtp_sink_active;
    rtp_sink->rtp_socket_close = rtp_udp_close_socket;
    return 0;
}

void rtp_prase_sdp(rtp_sink_t *rtp, char *attr, char *val)
{
    if (!attr || !val) return;
    if (strcmp(attr, "ptime") == 0) {
        // printf("ptime: %dms\n", atoi(val));
        rtp->ptime = atoi(val);
    }
    if (strcmp(attr, "rtpmap") == 0) {
        rtp->sample_rate = 8000;
        rtp->pket->payload = RTP_TP;
    }
}

void rtp_sink_set_protol(rtp_sink_t *rtp, char *protol)
{
    if (!rtp->rtp_sink_contex) {
        if (strcmp(protol, "RTP/AVP") == 0) {
            // printf("RTP/AVP\n");
            rtp_sink_init_udp(rtp);
        } else {
            // printf("not support protol: %s\n", protol);
        }
    }
}

rtp_sink_t *rtp_sink_alloc(void)
{
    rtp_sink_t *rtp_sink = (rtp_sink_t *)malloc(sizeof(rtp_sink_t));
    if (!rtp_sink) {
        goto error;
    }
    memset(rtp_sink, 0, sizeof(rtp_sink_t));
    rtp_sink->pket = rtp_hdr_malloc();
    if (!rtp_sink->pket) {
        goto error;
    }
    rtp_sink->pket->extension = 0;
    rtp_sink->pket->padding = 0;
    rtp_sink->pket->version = RTP_V;
    rtp_sink->pket->payload = RTP_TP;
    rtp_sink->pket->marker = 1;

    rtp_sink->tx_size = 0;
    rtp_sink->time_stamp = 100;
    rtp_sink->seq_num = 0x55;
    rtp_sink->marker = 1;
    return rtp_sink;
error:
    if (rtp_sink) {
        if (rtp_sink->pket) {
            free(rtp_sink->pket);
        }
        free(rtp_sink);
    }
    return NULL;
}
