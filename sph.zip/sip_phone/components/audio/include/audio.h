#ifndef __AUDIO_H__
#define __AUDIO_H__
#include <stdio.h>
#include <string.h>

typedef struct { 
    int (*init)(int sample_rate, int type);
    int (*deinit)(void);
    int (*set_samle_rate)(int sample_rate, int sample_bits);
    int (*set_vol)(int vol);
    int (*read)(uint8_t *buf, int len);
    int (*write)(uint8_t *buf, int len);
    int (*audio_flush_all)(void);
    int (*start)(void);
    int (*stop)(void);
} audio_cb_t ;

typedef struct {
    int (*init)(int sample_rate, int type);
    int (*deinit)(void);
    int (*set_samle_rate)(int sample_rate, int sample_bits);
    int (*set_vol)(int vol);
    int (*read)(uint8_t *buf, int len);
    int (*write)(uint8_t *buf, int len);
    int (*audio_flush_all)(void);
    int (*start)(void);
    int (*stop)(void);
} audio_codec_t;

typedef enum{
    AUDIO_EVENET_NULL = 0,
    AUDIO_EVENT_SET_SAMPLERATE = 1,
    AUDIO_EVENT_SET_VOL,
    AUDIO_EVENT_FRAME,
    AUDIO_EVENT_FRAME_DONE,
    AUDIO_EVENT_PAUSE,
    AUDIO_EVENT_STOP,
    AUDIO_EVENT_EXIT,
    AUDIO_EVENT_MAX,
} eudio_event_t;

void audio_init(void);

int audio_write(uint8_t *buf, size_t size, int ms_blcok);

int audio_read(uint8_t *buf, size_t size, int ms_blcok);

void audio_ulaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size);

void audio_ulaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size);

void audio_alaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size);

void audio_alaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size);

void audio_ch_swap_16(uint16_t *buf, int size);

void get_audio_by_name(char *name, uint8_t **get, size_t *len);

void audio_stop(void);

int audio_get_event(int time_out_ms);

#endif