#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s.h"
#include "driver/gpio.h"
#include "audio.h"
#include "es8388.h"

#define SAMPLE_RATE_DEF     (44100)
#define I2S_NUM             (0)
#define I2S_MCLK_IO         (14)
#define I2S_BCK_IO          (13)
#define I2S_WS_IO           (2)
#define I2S_DI_IO           (35)
#define I2S_DO_IO           (32)

static void i2s_mclk_out(void)
{
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_U0RXD_U, FUNC_U0RXD_CLK_OUT2);
    WRITE_PERI_REG(PIN_CTRL, 0xFF00);
}

static void es8388_init(void)
{
    audio_hal_codec_config_t es83xx_init = {
        .adc_input  = AUDIO_HAL_ADC_INPUT_LINE1,
        .dac_output = AUDIO_HAL_DAC_OUTPUT_LINE1,
        .codec_mode = AUDIO_HAL_CODEC_MODE_BOTH,
        .i2s_iface = {
            .mode = AUDIO_HAL_MODE_SLAVE,
            .fmt = AUDIO_HAL_I2S_NORMAL,
            .samples = AUDIO_HAL_44K_SAMPLES,
            .bits = AUDIO_HAL_BIT_LENGTH_16BITS,
        },
    };
    es8388_init(&es83xx_init);
    es8388_config_i2s(es83xx_init.codec_mode, &es83xx_init.i2s_iface);
    es8388_set_voice_volume(20);
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_STOP);
}

static void i2s_init(void)
{
    int sample_rate = SAMPLE_RATE_DEF;
    i2s_config_t i2s_config = {
        .mode = I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX,
        .sample_rate = sample_rate,
        .bits_per_sample = 16,
        .channel_format = I2S_CHANNEL_FMT_ONLY_RIGHT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .dma_buf_count = 6,
        .dma_buf_len = (sample_rate*2)/100,
        .use_apll = false,
        .tx_desc_auto_clear = true,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = I2S_BCK_IO,
        .ws_io_num = I2S_WS_IO,
        .data_out_num = I2S_DO_IO,     
        .data_in_num = I2S_DI_IO,
    };
    i2s_driver_install(I2S_NUM, &i2s_config, 0, NULL);
    i2s_stop(I2S_NUM);
    i2s_set_pin(I2S_NUM, &pin_config);
    i2s_mclk_out();   
}

static void codec_init(void)
{
    es8388_init();
    i2s_init();
}

static void codec_dinit(void)
{
    i2s_driver_uninstall();
    es8388_deinit();
}

static void audio_start(void)
{
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
    i2s_start(I2S_NUM);
    play_handle = xTaskCreatePinnedToCore(audio_play_task, "audio_play_task", 1024*4, NULL, 4, NULL, 1);
}

static void audio_stop(void)
{
    i2s_zero_dma_buffer(I2S_NUM);
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_STOP);
    i2s_stop(I2S_NUM);
}

static void audio_set_sample_rate(int sample_rate, int sample_bits)
{
    audio_hal_codec_i2s_iface_t i2s_iface;
    i2s_iface.mode = AUDIO_HAL_MODE_SLAVE;
    i2s_iface.fmt = AUDIO_HAL_I2S_NORMAL;
    i2s_iface.bits = AUDIO_HAL_BIT_LENGTH_16BITS;
    if (sample_rate == 16000) {
        i2s_iface.samples = AUDIO_HAL_16K_SAMPLES;
    } else if (sample_rate == 32000) {       
        i2s_iface.samples = AUDIO_HAL_32K_SAMPLES;
    } else if (sample_rate == 44100) {       
        i2s_iface.samples = AUDIO_HAL_44K_SAMPLES;
    } else if (sample_rate == 48000) {       
        i2s_iface.samples = AUDIO_HAL_48K_SAMPLES;
    } else {
        sample_rate = 44100;
        i2s_iface.samples = AUDIO_HAL_44K_SAMPLES;
    }
    es8388_config_i2s(AUDIO_HAL_CODEC_MODE_BOTH, &i2s_iface);
    // es8388_set_voice_volume(contex->audio_vol);
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
    i2s_set_sample_rates(I2S_NUM, sample_rate);
    printf("set sample rate: %d\n", sample_rate);
}

static void audio_set_vol(int vol)
{
    es8388_set_voice_volume(vol);
}

static void audio_ch_swap_16(uint16_t *buf, int size)
{
    int size_swap = size/2;
    uint16_t swap;
    for(int i = 0; i < size_swap-1; i += 2) {
        swap = buf[i];
        buf[i] = buf[i+1];
        buf[i+1] = swap;
    }
}

static int audio_write_i2s(uint8_t *buf, size_t size)
{
    int i2s_bytes_write = 0;
    uint16_t *pcm = (uint16_t *)buf;
    audio_ch_swap_16(pcm, size);
    i2s_write(I2S_NUM, buf, size, &i2s_bytes_write, (TickType_t)portMAX_DELAY);
    return i2s_bytes_write;
}

static int audio_read_i2s(uint8_t *buf, size_t size)
{
    size_t i2s_bytes_read = 0;
    i2s_read(I2S_NUM, buf, size, &i2s_bytes_read, (TickType_t)portMAX_DELAY);
    return i2s_bytes_read;
}

static audio_codec_t codec_8388 = {
    .init = codec_init,
    .deinit = codec_dinit,
    .set_samle_rate = audio_set_sample_rate,
    .set_vol = audio_set_vol,
    .read = audio_read_i2s,
    .write = audio_write_i2s,
    .start = audio_start,
    .stop = audio_stop,
};