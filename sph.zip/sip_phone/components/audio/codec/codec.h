#ifndef __CODEC_H__
#define __CODEC_H__

#include <stdio.h>
#include <string.h>

typedef struct {
    int (*init)(int sample_rate, int type);
    int (*deinit)(void);
    int (*set_samle_rate)(int sample_rate, int sample_bits);
    int (*set_vol)(int vol);
    int (*read)(uint8_t *buf, int len);
    int (*write)(uint8_t *buf, int len);
    int (*audio_flush_all)(void);
    int (*start)(void);
    int (*stop)(void);
} audio_codec_t;

#endif