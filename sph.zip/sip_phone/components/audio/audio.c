#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s.h"
#include "driver/gpio.h"
#include "freertos/ringbuf.h"
#include "audio.h"
#include "es8388.h"
#include "g711.h"

#define SAMPLE_RATE_DEF     (44100)
#define I2S_NUM         (0)
#define I2S_MCLK_IO     (14)
#define I2S_BCK_IO      (13)
#define I2S_WS_IO       (2)
#define I2S_DI_IO       (35)
#define I2S_DO_IO       (32)

enum {
    AUDIO_STATUS_UNINIT = 0,
    AUDIO_STATUS_INITED,
    AUDIO_STATUS_PLAY,
    AUDIO_STATUS_RECD,
    AUDIO_STATIS_STOP,
};

typedef struct {
    int sample_rate;
    int sample_bit;
    int audio_vol;
    int byte_wsap;
    int audio_status;
    StaticRingbuffer_t *audio_buffer_struct;
    RingbufHandle_t audio_rb;
    audio_cb_t *cb;
} audio_contex_t;

audio_contex_t audio_contex;

typedef void *audio_handle_t;

static RingbufHandle_t rb = NULL;

void audio_init_contex(void)
{
    memset(&audio_contex, 0, sizeof(audio_contex));
    uint8_t *buffer_storage = NULL;
    StaticRingbuffer_t *buffer_struct = (StaticRingbuffer_t *)malloc(sizeof(StaticRingbuffer_t));
    if (!buffer_struct) {
        printf("audio buffer malloc fail\n");
        goto error;
    }
    buffer_storage = heap_caps_calloc(1, 128032, MALLOC_CAP_SPIRAM);
    if (!buffer_storage) {
        printf("audio buffer malloc fail\n");
        goto error;
    }
    rb = xRingbufferCreateStatic(128032, RINGBUF_TYPE_BYTEBUF, buffer_storage, buffer_struct);
    if (!rb) {
        printf("audio buffer malloc fail\n");
        goto error;
    }
    audio_contex.audio_buffer_struct = buffer_struct;
    audio_contex.audio_rb = rb;
    audio_contex.sample_rate = SAMPLE_RATE_DEF;
    audio_contex.sample_bit = 16;
    audio_contex.audio_vol = 20;
    audio_contex.byte_wsap = 1;
    audio_contex.audio_status = AUDIO_STATUS_UNINIT;
    return 0;
error:
    if (rb) vRingbufferDelete(rb);
    if (buffer_storage) free(buffer_storage);
    if (buffer_struct) free(buffer_struct);
    return -1;
}

static void i2s_mclk_out(void)
{
    PIN_FUNC_SELECT(PERIPHS_IO_MUX_U0RXD_U, FUNC_U0RXD_CLK_OUT2);
    WRITE_PERI_REG(PIN_CTRL, 0xFF00);
}

static void audio_int_codec(void)
{
    audio_hal_codec_config_t es83xx_init = {
        .adc_input  = AUDIO_HAL_ADC_INPUT_LINE1,
        .dac_output = AUDIO_HAL_DAC_OUTPUT_LINE1,
        .codec_mode = AUDIO_HAL_CODEC_MODE_BOTH,
        .i2s_iface = {
            .mode = AUDIO_HAL_MODE_SLAVE,
            .fmt = AUDIO_HAL_I2S_NORMAL,
            .samples = AUDIO_HAL_44K_SAMPLES,
            .bits = AUDIO_HAL_BIT_LENGTH_16BITS,
        },
    };
    es8388_init(&es83xx_init);
    es8388_config_i2s(es83xx_init.codec_mode, &es83xx_init.i2s_iface);
    es8388_set_voice_volume(20);
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_STOP);
    // es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
}

static void audio_init_i2s(void)
{
    int sample_rate = SAMPLE_RATE_DEF;
    i2s_config_t i2s_config = {
        .mode = I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX,
        .sample_rate = sample_rate,
        .bits_per_sample = 16,
        .channel_format = I2S_CHANNEL_FMT_ONLY_RIGHT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .dma_buf_count = 6,
        .dma_buf_len = (sample_rate*2)/100,
        .use_apll = false,
        .tx_desc_auto_clear = true,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1
    };
    i2s_pin_config_t pin_config = {
        .bck_io_num = I2S_BCK_IO,
        .ws_io_num = I2S_WS_IO,
        .data_out_num = I2S_DO_IO,     
        .data_in_num = I2S_DI_IO,
    };
    i2s_driver_install(I2S_NUM, &i2s_config, 0, NULL);
    i2s_stop(I2S_NUM);
    i2s_set_pin(I2S_NUM, &pin_config);
    i2s_mclk_out();   
}

void audio_es8388_init(void)
{
    audio_int_codec();
    audio_init_i2s();
}

static void audio_play_task(void *arg)
{
    uint8_t *buf = NULL;
    size_t size = (SAMPLE_RATE_DEF/100)*2*2;
    size_t i2s_bytes_write;
    while (1) {
        buf = xRingbufferReceiveUpTo(rb, &size, (TickType_t)portMAX_DELAY, (SAMPLE_RATE_DEF/100)*2*2);
        if (!buf) continue;
        i2s_write(I2S_NUM, buf, size, &i2s_bytes_write, (TickType_t)portMAX_DELAY);
        vRingbufferReturnItem(rb, buf);
    }
    vTaskDelete(NULL);
}

uint32_t play_handle;

void audio_start(void)
{
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
    i2s_start(I2S_NUM);
    play_handle = xTaskCreatePinnedToCore(audio_play_task, "audio_play_task", 1024*4, NULL, 4, NULL, 1);
}

static int audio_reday_flag = 0;

void reset_status(void)
{
    audio_reday_flag = 0;
}

void audio_stop(void)
{
    size_t size;
    char *buf = xRingbufferReceive(rb, &size, (TickType_t)0);
    if (buf) {
        vRingbufferReturnItem(rb, buf);
    }
    i2s_zero_dma_buffer(I2S_NUM);
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_STOP);
    i2s_stop(I2S_NUM);
    vTaskDelete(play_handle);
}

void audio_set_sample_rate(int sample_rate, int sample_bits)
{
    audio_hal_codec_i2s_iface_t i2s_iface;
    i2s_iface.mode = AUDIO_HAL_MODE_SLAVE;
    i2s_iface.fmt = AUDIO_HAL_I2S_NORMAL;
    i2s_iface.bits = AUDIO_HAL_BIT_LENGTH_16BITS;
    if (sample_rate == 16000) {
        i2s_iface.samples = AUDIO_HAL_16K_SAMPLES;
    } else if (sample_rate == 32000) {       
        i2s_iface.samples = AUDIO_HAL_32K_SAMPLES;
    } else if (sample_rate == 44100) {       
        i2s_iface.samples = AUDIO_HAL_44K_SAMPLES;
    } else if (sample_rate == 48000) {       
        i2s_iface.samples = AUDIO_HAL_48K_SAMPLES;
    } else {
        sample_rate = 44100;
        i2s_iface.samples = AUDIO_HAL_44K_SAMPLES;
    }
    es8388_config_i2s(AUDIO_HAL_CODEC_MODE_BOTH, &i2s_iface);
    // es8388_set_voice_volume(contex->audio_vol);
    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
    i2s_set_sample_rates(I2S_NUM, sample_rate);
    printf("set sample rate: %d\n", sample_rate);
}

static void audio_task(void *arg)
{
    StaticRingbuffer_t *buffer_struct = (StaticRingbuffer_t *)malloc(sizeof(StaticRingbuffer_t));
    uint8_t *buffer_storage = heap_caps_calloc(1, 128032, MALLOC_CAP_SPIRAM);
    if (!buffer_storage) {
        printf("audio buffer alloc fail\n");
        goto out;
    }
    rb = xRingbufferCreateStatic(128032, RINGBUF_TYPE_BYTEBUF, buffer_storage, buffer_struct);

    uint8_t *buf = NULL;
    size_t size;
    size_t i2s_bytes_write;

    audio_int_codec();
    audio_init_i2s();
    size = (SAMPLE_RATE_DEF/100)*2*2;
    while (1) {
        // buf = xRingbufferReceive(rb, &size, (TickType_t)portMAX_DELAY);
        buf = xRingbufferReceiveUpTo(rb, &size, (TickType_t)portMAX_DELAY, (SAMPLE_RATE_DEF/100)*2*2);
        if (!buf) continue;
        i2s_write(I2S_NUM, buf, size, &i2s_bytes_write, (TickType_t)portMAX_DELAY);
        vRingbufferReturnItem(rb, buf);
    }
out:
    if (buffer_struct) {
        free(buffer_struct);
    }
    if (buffer_storage) {
        free(buffer_storage);
    }
    vTaskDelete(NULL);
}

static int decode(unsigned char const *start, unsigned long length);

static void audio_mp3_task(void *arg)
{
    StaticRingbuffer_t *buffer_struct = (StaticRingbuffer_t *)malloc(sizeof(StaticRingbuffer_t));
    uint8_t *buffer_storage = heap_caps_calloc(1, 128032, MALLOC_CAP_SPIRAM);
    if (!buffer_storage) {
        printf("audio buffer alloc fail\n");
        goto out;
    }
    rb = xRingbufferCreateStatic(128032, RINGBUF_TYPE_BYTEBUF, buffer_storage, buffer_struct);

    uint8_t *buf = NULL;
    size_t size;
    size_t i2s_bytes_write;

    audio_int_codec();
    audio_init_i2s();

    es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
    i2s_set_sample_rates(I2S_NUM, 44100);
    uint8_t *mad_buf = malloc(1024*8);
    buf = xRingbufferReceiveUpTo(rb, &size, (TickType_t)portMAX_DELAY, 1024*8);
    memcpy(mad_buf, buf, 1024*8);
    vRingbufferReturnItem(rb, buf);
    decode(mad_buf, 1024*8);
    while(1) {
        vTaskDelay(1000);
    }
out:
    vTaskDelete(NULL);
}

void audio_init(void)
{
    xTaskCreatePinnedToCore(audio_mp3_task, "audio_task", 1024*16, NULL, 4, NULL, 1);
}

void audio_set_vol(int vol)
{
    es8388_set_voice_volume(vol);
    // es8311_codec_set_voice_volume(vol);
}

int audio_write(uint8_t *buf, size_t size, int ms_blcok)
{
    // if (!rb) return 0;
    xRingbufferSend(rb, buf, size, ms_blcok);
    return size;
}

int audio_read(uint8_t *buf, size_t size, int ms_blcok)
{
    size_t i2s_bytes_read = 0;
    i2s_read(I2S_NUM, buf, size, &i2s_bytes_read, ms_blcok);
    return i2s_bytes_read;
}

int audio_read_i2s(uint8_t *buf, size_t size)
{
    audio_read(buf, size, 0);
    return size;
}

void audio_ulaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size)
{
    for (int i = 0; i < size/2; i++) {
        buf_ret[i] = esp_g711u_encode(buf[i]);
    }
}

void audio_ulaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size)
{
    for (int i = 0; i < size; i++) {
        buf_ret[i] = esp_g711u_decode(buf[i]);
    }
}

void audio_alaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size)
{
    for (int i = 0; i < size/2; i++) {
        buf_ret[i] = esp_g711a_encode(buf[i]);
    }
}

void audio_alaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size)
{
    for (int i = 0; i < size; i++) {
        buf_ret[i] = esp_g711a_decode(buf[i]);
    }
}

void audio_ch_swap_16(uint16_t *buf, int size)
{
    int size_swap = size/2;
    uint16_t swap;
    for(int i = 0; i < size_swap-1; i += 2) {
        swap = buf[i];
        buf[i] = buf[i+1];
        buf[i+1] = swap;
    }
}

typedef struct {
    struct {
        uint32_t id;
        uint32_t size;
        uint32_t type;
    } ripp;
    struct {
        uint32_t id;
        uint32_t size;
        uint16_t forma;
        uint16_t channel;
        uint32_t sample_rate;
        uint32_t byte_rate;
        uint16_t block_align;
        uint16_t sample_bit;
    } format;
    struct {
        uint32_t id;
        uint32_t size;
    }data;
} wav_hdr_t;

int audio_wav_parse(int *sample_rate, uint8_t *header)
{
    wav_hdr_t *hdr = (wav_hdr_t*)header;
    // printf("%x\n", hdr->ripp.id);
    // printf("%x\n", hdr->ripp.size);
    // printf("%x\n", hdr->ripp.type);
    // printf("%x\n", hdr->format.id);
    // printf("%x\n", hdr->format.size);
    // printf("%x\n", hdr->format.forma);
    // printf("%x\n", hdr->format.channel);
    // printf("saple rate: %d\n", hdr->format.sample_rate);
    // printf("bit rate: %d\n", hdr->format.byte_rate);
    // printf("%x\n", hdr->format.block_align);
    // printf("sample bit: %d\n", hdr->format.sample_bit);
    // init_flag = 1;
    *sample_rate = hdr->format.sample_rate;
    return 44;
}

int byte_swap_flag = 1;

int audio_play_wav(uint8_t *stream, size_t stream_size)
{
    int sample_rate = 0;
    uint8_t *frame_buf = stream;
    size_t frame_size = stream_size;
    if (!audio_reday_flag) {
        int offset = audio_wav_parse(&sample_rate, frame_buf);
        audio_set_sample_rate(sample_rate, 16);
        frame_buf += offset;
        frame_size -= offset;
        audio_reday_flag = 1;
    }
    if (byte_swap_flag) {
        audio_ch_swap_16((uint16_t*)frame_buf, frame_size>0 ? frame_size : 0);
    }
    audio_write(frame_buf, frame_size>0 ? frame_size : 0, 100);
    return frame_size;
}

#include "libmad/mad.h"

int audio_play_mp3(uint8_t *stream, size_t stream_size)
{
    audio_write(stream, stream_size, 100);
    return 0;
}

int audio_write_i2s(uint8_t *buf, size_t size)
{
    audio_play_wav(buf, size);
    return size;
}

extern const uint8_t dudu_start[]    asm("_binary_dudu_wav_start");
extern const uint8_t dudu_end[]      asm("_binary_dudu_wav_end");

extern const uint8_t connect_start[] asm("_binary_connect_wav_start");
extern const uint8_t connect_end[]   asm("_binary_connect_wav_end");
extern const uint8_t null_start[]    asm("_binary_null_call_wav_start");
extern const uint8_t null_end[]      asm("_binary_null_call_wav_end");


void get_audio_by_name(char *name, uint8_t **get, size_t *len)
{
    if (name == NULL) {
        *get = NULL;
        *len = 0;
        return;
    }
    if(strcmp(name, "connect") == 0) {
        *get = connect_start+44;
        *len = connect_end - connect_start-44;
    } else if (strcmp(name, "null") == 0) {
        *get = null_start+44;
        *len = null_end - null_start-44;
    } else if (strcmp(name, "dudu") == 0) {
        *get = dudu_start+44;
        *len = dudu_end - dudu_start-44;
    } else {
        *get = NULL;
        *len = 0;
    }
}

audio_cb_t audio_player_es8388 = {
    .init = audio_es8388_init,
    .deinit = NULL,
    .set_samle_rate = audio_set_sample_rate,
    .set_vol = audio_set_vol,
    .write = audio_write_i2s,
    .read = audio_read_i2s,
    .start = audio_start,
    .stop = audio_stop,
};


void audio_init_player(void)
{
    audio_contex.cb = &audio_player_es8388;
}

/**/

struct buffer {
  unsigned char const *start;
  unsigned long length;
};

/*
 * This is the input callback. The purpose of this callback is to (re)fill
 * the stream buffer which is to be decoded. In this example, an entire file
 * has been mapped into memory, so we just call mad_stream_buffer() with the
 * address and length of the mapping. When this callback is called a second
 * time, we are finished decoding.
 */

static
enum mad_flow input(void *data,
        struct mad_stream *stream)
{
    // printf("input stop\n");
  struct buffer *buffer = (struct buffer *)data;
  char *buf = NULL;
  size_t size;
  if (buffer->length == 0) {
      memcpy(buffer->start, stream->next_frame, stream->bufend-stream->next_frame );
      buffer->length = stream->bufend-stream->next_frame;
      buf = xRingbufferReceiveUpTo(rb, &size, (TickType_t)portMAX_DELAY, 1024*8-buffer->length);
      memcpy(buffer->start+buffer->length, buf, size);
      vRingbufferReturnItem(rb, buf);
      buffer->length += size;
  }
  if (!buffer->length) {
    return MAD_FLOW_STOP;
  }
  // printf("ne\n");
  mad_stream_buffer(stream, buffer->start, buffer->length);
  buffer->length = 0;
  return MAD_FLOW_CONTINUE;
}

static inline signed int scale(mad_fixed_t sample)
{
  sample += (1L << (MAD_F_FRACBITS - 16));

  if (sample >= MAD_F_ONE)
    sample = MAD_F_ONE - 1;
  else if (sample < -MAD_F_ONE)
    sample = -MAD_F_ONE;
  return sample >> (MAD_F_FRACBITS + 1 - 16);
}

static enum mad_flow output(void *data,
             struct mad_header const *header,
             struct mad_pcm *pcm)
{
  // printf("out\r\n");
  unsigned int nchannels, nsamples;
  mad_fixed_t const *left_ch, *right_ch;
  nchannels = pcm->channels;
  nsamples  = pcm->length;
  left_ch   = pcm->samples[0];
  right_ch  = pcm->samples[1];
  uint16_t *pcm_bf = malloc(pcm->length*2);//pcm->channels*
  int len = 0;
  size_t i2s_bytes_write;
  uint16_t sample;
  while (nsamples--) {
    sample = scale(*left_ch++);
    pcm_bf[len++] = sample;
    if (nchannels == 2) {
      //sample = scale(*right_ch++);
      //pcm_bf[len++] = sample;
    }
  }
  i2s_write(I2S_NUM, pcm_bf, pcm->length*2, &i2s_bytes_write, 100);
  free(pcm_bf);
  return MAD_FLOW_CONTINUE;
}

static enum mad_flow error(void *data,
            struct mad_stream *stream,
            struct mad_frame *frame)
{
  struct buffer *buffer = data;

  return MAD_FLOW_CONTINUE;
}


static int decode(unsigned char const *start, unsigned long length)
{
  struct buffer buffer;
  struct mad_decoder decoder;
  int result;
  buffer.start  = start;
  buffer.length = length;
  mad_decoder_init(&decoder, &buffer,
           input, 0 /* header */, 0 /* filter */, output,
           error, 0 /* message */);
  result = mad_decoder_run(&decoder, MAD_DECODER_MODE_SYNC);
  mad_decoder_finish(&decoder);
  return result;
}