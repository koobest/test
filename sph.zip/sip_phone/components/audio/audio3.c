#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/ringbuf.h"
#include "freertos/queue.h"
#include "audio.h"

#define SAMPLE_RATE_DEF     (44100)

enum {
    AUDIO_STATUS_UNINIT = 0,
    AUDIO_STATUS_INITED,
    AUDIO_STATUS_PLAY,
    AUDIO_STATUS_RECD,
    AUDIO_STATIS_STOP,
};

typedef struct {
    uint8_t buf[10];
} audio_decoder_t;

typedef struct {
    int sample_rate;
    int sample_bit;
    int audio_vol;
    int audio_status;
    uint8_t *buffer_storage;
    StaticRingbuffer_t *audio_buffer_struct;
    RingbufHandle_t audio_rb;
    xQueueHandle queue;
    audio_codec_t *codec;
    audio_decoder_t *decoder;
} audio_contex_t;

audio_contex_t audio_contex;

void audio_contex_free(void)
{
    if (audio_contex.audio_rb) vRingbufferDelete(audio_contex.audio_rb);
    if (audio_contex.buffer_storage) free(audio_contex.buffer_storage);
    if (audio_contex.audio_buffer_struct) free(audio_contex.audio_buffer_struct);
    memset(&audio_contex, 0, sizeof(audio_contex));
}

int audio_contex_init(void)
{
    uint8_t *buffer_storage = NULL;
    RingbufHandle_t rb;
    memset(&audio_contex, 0, sizeof(audio_contex));
    StaticRingbuffer_t *buffer_struct = (StaticRingbuffer_t *)malloc(sizeof(StaticRingbuffer_t));
    if (!buffer_struct) {
        printf("audio buffer malloc fail\n");
        goto error;
    }
    buffer_storage = heap_caps_calloc(1, 128032, MALLOC_CAP_SPIRAM);
    if (!buffer_storage) {
        printf("audio buffer malloc fail\n");
        goto error;
    }
    rb = xRingbufferCreateStatic(128032, RINGBUF_TYPE_BYTEBUF, buffer_storage, buffer_struct);
    if (!rb) {
        printf("audio buffer malloc fail\n");
        goto error;
    }
    audio_contex.buffer_storage = buffer_storage;
    audio_contex.audio_buffer_struct = buffer_struct;
    audio_contex.audio_rb = rb;
    audio_contex.sample_rate = SAMPLE_RATE_DEF;
    audio_contex.sample_bit = 16;
    audio_contex.audio_vol = 20;
    audio_contex.audio_status = AUDIO_STATUS_INITED;
    return 0;
error:
    audio_contex_free();
    return -1;
}

int audio_get_event(int time_out_ms)
{
    if (audio_contex.audio_status == AUDIO_STATUS_UNINIT) {
        return AUDIO_EVENT_EXIT;
    }
    int event = 0;
    xQueueReceive(audio_contex.queue, &event, time_out_ms/portTICK_PERIOD_MS);
    return event;
}

static void audio_flush_all(void *audio)
{
    size_t size;
    uint8_t *buf = xRingbufferReceive(audio_contex.audio_rb, &size, (TickType_t)0);
    if (!buf) return;
    audio_contex.codec->write(buf, size);
    vRingbufferReturnItem(audio_contex.audio_rb, buf);
}

static void audio_write_frame(void *audio)
{
    uint8_t *buf;
    int sample_rate = 0;
    size_t size;
    buf = xRingbufferReceiveUpTo(audio_contex.audio_rb, &size, (TickType_t)portMAX_DELAY, (sample_rate/100)*2*2);
    if (!buf) return;
    audio_contex.codec->write(buf, size);
    vRingbufferReturnItem(audio_contex.audio_rb, buf);
}

static void audio_read_frame(uint8_t *buf, size_t size)
{
    size_t i2s_bytes_read = 0;
    audio_contex.codec->read(buf, size);
    return i2s_bytes_read;
}

void audio_init_player(void)
{
    //audio_contex.codec = &audio_player_es8388;
}

void audio_find_decoder(int decoder)
{
    // int cur_decoder；
    // if (cur_decoder == decoder) return cur_decoder;
    // for (int i = 0; i < 10; i++) {
    //     if (decoder == serched) {
    //         return cur_decoder;
    //     }
    // }
}

static void try_require_decoder(int decoder)
{
    // decoder_stop_cur_decoder();
}

int audio_init_codec(void)
{
    audio_contex.codec->init(44100, 0);
    return 0;
}

void decoder_init(void)
{
    ;
}

int is_sample_rate_changed(void *audio)
{
   return 0;
}

void audio_send_event(void *audio, int event)
{
    ;
}

void send_frame_done_event(void)
{
    ;
}

void audio_start(void)
{
    // es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_START);
    // i2s_start(I2S_NUM);
    // play_handle = xTaskCreatePinnedToCore(audio_play_task, "audio_play_task", 1024*4, NULL, 4, NULL, 1);
}

void audio_stop(void)
{
    // size_t size;
    // char *buf = xRingbufferReceive(rb, &size, (TickType_t)0);
    // if (buf) {
    //     vRingbufferReturnItem(rb, buf);
    // }
    // i2s_zero_dma_buffer(I2S_NUM);
    // es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_BOTH, AUDIO_HAL_CTRL_STOP);
    // i2s_stop(I2S_NUM);
    // vTaskDelete(play_handle);
}

void audio_set_sample_rate(int sample_rate, int sample_bits)
{
    ;
}

void audio_free(void)
{
    ;
}

static void audio_play_task(void *arg)
{
    uint8_t *buf = NULL;
    size_t size = 0;
    size_t i2s_bytes_write;
    int event;
    int tout_ms = 500;
    int sample_rate = 32000;
    int vol = 30;
    while (1) {
        event = audio_get_event(tout_ms);
        switch (event) {
            case AUDIO_EVENT_FRAME:
                audio_write_frame(arg);
                tout_ms = 20;
            break;
            case AUDIO_EVENT_FRAME_DONE:
                audio_flush_all(arg);
                tout_ms = 1000;
            break;
            case AUDIO_EVENT_SET_VOL:
                audio_contex.codec->set_vol(audio_contex.audio_vol);
                break;
            case AUDIO_EVENT_PAUSE:
                tout_ms = 1000;
            break;
            case AUDIO_EVENT_STOP:
                audio_flush_all(arg);
                tout_ms = 1000;
            break;
            case AUDIO_EVENT_EXIT:
                audio_flush_all(arg);
                tout_ms = 1000;
                goto exit;
            break;
            case AUDIO_EVENT_SET_SAMPLERATE:
                audio_contex.codec->set_samle_rate(audio_contex.sample_rate, 16);
            break;
            case AUDIO_EVENET_NULL:
            break;
        }
    }
exit:
    audio_free();
    vTaskDelete(NULL);
}

void audio_init(void)
{
    if (audio_contex_init() != 0) return;
    xTaskCreatePinnedToCore(audio_play_task, "audio_play_task", 1024*16, NULL, 4, NULL, 1);
}

void audio_set_vol(int vol)
{
    ;
}

int audio_write(uint8_t *buf, size_t size, int ms_blcok)
{
    // if (!rb) return 0;
    // xRingbufferSend(rb, buf, size, ms_blcok);
    return size;
}

int audio_read(uint8_t *buf, size_t size, int ms_blcok)
{
    size_t i2s_bytes_read = 0;
    // i2s_read(I2S_NUM, buf, size, &i2s_bytes_read, ms_blcok);
    audio_read_frame(buf, size);
    return i2s_bytes_read;
}

void audio_find_codec()
{
    ;
}

/////////////////////////////////////
#include "g711.h"
void audio_ulaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size)
{
    for (int i = 0; i < size/2; i++) {
        buf_ret[i] = esp_g711u_encode(buf[i]);
    }
}

void audio_ulaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size)
{
    for (int i = 0; i < size; i++) {
        buf_ret[i] = esp_g711u_decode(buf[i]);
    }
}

void audio_alaw_enc(uint8_t *buf_ret, uint16_t *buf, size_t size)
{
    for (int i = 0; i < size/2; i++) {
        buf_ret[i] = esp_g711a_encode(buf[i]);
    }
}

void audio_alaw_dec(uint16_t *buf_ret, uint8_t *buf, size_t size)
{
    for (int i = 0; i < size; i++) {
        buf_ret[i] = esp_g711a_decode(buf[i]);
    }
}

void audio_ch_swap_16(uint16_t *buf, int size)
{
    int size_swap = size/2;
    uint16_t swap;
    for(int i = 0; i < size_swap-1; i += 2) {
        swap = buf[i];
        buf[i] = buf[i+1];
        buf[i+1] = swap;
    }
}