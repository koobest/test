#ifndef __MAIN_CONIG_H__
#define __MAIN_CONIG_H__

#ifdef __cplusplus
extern "C"
{
#endif

#define IP_ADDR  "192.168.1.5"
#define NET_MASK "255.255.255.0"
#define GW_ADDR  "192.168.1.1"

#define UNAME      "213"
// #define UNAME      "kooho"
#define PASSWD     "123456"
#define PROXY_IP   "192.168.1.22"
#define PROXY_PORT  5060

#define CALL_NAME "200"
// #define CALL_NAME "shen"

#ifdef __cplusplus
}
#endif

#endif