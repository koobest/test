#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include "lwip/err.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"
#include "parse.h"
#include "audio.h"

message_parse_contex_t udp_parse_ctx;
static console_cb_t udp_consol_cb[CMD_MAX];
int socketfd;


static int udp_open(void)
{
    struct sockaddr_in own_addr;
    int err = -1;
    int opt = 1;
    memset(&own_addr, 0, sizeof(own_addr));
    own_addr.sin_family = AF_INET;
    own_addr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    own_addr.sin_port = htons(8000);
    socketfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (socketfd < 0) {
        printf("sock\net");
        return -1;
    }
    err = setsockopt(socketfd, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt));
    err = bind(socketfd, (struct sockaddr*)&own_addr, sizeof(struct sockaddr_in));
    if (err < 0) {
        close(socketfd);
        return -1;
    }
    return 0;
}

static int udp_read(uint8_t *buf, int len)
{
    struct sockaddr_in dest_addr;
    socklen_t addr_len;
    int rxlen = recvfrom(socketfd, buf, len, 0, (struct sockaddr *)&dest_addr, &addr_len);
    return rxlen > 0 ? rxlen : 0;
}

static int udp_write(uint8_t *buf, int len)
{
    return 0;
}


static int udp_close(void)
{
    return 0;
}

void audio_set_vol(int vol);
void reset_status(void);
static int cmd_bordase_ctl_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
        // printf("play cmd: %x  %x\n", m->M_Type, m->M_Len);
        // reset_status();
        break;
        case 0x2:
            printf("set volum: %d  %d %x %x\n", m->M_Body[1], m->M_Len, m->M_Body[2], m->M_Body[3]);
        break;
        case 0x3:
            printf("sound type: %d\n", m->M_Body[1]);
        break;
        case 0x4:
            printf("split: %d\n", m->M_Body[1]);
        break;
        default:
        break;
    }
    return 0;
}

// static int cmd_audio_trans_cb(Mpayload_t *m, void *param)
// {
//     uint16_t *audio_buf = (uint16_t *)(m->M_Body-1);
//     int audio_len = m->M_Len-2;
//     // uint8_t *pr = (uint8_t *)audio_buf-1;
//     // for (int i = 0; i < audio_len; i++) {
//     //     printf("%x ", pr[i]);
//     // }
//     // printf("\n");
//     audio_ch_swap_16(audio_buf, audio_len>0 ? audio_len : 0);
//     audio_write((uint8_t*)audio_buf, audio_len>0 ? audio_len : 0, 100);
//     // printf("frame len: %d\n", audio_len);
//     return 0;
// }

void parase_audio(uint8_t *pbuf)
{
    // int pn = pbuf[0];
    // uint16_t *raw = pbuf+4;
    // printf("seq: %d\n", pn);

    // audio_ch_swap_16(raw, audio_len>0 ? audio_len : 0);
    // audio_write((uint8_t*)audio_buf, audio_len>0 ? audio_len : 0, 100);
}

// int audio_play_wav(uint8_t *stream, size_t stream_size);
// int audio_play_mp3(uint8_t *stream, size_t stream_size);

static int cmd_audio_trans_cb(Mpayload_t *m, void *param)
{
    int fnum = m->M_Body[0];
    // printf("len: %d\n", m->M_Len-4);
    uint16_t* fram_buf = &(m->M_Body[8]);
    int frame_len = m->M_Len-12;
    int sample = 0;
    // audio_wav_parse(&sample, (uint8_t *)fram_buf);
    // audio_ch_swap_16(fram_buf, frame_len>0 ? frame_len : 0);
    // audio_write((uint8_t*)fram_buf, frame_len>0 ? frame_len : 0, 100);
    // audio_play_mp3(fram_buf, frame_len);
    // audio_play_wav(fram_buf, frame_len);
    int frame_seq = *((uint32_t *)(&(m->M_Body[0])));
    int vol = m->M_Body[4];
    // printf("vol: %d\n", vol);
    static int vol_last = -1;
    if (((frame_seq+1) % 4) == 0) {
        if (vol != vol_last) {
            audio_set_vol(vol);
            vol_last = vol;
        }
    }
    return 0;
}

static int cmd_file_trans_cb(Mpayload_t *m, void *param)
{
    printf("trans file: %d\n", m->M_Body[0]);
    return 0;
}

static int cmd_param_set_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
            printf("set ip: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x2:
            printf("set port: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x3:
            printf("ip mask: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x4:
            printf("phone no: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        default:
        break;
    }
    return 0;
}

static int cmd_param_set_ack_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
    case 0x1:
        printf("param set: %d\n", m->M_Body[1]);
    break;
    default:
    break;
    }
    return 0;
}

static int cmd_status_report_cb(Mpayload_t *m, void *param)
{
    switch (m->M_Body[0]) {
        case 0x1:
            printf("set ip: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x2:
            printf("set port: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x3:
            printf("ip mask: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        case 0x4:
            printf("phone no: %x%x%x%x\n", m->M_Body[1],m->M_Body[2],m->M_Body[3],m->M_Body[4]);
        break;
        default:
        break;
    }
    return 0;
}

void exec_cmd(Mpayload_t *m)
{
    // printf("head: %x\n", m->M_Head);
    // printf("len: %x\n", m->M_Len);
    // printf("type: %x\n", m->M_Type);
    switch(m->M_Type) {
        case CMD_BORDASE_CTL:
        case CMD_AUDIO_TRANS:
        case CMD_FILE_TRANS:
        case CMD_PARAM_SET:
        case CMD_PARAM_SET_ACK:
        case CMD_STATUS_REPORT:
            if (udp_consol_cb[m->M_Type].exec) {
                udp_consol_cb[m->M_Type].exec(m, udp_consol_cb[m->M_Type].arg);
            }
        break;
        default:
        break;
    }
}

static void udp_console_task(void *param)
{
    Mpayload_t *m;
    while (1) {
        m = wait_packet(&udp_parse_ctx);
        if (m) {
            exec_cmd(m);
            del_mpacket(m);
        }
    }
}

void console_register_cb(Mtype_t type, console_exec_cb_t exec, void *arg)
{
    udp_consol_cb[type].exec = exec;
    udp_consol_cb[type].arg = arg;
}

void init_udp_parse_ctx(void)
{
    udp_open();
    udp_parse_ctx.stream_ctx.open = udp_open;
    udp_parse_ctx.stream_ctx.read = udp_read;
    udp_parse_ctx.stream_ctx.write = udp_write;
    udp_parse_ctx.stream_ctx.close = udp_close;
    udp_parse_ctx.flag = 1;
    memset(udp_consol_cb, 0, sizeof(udp_consol_cb));
    udp_consol_cb[CMD_BORDASE_CTL].exec = cmd_bordase_ctl_cb;
    udp_consol_cb[CMD_AUDIO_TRANS].exec = cmd_audio_trans_cb;
    udp_consol_cb[CMD_FILE_TRANS].exec = cmd_file_trans_cb;
    udp_consol_cb[CMD_PARAM_SET].exec = cmd_param_set_cb;
    udp_consol_cb[CMD_PARAM_SET_ACK].exec = cmd_param_set_ack_cb;
    udp_consol_cb[CMD_STATUS_REPORT].exec = cmd_status_report_cb;
    xTaskCreatePinnedToCore(udp_console_task, "udp_console_task", 1024*4, NULL, 8, NULL, 1);
}