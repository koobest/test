#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_heap_caps.h"
#include <netinet/in.h>
#include <eXosip2/eXosip.h>
#include "lwip/err.h"
#include "lwip/sys.h"
#include <osip2/osip_mt.h>
#include <eXosip2/eXosip2.h>
#include <rtp.h>
#include "audio.h"
#include "config.h"
#include "console.h"

void net_config(void);
void console_init(void);

void app_main(void)
{
    net_config();
    audio_init();
    // session_global_init();
    // session_register(session);

    // bind_key(34, 0, call0, hold_on_0);
    init_udp_parse_ctx();
}