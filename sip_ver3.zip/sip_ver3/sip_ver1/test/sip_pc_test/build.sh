#!/bin/bash

gcc test.c -o test -leXosip2 -losip2 -losipparser2

gcc test2.c -o test2 -leXosip2 -losip2 -losipparser2