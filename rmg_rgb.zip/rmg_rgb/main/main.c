/* GPIO Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/periph_ctrl.h"
#include "driver/gpio.h"
#include "soc/rmt_struct.h"
#include "soc/i2s_struct.h"
#include "soc/gpio_sig_map.h"
#include "esp_rom_gpio.h"
#include "hal/gpio_hal.h"

#define WIDTH (480)
#define HIGN  (272)

#define PCLK_DUR (4)
#define HSYNC_H_PIX (PCLK_DUR*WIDTH)
#define HSYNC_L_PIX (PCLK_DUR*50)
#define HSYNC_PIX   ((HSYNC_H_PIX)+(HSYNC_L_PIX))

#define VBP (12)
#define VFP (1)
#define HW  (1)

#define YSYNC_H_PIX (HW*HSYNC_PIX)
#define YSYNC_L_PIX ((VBP+VFP+HIGN)*HSYNC_PIX)

const rmt_item32_t clk_dur = {
    .duration0 = PCLK_DUR/2,
    .level0 = 1,
    .duration1 = PCLK_DUR/2,
    .level1 = 0,
};

const rmt_item32_t hsync_dur0 = {
    .duration0 = HSYNC_L_PIX/2,
    .level0 = 0,
    .duration1 = HSYNC_L_PIX/2,
    .level1 = 0,
};

const rmt_item32_t hsync_dur1 = {
    .duration0 = HSYNC_H_PIX/2,
    .level0 = 1,
    .duration1 = HSYNC_H_PIX/2,
    .level1 = 1,
};

const rmt_item32_t vsync_dur1 = {
    .duration0 = YSYNC_H_PIX/2,
    .level0 = 0,
    .duration1 = YSYNC_H_PIX/2,
    .level1 = 0,
};

//repeat 15;
const rmt_item32_t vsync_dur0 = {
    .duration0 = YSYNC_L_PIX/2/32,
    .level0 = 1,
    .duration1 = YSYNC_L_PIX/2/32,
    .level1 = 1,
};

static void tx_start(void)
{
    RMT.tx_sim.val = 0x17;
    RMT.ref_cnt_rst.val = 0xf;
    RMT.ref_cnt_rst.val = 0x0;

    for (int i = 0; i < 3; i++) {
        RMT.conf_ch[i].conf1.tx_start = 1;
    }
}

static void tx_stop(void)
{
    for (int i = 0; i < 3; i++) {
        RMT.conf_ch[i].conf1.tx_stop = 1;
    }
}

static void fill_mem(void)
{
    for (int i = 0; i < 4; i++) {
        RMT.conf_ch[i].conf1.mem_wr_rst = 1;
        RMT.conf_ch[i].conf1.mem_rd_rst = 1;
        RMT.conf_ch[i].conf1.apb_mem_rst = 1;
        RMT.conf_ch[i].conf1.mem_wr_rst = 0;
        RMT.conf_ch[i].conf1.mem_rd_rst = 0;
        RMT.conf_ch[i].conf1.apb_mem_rst = 0;
        for (int j = 0; j < 64; j++) {
            RMTMEM.chan[i].data32[j].val = 0;
        }
    }
    RMT.int_ena.val = 0;
    RMT.int_clr.val = ~0;

    for (int i = 0; i < 32; i++) {
        RMTMEM.chan[0].data32[i].val = clk_dur.val;
    }

    for (int i = 0; i < 32; i+=2) {
        RMTMEM.chan[1].data32[i].val = hsync_dur0.val;
        RMTMEM.chan[1].data32[i+1].val = hsync_dur1.val;
    }

    RMTMEM.chan[2].data32[0].val = vsync_dur1.val;
    for (int i = 1; i < 33; i++) {
        RMTMEM.chan[2].data32[i].val = vsync_dur0.val;
    }
}

static void _gpio_config(void)
{
    gpio_set_level(37, 0);
    gpio_set_level(38, 0);
    gpio_set_level(39, 0);
    gpio_set_level(40, 0);

    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[37], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[38], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[39], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[40], PIN_FUNC_GPIO);
    //gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[21], PIN_FUNC_GPIO);
    gpio_set_direction(37, GPIO_MODE_OUTPUT);
    gpio_set_direction(38, GPIO_MODE_OUTPUT);
    gpio_set_direction(39, GPIO_MODE_OUTPUT);
    gpio_set_direction(40, GPIO_MODE_OUTPUT);


    gpio_set_level(3, 0);
    gpio_set_level(4, 0);
    gpio_set_level(5, 0);
    gpio_set_level(6, 0);
    gpio_set_level(7, 0);
    gpio_set_level(8, 0);
    gpio_set_level(9, 0);
    gpio_set_level(10, 0);
    gpio_set_level(11, 0);
    gpio_set_level(12, 0);
    gpio_set_level(13, 0);
    gpio_set_level(14, 0);
    gpio_set_level(15, 0);
    gpio_set_level(16, 0);
    gpio_set_level(17, 0);
    gpio_set_level(18, 0);
    gpio_set_level(19, 0);
    gpio_set_level(20, 0);
    gpio_set_level(21, 0);
    gpio_set_level(26, 0);
    gpio_set_level(33, 0);
    gpio_set_level(34, 0);
    gpio_set_level(35, 0);
    gpio_set_level(36, 0);

    gpio_set_direction(3, GPIO_MODE_OUTPUT);
    gpio_set_direction(4, GPIO_MODE_OUTPUT);
    gpio_set_direction(5, GPIO_MODE_OUTPUT);
    gpio_set_direction(6, GPIO_MODE_OUTPUT);
    gpio_set_direction(7, GPIO_MODE_OUTPUT);
    gpio_set_direction(8, GPIO_MODE_OUTPUT);
    gpio_set_direction(9, GPIO_MODE_OUTPUT);
    gpio_set_direction(10, GPIO_MODE_OUTPUT);
    gpio_set_direction(11, GPIO_MODE_OUTPUT);
    gpio_set_direction(12, GPIO_MODE_OUTPUT);
    gpio_set_direction(13, GPIO_MODE_OUTPUT);
    gpio_set_direction(14, GPIO_MODE_OUTPUT);
    gpio_set_direction(15, GPIO_MODE_OUTPUT);
    gpio_set_direction(16, GPIO_MODE_OUTPUT);
    gpio_set_direction(17, GPIO_MODE_OUTPUT);
    gpio_set_direction(18, GPIO_MODE_OUTPUT);
    gpio_set_direction(19, GPIO_MODE_OUTPUT);
    gpio_set_direction(20, GPIO_MODE_OUTPUT);
    gpio_set_direction(21, GPIO_MODE_OUTPUT);
    gpio_set_direction(26, GPIO_MODE_OUTPUT);
    gpio_set_direction(33, GPIO_MODE_OUTPUT);
    gpio_set_direction(34, GPIO_MODE_OUTPUT);
    gpio_set_direction(35, GPIO_MODE_OUTPUT);
    gpio_set_direction(36, GPIO_MODE_OUTPUT);

    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[3], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[4], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[5], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[6], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[7], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[8], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[9], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[10], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[11], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[12], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[13], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[14], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[15], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[16], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[17], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[18], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[19], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[20], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[21], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[26], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[33], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[34], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[35], PIN_FUNC_GPIO);
    gpio_hal_iomux_func_sel(GPIO_PIN_MUX_REG[36], PIN_FUNC_GPIO);


//    gpio_set_direction(21, GPIO_MODE_OUTPUT);
}

static void rmt_sig_map(void)
{
    esp_rom_gpio_connect_out_signal(37, RMT_SIG_OUT0_IDX, 0, 0);
    esp_rom_gpio_connect_out_signal(38, RMT_SIG_OUT1_IDX, 0, 0);
    esp_rom_gpio_connect_out_signal(39, RMT_SIG_OUT2_IDX, 0, 0);
    esp_rom_gpio_connect_out_signal(40, RMT_SIG_OUT3_IDX, 0, 0);

    // esp_rom_gpio_connect_in_signal(12,  I2S0O_WS_IN_IDX, 0);
    // esp_rom_gpio_connect_in_signal(12,  I2S0O_BCK_IN_IDX, 0);
    // esp_rom_gpio_connect_out_signal(12, I2S0O_WS_OUT_IDX, 0, 0);
    int i = 0;
    esp_rom_gpio_connect_out_signal(3, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(4, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(5, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(6, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(7, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(8, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(9, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(10, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(11, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(12, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(13, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(14, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(15, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(16, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(17, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(18, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(19, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(20, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(21, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(26, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(33, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(34, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(35, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
    esp_rom_gpio_connect_out_signal(36, I2S0O_DATA_OUT8_IDX+i++, 0, 0);
}

#include "soc/lldesc.h"

lldesc_t data_desc = {0};

int data[30] = {0x1};

static inline void dma_tx_start(void)
{
    for (int i = 0; i < 30; i++) {
        data[i] = 0x17922361+i;
    }
    data_desc.size = 30*3;
    data_desc.length = 30*3;
    data_desc.eof = 1;
    data_desc.owner = 1;
    data_desc.buf = (uint8_t *)data;
    data_desc.empty = (uint32_t)&data_desc;
    I2S0.out_link.addr = (uint32_t)(&data_desc);

    int tout = 3;
    I2S0.fifo_conf.dscr_en = 1;
    I2S0.int_clr.val = ~0;
    I2S0.out_link.start = 1;
    ets_delay_us(1);
    I2S0.conf.tx_start = 1;

    printf("I2S0: %x\n", I2S0.date);
}

static void i2s_lcd_config(void)
{
    periph_module_enable(PERIPH_I2S0_MODULE);
    I2S0.clkm_conf.val = 0;
    I2S0.clkm_conf.clkm_div_num = 2;
    I2S0.clkm_conf.clkm_div_b = 0;
    I2S0.clkm_conf.clkm_div_a = 0;
    I2S0.clkm_conf.clk_sel = 2;
    I2S0.clkm_conf.clk_en = 1;

    // 配置采样率
    I2S0.sample_rate_conf.val = 0;
    // 配置数据格式
    I2S0.conf.val = 0;
    I2S0.conf1.val = 0;
    I2S0.conf2.val = 0;
    I2S0.conf_chan.val = 0;
    I2S0.fifo_conf.val = 0;
    I2S0.timing.val = 0;
    I2S0.int_ena.val = 0;
    I2S0.int_clr.val = ~0;

    I2S0.lc_conf.ahbm_fifo_rst = 1;
    I2S0.lc_conf.ahbm_fifo_rst = 0;
    I2S0.lc_conf.ahbm_rst = 1;
    I2S0.lc_conf.ahbm_rst = 0;

    I2S0.sample_rate_conf.tx_bck_div_num = 2;
    I2S0.sample_rate_conf.tx_bits_mod = 24;

    // 配置数据格式
    I2S0.conf.tx_right_first = 1;
    I2S0.conf.tx_msb_right = 1;
    I2S0.conf.tx_dma_equal = 1;
    I2S0.conf1.tx_pcm_bypass = 1;
    I2S0.conf1.tx_stop_en = 1;
    I2S0.conf2.lcd_en = 1;
    I2S0.conf2.camera_en = 1;
    I2S0.conf2.cam_clk_loopback = 1;
    I2S0.conf_chan.tx_chan_mod = 1;
    I2S0.fifo_conf.tx_fifo_mod_force_en = 1;
    I2S0.fifo_conf.tx_data_num = 32;
    I2S0.fifo_conf.tx_fifo_mod = 1;
    I2S0.fifo_conf.dscr_en = 1;

    I2S0.lc_conf.out_rst  = 1;
    I2S0.lc_conf.out_rst  = 0;
    I2S0.conf.tx_reset = 1;
    I2S0.conf.tx_reset = 0;

    // I2S0.conf.sig_loopback = 1;
    // I2S0.conf2.inter_valid_en = 1;
    // I2S0.conf.tx_slave_mod = 1;
}

static void rmt_config(void)
{
    periph_module_reset(PERIPH_RMT_MODULE);
    periph_module_enable(PERIPH_RMT_MODULE);
    i2s_lcd_config();
    _gpio_config();

    RMT.apb_conf.fifo_mask = 1;
    RMT.apb_conf.clk_en = 1;

    for (int i = 0; i < 3; i++) {
        RMT.conf_ch[i].conf1.tx_start = 1;
    }

    for (int i = 0; i < 4; i++) {
        
        // RMT.carrier_duty_ch[i].low = 50;
        // RMT.carrier_duty_ch[i].high = 50;

        RMT.conf_ch[i].conf0.carrier_en = 0;

        // RMT.conf_ch[i].conf0.val = 0;
        RMT.conf_ch[i].conf0.div_cnt = 1;
        RMT.conf_ch[i].conf0.carrier_eff_en = 0;
        RMT.conf_ch[i].conf1.val = 0;
        RMT.conf_ch[i].conf1.ref_always_on = 1;
        RMT.conf_ch[i].conf1.tx_conti_mode = 1;
        RMT.conf_ch[i].conf1.mem_wr_rst = 1;
        RMT.conf_ch[i].conf1.mem_rd_rst = 1;
        RMT.conf_ch[i].conf1.apb_mem_rst = 1;
        RMT.conf_ch[i].conf1.mem_wr_rst = 0;
        RMT.conf_ch[i].conf1.mem_rd_rst = 0;
        RMT.conf_ch[i].conf1.apb_mem_rst = 0;

        RMT.conf_ch[i].conf1.idle_out_lv = 0;
        RMT.conf_ch[i].conf1.idle_out_en = 1;
    }
    fill_mem();
    tx_start();
    printf("RMT: %x\n", RMT.date);
    tx_stop();
    rmt_sig_map();
    fill_mem();
    dma_tx_start();
    tx_start();
}

void app_main(void)
{
    rmt_config();
    while (1) {
        vTaskDelay(10/portTICK_PERIOD_MS);
        // printf("%x\n", I2S0.int_raw.val);
        for (int i = 0; i < 30; i++) {
            data[i]++;
        }
    }
}